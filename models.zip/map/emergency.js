/**
 * dqy 20171104
 * 右侧辅助决策，远程商务，应急救援，最新动态模块ui变化绑定
 * 辅助决策（态势分析，地图标绘功能) 
 * main.js 引入emergency.js 执行init()方法，完成初始化
 * initMap.js 中添加了提供绘制的图层，plotLayer
 */
define(["ol", "initMap", "mapTools", "layerConfig", "text!boom.html","poison","fire"],function(ol, mapContent, mapTools,layerConfig,boomHtm,poison,fire) {
    //私有属性，方法
    var operType; //地图标绘，态势分析
    var sgid = layerConfig.emergencyId; //事务id
    var plotDraw;
    var selectKey, modifyKey;
    var wktFormat = new ol.format.WKT();
    var colors = ["#ff0000", "#00ff00"];
    var selectInteraction = new ol.interaction.Select({ layers: [mapContent.plotLayer], multi: false });
    var modify = new ol.interaction.Modify({ features: selectInteraction.getFeatures(), multi: false });
    //绘制标绘
    function DrawPlot(type, drawlayer) {
        if (plotDraw) {
            mapContent.map.removeInteraction(plotDraw);
            plotDraw = null;
        }
        switch (type) {
            case '聚集地':
                plotDraw = mapTools.drawHabitation(mapContent.map, drawlayer.getSource());
                plotDraw.on("drawend", function(evt) {
                    evt.feature.setProperties({
                        'type': 'jjd',
                        'name': '',
                        'labeltype':'聚集地'
                    });
                    return;
                    layer.open({
                        type: 1,
                        title: false,
                        area: ['200px', '120px'],
                        closeBtn: 0,
                        content: '<div style="font-size:14px;margin:2px 10px;"><label>请输入标注名称：</label></br><input id="name" type="text" value="" /></div>',
                        btn: ['确定', '取消'],
                        yes: function(index) {
                            var name = $('#name').val();
                            if (!name) {
                                layer.msg('请输入标注名称！', {
                                    icon: 7,
                                    time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                });
                                return null;
                            } else {
                                //evt.feature.setStyle(mapContent.createStyle(colors[0], colors[1], 1, 1, name));
                                evt.feature.setProperties({
                                    'type': 'jjd',
                                    'name': name,
                                    'labeltype':'聚集地'
                                })
                                //mapContent.map.removeInteraction(plotDraw);
                                //plotDraw = null;
                                layer.close(index);
                                console.log(evt.feature);
                            }
                        },
                        btn2: function() {
                            mapContent.plotLayer.getSource().removeFeature(evt.feature);
                            //mapContent.map.removeInteraction(plotDraw);
                            //plotDraw = null;
                        }
                    });
                });
                break;
            case '简单箭头':
                plotDraw = mapTools.simpleArrow(mapContent.map, drawlayer.getSource());
                plotDraw.on("drawend", function(evt) {
                    evt.feature.setProperties({
                        'type': 'jdjt',
                        'name': '',
                        'labeltype':'简单箭头'
                    });
                    return;
                    layer.open({
                        type: 1,
                        title: false,
                        area: ['200px', '120px'],
                        closeBtn: 0,
                        content: '<div style="font-size:14px;margin:2px 10px;"><label>请输入标注名称：</label></br><input id="name" type="text" value="" /></div>',
                        btn: ['确定', '取消'],
                        yes: function(index) {
                            var name = $('#name').val();
                            if (!name) {
                                layer.msg('请输入标注名称！', {
                                    icon: 7,
                                    time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                });
                                return null;
                            } else {
                                //evt.feature.setStyle(mapContent.createStyle(colors[0], colors[1], 1, 1, name));
                                evt.feature.setProperties({
                                    'type': 'jdjt',
                                    'name': name,
                                    'labeltype':'简单箭头'
                                })
                                //mapContent.map.removeInteraction(plotDraw);
                                //plotDraw = null;
                                layer.close(index);
                                console.log(evt.feature);
                            }
                        },
                        btn2: function() {
                            mapContent.plotLayer.getSource().removeFeature(evt.feature);
                            //mapContent.map.removeInteraction(plotDraw);
                            //plotDraw = null;
                        }
                    });
                });
                break;
            case '直箭头':
                plotDraw = mapTools.fineArrow(mapContent.map, drawlayer.getSource());
                plotDraw.on("drawend", function(evt) {
                    evt.feature.setProperties({
                        'type': 'zjt',
                        'name': '',
                        'labeltype':'直箭头'
                    });
                   /* return;
                    layer.open({
                        type: 1,
                        title: false,
                        area: ['200px', '120px'],
                        closeBtn: 0,
                        content: '<div style="font-size:14px;margin:2px 10px;"><label>请输入标注名称：</label></br><input id="name" type="text" value="" /></div>',
                        btn: ['确定', '取消'],
                        yes: function(index) {
                            var name = $('#name').val();
                            if (!name) {
                                layer.msg('请输入标注名称！', {
                                    icon: 7,
                                    time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                });
                                return null;
                            } else {
                                //evt.feature.setStyle(mapContent.createStyle(colors[0], colors[1], 1, 1, name));
                                evt.feature.setProperties({
                                    'type': 'zjt',
                                    'name': name,
                                    'labeltype':'直箭头'
                                })
                                //mapContent.map.removeInteraction(plotDraw);
                                //plotDraw = null;
                                layer.close(index);
                                console.log(evt.feature);
                            }
                        },
                        btn2: function() {
                            mapContent.plotLayer.getSource().removeFeature(evt.feature);
                            //mapContent.map.removeInteraction(plotDraw);
                            //plotDraw = null;
                        }
                    });*/
                });
                break;
            case '长箭头':
                plotDraw = mapTools.longArrow(mapContent.map, drawlayer.getSource());
                plotDraw.on("drawend", function(evt) {
                    evt.feature.setProperties({
                        'type': 'cjt',
                        'name': '',
                        'labeltype':'长箭头'
                    });
                    return;
                    layer.open({
                        type: 1,
                        title: false,
                        area: ['200px', '120px'],
                        closeBtn: 0,
                        content: '<div style="font-size:14px;margin:2px 10px;"><label>请输入标注名称：</label></br><input id="name" type="text" value="" /></div>',
                        btn: ['确定', '取消'],
                        yes: function(index) {
                            var name = $('#name').val();
                            if (!name) {
                                layer.msg('请输入标注名称！', {
                                    icon: 7,
                                    time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                });
                                return null;
                            } else {
                                //evt.feature.setStyle(mapContent.createStyle(colors[0], colors[1], 1, 1, name));
                                evt.feature.setProperties({
                                    'type': 'cjt',
                                    'name': name,
                                    'labeltype':'长箭头'
                                })
                                //mapContent.map.removeInteraction(plotDraw);
                                //plotDraw = null;
                                layer.close(index);
                                console.log(evt.feature);
                            }
                        },
                        btn2: function() {
                            mapContent.plotLayer.getSource().removeFeature(evt.feature);
                            //mapContent.map.removeInteraction(plotDraw);
                            //plotDraw = null;
                        }
                    });
                });
                break;
            case '撤离路线':
                plotDraw = new ol.interaction.Draw({
                    type: 'LineString',
                    source: drawlayer.getSource()
                });
                mapContent.map.addInteraction(plotDraw);
                plotDraw.on("drawend", function(evt) {
                    evt.feature.setProperties({
                        'type': 'cllx',
                        'name': '',
                        'labeltype':'撤离路线'
                    });
                    return;
                    layer.open({
                        type: 1,
                        title: false,
                        area: ['200px', '120px'],
                        closeBtn: 0,
                        content: '<div style="font-size:14px;margin:2px 10px;"><label>请输入标注名称：</label></br><input id="name" type="text" value="" /></div>',
                        btn: ['确定', '取消'],
                        yes: function(index) {
                            var name = $('#name').val();
                            if (!name) {
                                layer.msg('请输入标注名称！', {
                                    icon: 7,
                                    time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                });
                                return null;
                            } else {
                                //evt.feature.setStyle(mapContent.createStyle(colors[0], colors[1], 6, 1, name));
                                evt.feature.setProperties({
                                    'type': 'cllx',
                                    'name': name,
                                    'labeltype':'撤离路线'
                                })
                                //mapContent.map.removeInteraction(plotDraw);
                                //plotDraw = null;
                                layer.close(index);
                            }
                        },
                        btn2: function() {
                            mapContent.plotLayer.getSource().removeFeature(evt.feature);
                            //mapContent.map.removeInteraction(plotDraw);
                            //plotDraw = null;
                        }
                    });
                });
                break;
            case '关注点':
                plotDraw = new ol.interaction.Draw({
                    type: 'Point',
                    source: drawlayer.getSource()
                });
                mapContent.map.addInteraction(plotDraw);
                plotDraw.on("drawend", function(evt) {
                    evt.feature.setProperties({
                        'type': 'gzd',
//                        'name': '',
                        'labeltype':'关注点'
                    });
                    return;
                    layer.open({
                        type: 1,
                        title: false,
                        area: ['200px', '120px'],
                        closeBtn: 0,
                        content: '<div style="font-size:14px;margin:2px 10px;"><label>请输入标注名称：</label></br><input id="name" type="text" value="" /></div>',
                        btn: ['确定', '取消'],
                        yes: function(index) {
                            var name = $('#name').val();
                            if (!name) {
                                layer.msg('请输入标注名称！', {
                                    icon: 7,
                                    time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                });
                                return null;
                            } else {
                                //evt.feature.setStyle(mapContent.createStyle(colors[0], colors[1], 1,6, name));
                                evt.feature.setProperties({
                                    'type': 'gzd',
                                    'name': name,
                                    'labeltype':'关注点'
                                })
                                //mapContent.map.removeInteraction(plotDraw);
                                //plotDraw = null;
                                layer.close(index);
                                console.log(evt.feature);
                            }
                        },
                        btn2: function() {
                            mapContent.plotLayer.getSource().removeFeature(evt.feature);
                            //mapContent.map.removeInteraction(plotDraw);
                            //plotDraw = null;
                        }
                    });

                });
                break;
            case '文字标绘':
                plotDraw = new ol.interaction.Draw({
                    type: 'Point',
                    source: drawlayer.getSource()
                });
                mapContent.map.addInteraction(plotDraw);
                plotDraw.on("drawend", function(evt) {
                    layer.open({
                        type: 1,
                        title: false,
                        area: ['200px', '120px'],
                        closeBtn: 0,
                        content: '<div style="font-size:14px;margin:2px 10px;"><label>请输入标注文字：</label></br><input id="name" type="text" placeholder="最多10个字" value="" /></div>',
                        btn: ['确定', '取消'],
                        yes: function(index) {
                            var name = $('#name').val();
                            if (!name) {
                                layer.msg('请输入标注文字！', {
                                    icon: 7,
                                    time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                });
                                return null;
                            } else {
                                if(name.length>10){
                                    layer.msg('最多10个文字！', {
                                        icon: 7,
                                        time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                    });
                                    return null;
                                }
                                //evt.feature.setStyle(mapContent.createStyle(colors[0], colors[1], 1,6, name));
                                evt.feature.setProperties({
                                    'type': 'wzbh',
                                    'name': name,
                                    'labeltype':'文字标绘'
                                })
                                //mapContent.map.removeInteraction(plotDraw);
                                //plotDraw = null;
                                layer.close(index);
                            }
                        },
                        btn2: function() {
                            mapContent.plotLayer.getSource().removeFeature(evt.feature);
                            //mapContent.map.removeInteraction(plotDraw);
                            //plotDraw = null;
                        }
                    });

                });
                break;
            default:
                return null;
                break;

        }
    }
    //清除标绘模块
    function clearDraw() {
    	$(".resourcetable").slideUp();//隐藏资源清单
    	mapContent.addResources=false;//停止添加资源
        mapContent.map.removeInteraction(plotDraw);
        plotDraw = null;
        mapContent.map.removeInteraction(selectInteraction);
        selectInteraction.unByKey(selectKey);
        modify.unByKey(modifyKey);
        mapContent.plotLayer.getSource().clear();
    }
    //地图标绘,态势分析功能绑定
    function callback(e) {
        var text = $(e.target).text();
        mapContent.map.removeInteraction(plotDraw);
        plotDraw = null;
        mapContent.map.removeInteraction(selectInteraction);
        selectInteraction.unByKey(selectKey);
        modify.unByKey(modifyKey);
        switch (text) {
            case '聚集地':
            case '撤离路线':
            case '关注点':
            case '简单箭头':
            case '直箭头':
            case '长箭头':
            case '文字标绘':
                DrawPlot(text, mapContent.plotLayer)
                break;
            case '保存绘制':
                var features = mapContent.plotLayer.getSource().getFeatures();
                console.log(features);
                //mapContent.plotLayer.getSource().clear();

                if (features.length > 0) {
                    var params = [];
                    $.each(features, function(index, item) {
                        var geomWkt = wktFormat.writeFeature(item, {
                            decimals: 6
                        }).replace(new RegExp(',', "gm"), '=');
                        var geomType = item.getGeometry().getType();
                        var name = item.getProperties().name;
                        if(!name){name='';}
                        var type = item.getProperties().type;
                        switch (geomType) {
                            case "Point":
                                params.push({
                                    "id": '',
                                    "sgid": layerConfig.emergencyId,
                                    "name": name,
                                    "type": type,
                                    "geom": geomWkt,
                                    "fl": operType,
                                    "geomtype": "point"
                                });
                                break;
                            case "LineString":
                                params.push({
                                    "id": '',
                                    "sgid": layerConfig.emergencyId,
                                    "name": name,
                                    "type": type,
                                    "geom": geomWkt,
                                    "fl": operType,
                                    "geomtype": "line"
                                });
                                break;
                            case "Polygon":
                                params.push({
                                    "id": '',
                                    "sgid": layerConfig.emergencyId,
                                    "name": name,
                                    "type": type,
                                    "geom": geomWkt,
                                    "fl": operType,
                                    "geomtype": "polygon"
                                });
                                break;
                            default:
                                break;
                        }
                    });
                    var url = '/main/onemap/AddPlotGeom';
                    //                  params=JSON.stringify(params);
                    //                  params=params.replace(new RegExp(',',"gm"),'='); 
                    if(!layerConfig.emergencyId){
                    	layer.msg("清先和应急响应关联，然后再保存！");
                    	return;
                    }
                    $.ajax({
                        type: "POST",
                        url: url,
//                        contentType: "application/json; charset=utf-8",
                        datatype: "json",
                        data: {
                            plotgeomlist: JSON.stringify(params)
                        },
                        success: function(data) {
                            var data=JSON.parse(data);
                            if (data.flag) {
                                layer.msg("操作成功！");
                            } else {
                                layer.msg("操作失败！");
                            }
                        },
                        error: function(e) {
                            console.log(e);
                        }
                    })
                } else {
                    layer.msg("无标绘！");
                }
                break;
            case '修改标注':
                var originFeature;
                selectInteraction.getFeatures().clear();
                mapContent.map.addInteraction(selectInteraction);
                mapContent.map.addInteraction(modify);
                selectKey = selectInteraction.on("select", function(evt) {
                    if (evt.selected.length < 1) return;
                    var name = evt.selected[0].getProperties().name;
                    if(!name){
                        selectInteraction.getFeatures().clear();
                        return;
                    }
                    originFeature = evt.selected[0].clone();
                    layer.open({
                        type: 1,
                        title: false,
                        area: ['200px', '120px'],
                        closeBtn: 0,
                        content: '<div style="font-size:14px;margin:2px 10px;"><label>请输入修改名称：</label></br><input id="name" type="text" value=' + name + ' /></div>',
                        btn: ['确定', '取消'],
                        yes: function(index) {
                            var name = $('#name').val();
                            if (!name) {
                                layer.msg('请输入标注名称！', {
                                    icon: 7,
                                    time: 1000 //2秒关闭（如果不配置，默认是3秒）
                                });
                                return null;
                            } else {
                                //evt.feature.setStyle(mapContent.createStyle(colors[0], colors[1], 1,6, name));
                                evt.selected[0].setProperties({
                                    'name': name
                                })
                                //mapContent.map.removeInteraction(plotDraw);
                                //plotDraw = null;
                                layer.close(index);
                                console.log(evt.feature);
                                selectInteraction.getFeatures().clear();
                            }
                        },
                        btn2: function() {
                            //mapContent.map.removeInteraction(plotDraw);
                            //plotDraw = null;
                            selectInteraction.getFeatures().clear();
                        }
                    });
                    //map.removeInteraction(selectInteraction);
                });
                break;
            case '修改颜色':
            	 var originFeature;
                 selectInteraction.getFeatures().clear();
                 mapContent.map.addInteraction(selectInteraction);
                 
                 selectKey = selectInteraction.on("select", function(evt) {
                     if (evt.selected.length < 1) return;
                     var geomType = evt.selected[0].getProperties().type;
                     var typeName=evt.selected[0].getGeometry().getType();
                     var html="";
                     if(typeName==="Point"){
                    	 html="设置点的大小:<input type='text' min=5 value='5' style='width: 85px;'><br/>设置点的颜色：<input value='#ffff00' type='color'>";
                     }else if(typeName==="LineString"){
                    	 html="设置线的宽度:<input type='text' max=10 value='2' style='width: 85px;'><br/>设置线的宽度：<input value='#ffff00' type='color'>";
                     }else if(typeName==="Polygon"){
                    	 html="设置边的宽度:<input type='text' max=10 value='2' style='width: 85px;'><br/>设置面的填充颜色：<input value='#ffff00' type='color'>";
                     }
                     layer.open({
                    	 type:1,
                    	 content:html,
                    	 area:["200px","150px"],
                    	 btn:["确定"],
                    	 yes:function(index,layero){
                    		 
                    		 var $inputs=$(layero).find("input");
                    		 console.log(parseInt($inputs.eq(0).val()));
                    		 if(!isNaN(parseInt($inputs.eq(0).val()))&&1<parseInt($inputs.eq(0).val())&&parseInt($inputs.eq(0).val())<9){
                    			 layer.close(index);
                    		 }else{
                    			 layer.msg("输入值必须在2到8之间");
                    			 return;
                    		 }
                    		 
                    		 
                    		 
                    		 
                    		 if(typeName==="Point"){
                    			 evt.selected[0].setStyle(new ol.style.Style({
                    				 image:new ol.style.Circle({
                    					 radius:parseInt($inputs.eq(0).val()),
                    					 fill:new ol.style.Fill({
                    						 color:$inputs.eq(1).val()
                    					 })
                    				 })
                    			 }));
                    		 }else if(typeName==="LineString"){
                    			 evt.selected[0].setStyle(new ol.style.Style({
                    				 stroke:new ol.style.Stroke({
                    					 width:parseInt($inputs.eq(0).val()),
                    					 color:$inputs.eq(1).val()
                    				 })
                    			 }));
                    		 }else if(typeName==="Polygon"){
                    			 evt.selected[0].setStyle(new ol.style.Style({
                    				 stroke:new ol.style.Stroke({
                    					 width:parseInt($inputs.eq(0).val()),
                    					 color:"#ff0000"
                    				 }),
                    				 fill:new ol.style.Fill({
                    					 color:$inputs.eq(1).val()
                    				 })
                    			 }));
                    		 }
                    		 
                    	 }
                     })
                     
                    /* if (geomType == 'jjd') {
                         selectInteraction.getFeatures().clear();
                         layer.msg('聚集地不支持图形修改！');
                         return;
                     }
                     var name = evt.selected[0].getProperties().name;
                     originFeature = evt.selected[0].clone();*/
                     //map.removeInteraction(selectInteraction);
                 });
            	break;
            case '修改图形':
                var originFeature;
                selectInteraction.getFeatures().clear();
                mapContent.map.addInteraction(selectInteraction);
                mapContent.map.addInteraction(modify);
                selectKey = selectInteraction.on("select", function(evt) {
                    if (evt.selected.length < 1) return;
                    var geomType = evt.selected[0].getProperties().type;
                    if (geomType == 'jjd') {
                        selectInteraction.getFeatures().clear();
                        layer.msg('聚集地不支持图形修改！');
                        return;
                    }
                    var name = evt.selected[0].getProperties().name;
                    originFeature = evt.selected[0].clone();
                    //map.removeInteraction(selectInteraction);
                });
                modifyKey = modify.on("modifyend", function(evt) {
                    var feature = evt.features.getArray()[0];

                });
                break;
            case '删除':
                selectInteraction.getFeatures().clear();
                mapContent.map.addInteraction(selectInteraction);
                selectKey = selectInteraction.on("select", function(evt) {
                    var name = evt.selected[0].getProperties().name;
                    var feature = evt.selected[0];
                    layer.confirm('确定要删除' + name + '?', { icon: 3, title: '提示' }, function(index) {
                        mapContent.plotLayer.getSource().removeFeature(feature);
                        //mapContent.map.removeInteraction(selectInteraction);
                        layer.close(index);
                    }, function() {

                    });
                    selectInteraction.getFeatures().clear();

                });
                break;
            default:
                break;
        }
    }
    //获取标绘列表 事务id sgid,模块分类 fl (dtbh地图标绘，tsfx态势分析)
    function getPlotList(sgid,fl){
        if(!sgid){
            layer.msg('参数(sgid)不能为空！');
            return;
        }
        if(!fl){
            layer.msg('参数(fl)不能为空！');
            return;
        }
        if(!layerConfig.emergencyId){
        	layer.msg("必须先和应急响应关联");
            return;
        }
        var url = '/main/onemap/GetPlotList';
        $.ajax({
            type: "GET",
            url: url,
            datatype: "json",
            data: {
                sgid:layerConfig.emergencyId,
                fl:fl
            },
            success: function(data) {
               return data;
            },
            error: function(e) {
                console.log(e);
                layer.msg('获取数据失败！');
                return null;
            }
        })
    }
    //模型 爆炸
    //常数定义
    const N = 0.1; //效率因子
    var boomR, //损害半径 m
        V, //气体体积 m3
        Hc, //可燃气体高燃烧热值 kJ/m3
        Cs; //经验常数，取决于伤害等级
    var Cs=[0.06,0.15,0.4];
    var drawTool; //绘制工具
    var boomCoord; //爆炸点坐标
    //分析结果
    var bufferCircle;
    //爆炸点图层
    var vectorLyr = new ol.layer.Vector({
        source: new ol.source.Vector()
//        style: new ol.style.Style({
//            image: new ol.style.RegularShape({
//                fill: new ol.style.Fill({ color: "#ff0000" }),
//                stroke: new ol.style.Stroke({
//                    width: 2,
//                    color: "#ff0000"
//                }),
//                points: 9,
//                radius: 6,
//                radius2: 4,
//                angle: 0
//            })
//        })
    });
    //爆炸范围图层
    var analysisLyr;
    //绘制爆炸点
    function drawBoomPosition() {
//        document.getElementById('result').innerHTML = '';
        boomCoord = null;
        //清空图层
        analysisLyr.getSource().clear();
        vectorLyr.getSource().clear();
        if (drawTool) return;
        drawTool = new ol.interaction.Draw({
            source: vectorLyr.getSource(),
            type: 'Point'
        });
        mapContent.map.addInteraction(drawTool);
        drawTool.on('drawend', function(e) {
            // body...
            mapContent.map.removeInteraction(drawTool);
            drawTool = null;
            e.feature.setStyle(new ol.style.Style({
                image:new ol.style.Icon({
                    src:'/main/resources/image/map/bomb.png',
                    size:[16,16],
                    anchor:[0.5,0.5]
                })
            }));
            boomCoord = e.feature.getGeometry().getCoordinates();
        });
    }
    var breaks=[10,25,47];
    //影响范围分析
    function boomAnalysis() {
        if (!boomCoord) {
            layer.msg('请绘制爆炸发生位置！');
            return;
        }
        V = document.getElementById('V').value;
        if (!V||V<=0) {
            layer.msg('请输入爆炸气体体积并且不能为负值！');
            return;
        }
        Hc = document.getElementById('Hc').value;
//        Cs = document.getElementById('Cs').value;  
        var features=[];
        var colors=["#982000", "#d1571b", "#f0824c"];
        for(var i=Cs.length-1;i>=0;i--){
            var boomR = (Cs[i] * Math.pow((N * V * Hc), 1 / 3)).toFixed(1);
            var r = boomR / (2 * Math.PI * 6378137.0) * 360;
            bufferCircle = new ol.geom.Circle(boomCoord, r, 'XY');
            analysisLyr.getSource().clear();
            var feature = new ol.Feature({
                    geometry:bufferCircle,
                    zIndex:i
                });
            feature.setStyle(new ol.style.Style({
                stroke: new ol.style.Stroke({
                    color: colors[i],
                    width: 10
                }),
                /*fill: new ol.style.Fill({
                    color: colors[i]
                })*/
            }));
            var polygon = ol.geom.Polygon.fromCircle(bufferCircle);
            var co=polygon.getCoordinates();
            co=co[0][Math.floor(co[0].length/4)];
            var label = new ol.Feature({
                geometry: new ol.geom.Point(co),
                zIndex: 500
            })
            label.setStyle(new ol.style.Style({
                text: new ol.style.Text({
                    font: '14px 微软雅黑',
                    fill: new ol.style.Fill({ color: 'black' }),
                    fill: new ol.style.Fill({ color: '#075db3' }),
                    // text: tempR+'米，浓度范围'+S*Per[i],
                    text: boomR + 'm',
                    rotation: 0,
                    offsetY: 20,
                    // textAlign: 'line'
                    textBaseline: 'bottom'
                })
            }));
            features.push(feature);
            features.push(label);
        }
        analysisLyr.getSource().addFeatures(features);
        mapContent.map.getView().fit(features[0].getGeometry().getExtent(), mapContent.map.getSize());
//        document.getElementById('result').innerHTML = '爆炸影响半径为：' + boomR + '米';
    }
    //清除分析模块
    function clearAnalysis() {
        $('.fundo').hide();
        if (analysisLyr || vectorLyr) {
            mapContent.map.removeLayer(analysisLyr);
            mapContent.map.removeLayer(vectorLyr);
            analysisLyr = null;
            vectorLyr = null;
        }
        //销毁毒气泄漏
        poison.destroy();
        //销毁火灾烟雾扩散
        fire.destroy();
        //销毁overlay
        mapContent.map.getOverlays().clear();
    }
    
    
       //用来回显标绘或者态势分析的数据
    function showBackData(type){
    	if(!layerConfig.emergencyId){
    		return;
    	}
    	$.get("/main/onemap/GetPlotList",{sgid:layerConfig.emergencyId,fl:type}).done(function(data){
    		//var obj=JSON.parse(data);
    		var wkt=new ol.format.WKT();
    		var features=data.map(function(val,index){
    			var feature=wkt.readFeature(val.geom);
    			feature.set("fl",val.fl);
    			feature.set("id",val.id);
    			feature.set("type",val.type);
    			feature.set("name",!val.name?"":val.name);
    			if(val.type==="wzbh"){
    				feature.set("labeltype","文字标绘");
    			}else if(val.type==="gzd"){
    				feature.set("labeltype","关注点");
    			}else if(val.type==="cjt"){
    				feature.set("labeltype","长箭头");
    			}else if(val.type==="zjt"){
    				feature.set("labeltype","直箭头");
    			}
    			
    			return feature;
    		});
    		mapContent.plotLayer.getSource().clear();
    		mapContent.plotLayer.getSource().addFeatures(features);
    	})
    }
    
    //对外放属性方法
    var obj = {
        //初始化绑定
        init: function() {
            //取消地图状态
            document.onkeydown = function(event) {
                var e = event || window.event || arguments.callee.caller.arguments[0];
                if (e && e.keyCode == 27) { // 按 Esc 
                    //清除绘制状态
                    mapContent.map.removeInteraction(plotDraw);
                    plotDraw = null;
                    mapContent.map.removeInteraction(selectInteraction);
                    selectInteraction.unByKey(selectKey);
                    modify.unByKey(modifyKey);
                }
            };
            // ui事件绑定
            // 一级事件绑定
            $('.first_item').click(function(e) {
                if ($(e.target).hasClass('yi_active')) {
                    $('.first_item').removeClass('yi_active');
                    // 二级全部收回
                    $('.yisonson').slideUp();
                    // 取消选中
                    $('.second_item').removeClass('ysonact');
                } else {
                    // 二级全部收回
                    $('.yisonson').slideUp();
                   // $('.first_item').removeClass('yi_active');
                    //取消其他选项
                    $('.first_item').each(function(index,ele){
                    	if($(ele).hasClass('yi_active')){
                    		$(ele).trigger("click");
                    	}
                    })
                    $(e.target).addClass('yi_active');
                    $(e.target).next('.yisonson').slideDown();
                    // 取消选中
                    $('.second_item').removeClass('ysonact');
                }
                //清除地图标绘模块
                clearDraw();
                //清除地图模拟分析
                clearAnalysis();
                
            })
            // 二级事件
            $('.second_item').click(function(e) {
                if ($(e.target).hasClass('ysonact')) { //选中状态，则取消选中
                    $('.second_item').removeClass('ysonact');
                    // 移除箭头
                    $(e.target).parent('li').siblings().removeClass('yingson');
                    // 三级全部收回
                    $(e.target).next('.yisonson').slideUp();
                    // 三级取消选中
                    $('.third_item').removeClass('ysonact');
                } else {
                    // 三级全部收回
                    $('.second_item').next('.yisonson').css("display","none");
                    $('.third_item').removeClass('ysonact');

                    $('.second_item').removeClass('ysonact');
                    $(e.target).addClass('ysonact');

                    // 移除其他箭头，添加箭头
                    $(e.target).parent('li').siblings().removeClass('yingson').addClass('yingson');
                    $(e.target).next('.yisonson').css("top",$(e.target).position().top);
                    $(e.target).next('.yisonson').slideDown();
                    if($(e.target).text()==="地图标绘"){
                    	showBackData("dtbh");
                    }else if($(e.target).text()==="态势分析"){
                    	showBackData("tsfx");
                    }
                }
                //清除地图标绘
                clearDraw();
                //清除地图模拟分析
                clearAnalysis();
            });
            //三级事件绑定
            $('.third_item').click(function(e) {
                $('.third_item').removeClass('ysonact');
                $(e.target).addClass('ysonact');
            });
            // 地图标绘功能绑定
            $('#mapPlot li').click(function(e) {
                operType = 'dtbh';
                callback(e);
            });
            // 地图标绘功能绑定
            $('#trendAnalysis li').click(function(e) {
                operType = 'tsfx';
                callback(e);
            });
            //模拟分析功能绑定
            $('#simulationAnalysis li').click(function(e) {
                var text = $(e.target).text();
                clearAnalysis();
                switch (text) {
                    case '爆炸':
                        if (analysisLyr || vectorLyr) return;
                        analysisLyr = new ol.layer.Vector({
                            source: new ol.source.Vector()
                        });
                        vectorLyr = new ol.layer.Vector({
                            source: new ol.source.Vector(),
                            style: new ol.style.Style({
                                image: new ol.style.RegularShape({
                                    fill: new ol.style.Fill({ color: "#ff0000" }),
                                    stroke: new ol.style.Stroke({
                                        width: 2,
                                        color: "#ff0000"
                                    }),
                                    points: 9,
                                    radius: 12,
                                    radius2: 4,
                                    angle: 0
                                })
                            })
                        });
                        mapContent.map.addLayer(analysisLyr);
                        mapContent.map.addLayer(vectorLyr);
                        //展开面板
                        //todo
                        $('.fundo').show();
                        $('.fundo').html(boomHtm);

                        $('#drawBoomPosition').click(function() {
                            drawBoomPosition();
                        });
                        $('#boomAnalysis').click(function() {
                            boomAnalysis();
                        });
                        break;
                    case '火灾':
                        fire.init();
                        break;
                    case '毒气泄漏':
                        poison.init();
                        break;
                    default:
                        break;

                }
            });

        }
    };
    return obj;
})