

require(["ol", "mapTools", "mapConfig", "turf.min"], function (ol, mapTools, mapConfig, turf) {


	//河北省界图层
	var hbsjLayer = new ol.layer.Tile({
		minResolution: 0.0013766455078125,
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "HBSJ/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=HBSJ&STYLE=HBSJ&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	//矢量地图
	var sl_dtLayer = new ol.layer.Tile({
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "sl_dt/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_dt&STYLE=sl_dt&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	//矢量地图标注
	var sl_zjLayer = new ol.layer.Tile({
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "sl_zj/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_zj&STYLE=sl_zj&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	var view = new ol.View({
		zoom: 7,
		center: [115.80688, 39.67163],
		projection: "EPSG:4326"
	});

	var vectorLayer = new ol.layer.Vector({
		source: new ol.source.Vector()
	});

	var map = new ol.Map({
		target: "map",
		layers: [sl_dtLayer, hbsjLayer, sl_zjLayer, vectorLayer],
		view: view,
		logo: false
	});


	//获得网页传过来的参数并返回对象
	function seriHref(href) {
		var arr = href.split("&"), obj = {};
		arr.map(function (val, index) {
			var vals = val.split("=");
			obj[vals[0]] = vals[1];
		});
		return obj;
	}


	//根据图层数字获得图层名称
	function getLayer(layerNumber) {
		var layerName = "";
		switch (layerNumber) {
			case "1129":
				layerName = "HBAJ:GEOM_YJZY_YJJYZB";//救援装备
				break;
			case "1128":
				layerName = "HBAJ:GEOM_YJYA_YJWZ";//物资
				break;
			case "1127":
				layerName = "HBAJ:GEOM_YJZY_YJJYDW";//救援队伍
				break;
		}

		return layerName;
	}



	var href = location.search.replace('?', '');
	var params = seriHref(href);
	//params.layer=getLayer(params.layer);

	view.setCenter([parseFloat(params.lon), parseFloat(params.lat)]);
	view.setZoom(12);










	var feature = new ol.Feature({
		geometry: new ol.geom.Point([parseFloat(params.lon), parseFloat(params.lat)])
	});

	vectorLayer.getSource().addFeature(feature);
	var distance = parseFloat(params.buffer) / map.getView().getProjection().getMetersPerUnit();
	var format = new ol.format.GeoJSON();
	var featureObj = format.writeFeatureObject(feature);
	var data = turf.buffer(featureObj, distance, "degrees");
	var circle = format.readFeature(data);
	vectorLayer.getSource().addFeature(circle);

	var wkt = new ol.format.WKT();
	var polygonStr = wkt.writeGeometry(circle.getGeometry());
	var componentUrl = "service=WFS&version=1.0.0&REQUEST=GetFeature&typeName=" + getLayer(params.layer) + "&srsName=EPSG:4326&outputFormat=application/json&CQL_FILTER=INTERSECTS(GEOM,";
	componentUrl += encodeURIComponent(polygonStr);
	componentUrl += ")";
	var url = mapConfig.bufferUrl + componentUrl;
	var style = new ol.style.Style({
		image: new ol.style.Circle({
			radius: 5,
			fill: new ol.style.Fill({
				color: "#ff0000"
			}),
			stroke: new ol.style.Stroke({
				color: "#00ff00",
				width: 1
			})
		})
	});

	var style2 = new ol.style.Style({
		image: new ol.style.Circle({
			radius: 5,
			fill: new ol.style.Fill({
				color: "#ffffff"
			}),
			stroke: new ol.style.Stroke({
				color: "#00ff00",
				width: 1
			})
		}),
		zIndex: 100
	});
	var ids = [], saveIds, zbs = [];
	$.post("/main/emer/getEmersourcetypeByEmersourceId", { id: params.id }, function (str) {
		var obj = JSON.parse(str);
		var selectIds = [];
		for (var j = 0, k = obj.length; j < k; j++) {
			selectIds.push(obj[j].id);
		}
		$.get(url, function (data) {
			var datas = data.features;
			if (data.features.length === 0) {
				layer.msg("该范围内没有数据");
			} else {
				var features = [];
				for (var i = 0, z = datas.length; i < z; i++) {
					var length = features.length;
					for (j = 0, k = selectIds.length; j < k; j++) {
						if (datas[i].id.split(".")[1] === selectIds[j]) {
							var feature = new ol.Feature({
								geometry: new ol.geom.Point(datas[i].geometry.coordinates),
								id: datas[i].id.split(".")[1],
								selected: false
							});
							feature.setStyle(style2);
							features.push(feature);
							ids.push(selectIds[j]);
							zbs.push(datas[i].geometry.coordinates);
							break;
						}
					}
					if (length === features.length) {
						var feature = new ol.Feature({
							geometry: new ol.geom.Point(datas[i].geometry.coordinates),
							id: datas[i].id.split(".")[1],
							selected: true
						});
						feature.setStyle(style);
						features.push(feature);
					}
				}
				vectorLayer.getSource().addFeatures(features);
			}
		});
	});


	var mapSel = new ol.interaction.Select({
		filter: function (f) {
			if (f.get('id')) {
				f.setStyle(style2);
				return true;
			} else {
				return false;
			}

		}
	});

	map.addInteraction(mapSel);
	mapSel.on("select", function (evt) {
		var selected = evt.selected[0];
		if (selected.get("selected") === true) {
			ids.push(selected.get("id"));
			zbs.push(selected.getGeometry().getCoordinates());
			selected.set("selected", false);
		} else {
			var slice;
			for (var i = 0, z = ids.length; i < z; i++) {
				if (ids[i] === selected.get("id")) {
					slice = i;
					break;
				}
			}
			zbs.splice(slice, 1);
			ids.splice(slice, 1);
			selected.setStyle(style);
			selected.set("selected", true);
		}
		mapSel.getFeatures().clear();
	});

	$("#save").click(function () {
		if (ids.length < 1) {
			layer.msg("请选择资源点");
			return;
		}

		saveIds = ids;
		var id = "", zb = "";
		for (var i = 0, z = ids.length; i < z; i++) {
			if (i === z - 1) {
				id = id + ids[i];
				zb = zb + zbs[i][0] + "+" + zbs[i][1];
			} else {
				id = id + ids[i] + ",";
				zb = zb + zbs[i][0] + "+" + zbs[i][1] + ",";
			}
		}
		console.log(zb);
		var obj = {
			pid: params.id,
			layer: params.layer,
			ids: id,
			zb: zb
		};
		$.post("/main/emer/emersourcetypesave", obj, function (data) {
			var parseStr = JSON.parse(data);
			if (parseStr.flag === true) {
				//关闭父窗口
				window.parent.closemap();
				layer.msg("提交成功");
			} else {
				layer.msg("提交失败");
			}
		});
	});
})