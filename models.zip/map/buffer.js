define(["ol", "turf.min", "initMap", "mapConfig","mapTools","layerConfig"], function (ol, turf, initMap, mapConfig,mapTools,layerConfig) {
    return {
        style: new ol.style.Style({
            fill: new ol.style.Fill({
                color: "rgba(0,250,154,0.2)"
            }),
            stroke: new ol.style.Stroke({
                color: "rgba(240,128,128,0.2)"
            })
        }),
        /**
		 * @api {类型 ol.format.GeoJSON} 用来把geojson对象转换为feature类型 format
		 * @apiSuccess (返回类型) {ol.format.GeoJSON} return 返回格式化geojson的ol.format.GeoJSON对象
		 * @apiName format 
		 * @apiGroup buffer
		 */
        format: new ol.format.GeoJSON(),
        /**
		 * @api {类型 function} 点|面缓冲区,本方法依赖turf.js buffer
		 * @apiParam {ol.Map} map 地图对象
		 * @apiParam {ol.layer.Vector} vector 矢量图层对象
		 * @apiParam {ol.interaction.Draw} drawInteraction 绘图交互工具
		 * @apiParam {ol.layer.Vector} layerNames 缓冲区搜索出来的结果所展示的图层
		 * @apiParam {Number} bufferDistance 缓冲区距离
		 * @apiParam {Booleans} isDecision 是否是决策支持的缓冲区分析
		 * @apiName buffer 
		 * @apiGroup buffer
		 */
        buffer: function (map, vector, drawInteraction, layerNames, bufferDistance,isDecision) {
            var that = this;
            map.addInteraction(drawInteraction);
            vector.clear();
            var key = drawInteraction.on("drawend", function (evt) {
                evt.feature.set("drawPoint", "point");
                var style = initMap.createStyle("rgba(239,250,250,0.5)", "rgba(252,0,0,0.6)", 3, 5);
                evt.feature.setStyle(style);

                //转换距离单位
                var juli = bufferDistance / map.getView().getProjection().getMetersPerUnit();

                //console.log(map.getView().getProjection().getMetersPerUnit());
                var format = that.format;
                var obj = format.writeFeatureObject(evt.feature);
                var data = turf.buffer(obj, juli, "degrees");
                var feature = format.readFeature(data);
                feature.setStyle(that.style);

                vector.addFeature(feature);
                var assembly = feature;
                assembly.getGeometry();


                var wkt = new ol.format.WKT();
                var polygonStr = wkt.writeGeometry(feature.getGeometry());
                var centerPoint=evt.feature.getGeometry().getType()==="Point"?evt.feature.getGeometry().getCoordinates():feature.getGeometry().getInteriorPoint().getCoordinates();
                if(isDecision){
                	that.decisionResult(polygonStr, vector, layerNames,centerPoint);
                }else{
                	that.strAssembly(polygonStr, vector, layerNames,centerPoint);
                }
                //查找在缓冲区范围内的数据
                
                
                assembly.getGeometry();
                drawInteraction.unByKey(key);
                map.removeInteraction(drawInteraction);
            });


        },
        /**
		 * @api {类型 function} 缓冲区分析用来查出范围内的点,并加载到地图上 distance
		 * @apiParam {Array} start 事故发生点
		 * @apiParam {Array} end 资源点
		 * @apiName distance 
		 * @apiGroup buffer
		 */
        distance:function(start,end){
        	var S2Plane=ol.proj.fromLonLat(start);
        	var E2Plane=ol.proj.fromLonLat(end);
        	var distance=Math.sqrt(Math.pow(S2Plane[0]-E2Plane[0],2)+Math.pow(E2Plane[0]-E2Plane[0],2)).toFixed(0);
        	return distance;
        },
        /**
		 * @api {类型 function} 对缓冲区结果进行过滤只显示符合过滤条件的数据 bufferFilter
		 * @apiParam {String} layerName 图层名称
		 * @apiParam {Array} features 缓冲区结果集
		 * @apiName bufferFilter 
		 * @apiGroup buffer
		 */
        bufferFilter:function(layerName,features){
        	var classify="",grade="",nFeatures=[];
        	switch(layerName){
        	case "GEOM_YJZY_YJJYDW"://救援队伍
        		var $div1=$("#decisionBufferSet .list-right div:eq(0) input:checked");
        		if($div1.length>0){
        			$div1.each(function(index,val){
        				classify=classify+val.getAttribute("code")+",";
                	});
        	}
        		var $div2=$("#decisionBufferSet .list-right div:eq(1) input:checked");
        		if($div2.length>0){
        			$div2.each(function(index,val){
        				grade=grade+val.getAttribute("code")+",";
                	});
        		}
        		var zj=classify+grade;
        		if(zj){
        			features.map(function(val,index){
            			if(zj.indexOf(val.get("DWSX"))>-1||zj.indexOf(val.get("FTYPE"))>-1){
            				nFeatures.push(val);
            			}
            		});
        		}else{
        			nFeatures=features;
        		}
        		break;
        	case "GEOM_YJZY_YJJYZB"://救援装备
        		if($("#decisionBufferSet .list-right input:checked").length>0){
            		$("#decisionBufferSet .list-right input:checked").each(function(index,val){
            			classify=classify+val.getAttribute("code").substring(0,2)+",";
                	});
        		}
        		if(classify){
        			features.map(function(val,index){
        				if(val.get("FTYPE")){
        					var str=(val.get("FTYPE")).toString();
                			if(classify.indexOf(str.substring(0,2))>-1){
                				nFeatures.push(val);
                			}
        				}
            		});
        		}else{
        			nFeatures=features;
        		}
        		break;
        	case "GEOM_YJYA_YJWZ"://救援物资
        		if($("#decisionBufferSet .list-right input:checked").length>0){
            		$("#decisionBufferSet .list-right input:checked").each(function(index,val){
            			classify=classify+val.getAttribute("code").substring(0,2)+",";
                	});
        		}
        		if(classify){
        			features.map(function(val,index){
        				if(val.get("FTYPE")){
        					var str=(val.get("FTYPE")).toString();
                			if(classify.indexOf(str.substring(0,2))>-1){
                				nFeatures.push(val);
                			}
        				}
            		});
        		}else{
        			nFeatures=features;
        		}
        		break;
        	    default:
        	    	nFeatures=features;
 /*       	case "GEOM_VB_TARGET"://救援物资
        		break;
        	case "GEOM_WXYHZB"://重大危险源
        		break;*/
        	}
        	return nFeatures;
        },
        /**
		 * @api {类型 function} 缓冲区分析用来查出范围内的点,并加载到地图上 strAssembly
		 * @apiParam {Array} polygonStr 缓冲区面的坐标数组
		 * @apiParam {ol.layer.Vector} vector 矢量图层对象
		 * @apiParam {ol.layer.Vector} layerNames 缓冲区搜索出来的结果所展示的图层
		 * @apiParam {Array} accidentPnt 事故点的经纬度坐标
		 * @apiName strAssembly 
		 * @apiGroup buffer
		 */
        decisionResult:function(polygonStr, vector, layerNames,accidentPnt){
        	console.log(layerNames);
        	var that=this;
        	var bufResult=[];
        	  if(layerNames){
        		  var $getChecked=$("#decisionBufferSet .list-right.fl"),otherCondition="",fl="",fj="",p3=[];
        		  $getChecked.find("input:checked").each(function(){
    				  p3.push($(this).attr("code"));
    				})
        		  switch(layerNames){
        		  case "GEOM_YJYA_YJWZ"://应急物资
        			  if(p3.length>0){
        				  otherCondition =" and FTYPE in("+p3.join(",")+")";
        			  }
        			  break;
        		  case "GEOM_YJZY_YJJYZB"://救援装备
        			  if(p3.length>0){
        				  otherCondition =" and FTYPE in("+p3.join(",")+")";
        			  }
        			  break;
        		  }
        		  if($getChecked.find("div").length===2){
        			  var p1=[],p2=[];
        			  $getChecked.find("div:first input:checked").each(function(){
        				  p1.push($(this).attr("code"));
        				})
        				
        			  if(p1.length>0){
        				  fl="DWSX in ("+p1.join(",")+")";
        				  otherCondition=" and "+fl;
        			  }
        				$getChecked.find("div:last input:checked").each(function(){
        				  p2.push($(this).attr("code"));
        				})
        				if(p2.length>0){
        					fj=" and FTYPE in ("+p2.join(",")+")";
        					otherCondition+=fj;
        				}
        				
        				
        		  }
        		  var dataStr="",url="";
        		 
        		  
        		  if(layerNames==="RKSJ"){
        			  var fformat=new ol.format.WKT();
            		  var wktFeature=fformat.readFeature(polygonStr);
            		  wktFeature.getGeometry().getCoordinates()[0].map(function(val,index){
            			  if(index===0){
            				  polygonStr="";
            				  polygonStr=val.join(",")+" ";
            			  }
            			  else if(index===wktFeature.getGeometry().getCoordinates()[0].length-1){
            				  polygonStr+=val.join(",");
            			  }else{
            				  polygonStr+=val.join(",");
                			  polygonStr+=" ";
            			  }
            			 
            		  });
            		  //url=url.toLowerCase();
            		  dataStr='<wfs:GetFeature xmlns:wfs="http://www.opengis.net/wfs" service="WFS" version="1.0.0"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.0.0/WFS-transaction.xsd"><wfs:Query typeName="CZ_RK_XIANG"><ogc:Filter xmlns:ogc="http://www.opengis.net/ogc"><ogc:Intersects><ogc:PropertyName>geometry</ogc:PropertyName><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="EPSG:4326"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates decimal="." cs="," ts=" ">'+polygonStr+'</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></ogc:Intersects></ogc:Filter></wfs:Query></wfs:GetFeature>';
            		  
            		  //polygonStr="116.74653857421,38.413050048828 116.62431567382,38.198816650391 116.88661425781,38.131525390625 117.06239550781,38.218042724609 117.02394335937,38.42815625 116.74653857421,38.413050048828";
        			 // url='/tdt/CZ_RK_XIANG/wfs?'
        			     //+'<wfs:GetFeature xmlns:wfs="http://www.opengis.net/wfs" service="WFS" version="1.0.0"  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.0.0/WFS-transaction.xsd"><wfs:Query typeName="CZ_RK_XIANG"><ogc:Filter xmlns:ogc="http://www.opengis.net/ogc"><ogc:Intersects><ogc:PropertyName>geometry</ogc:PropertyName><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="EPSG:4326"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates decimal="." cs="," ts=" ">'+polygonStr+'</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></ogc:Intersects></ogc:Filter></wfs:Query></wfs:GetFeature>'
        			    // +'<wfs:GetFeature xmlns:wfs="http://www.opengis.net/wfs" service="WFS" version="1.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.0.0/WFS-transaction.xsd"><wfs:Query typeName="CZ_RK_XIANG"><ogc:Filter xmlns:ogc="http://www.opengis.net/ogc"><ogc:Intersects><ogc:PropertyName>geometry</ogc:PropertyName><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="EPSG:4326"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates decimal="." cs="," ts=" ">'+polygonStr+'</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></ogc:Intersects></ogc:Filter></wfs:Query></wfs:GetFeature>';
        		  }else{
        			  dataStr = "service=WFS&version=1.0.0&REQUEST=GetFeature&typeName=HBAJ:" + layerNames + "&srsName=EPSG:4326&outputFormat=application/json&CQL_FILTER=INTERSECTS(GEOM,";
                      dataStr += encodeURIComponent(polygonStr);
                      dataStr += encodeURIComponent(") and ");
                      dataStr +=encodeURIComponent(mapConfig.userFilters.split("=")[1]);
                      dataStr +=encodeURIComponent(otherCondition);
                      url = mapConfig.bufferUrl + dataStr;
        		  }
        		  
        		  
                   if(layerNames==="RKSJ"){
                	   $.ajax({
                			 url:"/tdt/CZ_RK_XIANG/wfs?",
                			 data:dataStr,
                			 type:"POST",
                			 contentType:"application/json;charset=UTF-8",
                			 beforeSend:function(request){
                				request.setRequestHeader("Content-Type","application/xml");
                			 }
                		 }).then(function(data){
                			 var gml=new ol.format.GML2();
               				features=gml.readFeatures(data);
               			    vector.addFeatures(features);
               			 var html='<ul class="am-list am-list-static">';
                         features.map(function(val,index){
                      	     var gid=val.get("RKSHJ");
                      	     var xy=val.getGeometry().getCoordinates(),name=null;
                      	     var name=val.get("NAME");
                      	     html+='<li style="margin-left:15px;padding:0px 0px;"><button class="am-badge am-badge-success" style="margin-top: 14px;">添加</button> <button class="am-badge am-badge-danger" style="margin-top: 14px;">移除</button><a x="'+xy[0]+'" y="'+xy[1]+'" href="#" style="width:150px;" title="'+name+'" class="am-text-truncate" gid='+gid+'><span>'+name+'</span></a><span style="position:absolute;top:12px;left:154px;">'+gid+'人</span></li>';
                         });
                         html+='</ul>';
                         layer.open({
                      	   content:html,
                      	   type:1,
                      	   title:"分析结果",
                      	   area:["400px","300px"],
                      	   shade:0,
                      	   offset:"r",
                      	   success:function(layero,index){
                      		   $(layero).find(".layui-layer-content a").hover(function(){
                      			   for(var j=0,k=features.length;j<k;j++){
                      			    	  if(features[j].getId().split(".")[1]===$(this).attr("gid")){
                      			    		  features[j].set("hasStyle",true);
                      			    		  features[j].setStyle( new ol.style.Style({
                      			    			  image:new ol.style.Circle({
                       			    				  radius:6,
                       			    				  fill:new ol.style.Fill({
                       			    					  color:"#ffff00"
                       			    				  }),
                       			    				  stroke:new ol.style.Stroke({
                       			    					  color:"#ff0000",
                       			    					  width:2
                       			    				  })
                       			    			  }),
                       			    			 zIndex:150
                      						}));
                      			    		  break;
                      			    	  }
                      			   }
                      		   },function(){
                      			   for(var j=0,k=features.length;j<k;j++){
                   			    		  features[j].setStyle(new ol.style.Style({
                   			    			 image: new ol.style.Circle({
                   								radius: 4,
                   								fill: new ol.style.Fill({
                   									color: "#FFCC99"
                   								}),
                   								stroke: new ol.style.Stroke({
                   									color: "#FFFFFF",
                   									width: 1
                   								})
                   							})
                   			    		  }));
                   			   }
                      		   }); 
                      		   $(layero).find(".layui-layer-content button").click(function(evt){
                		    	   var target=evt.target.parentNode.getElementsByTagName("A")[0];
                		    	   var id=evt.target.parentNode.getElementsByTagName("A")[0].getAttribute("gid");
                		    	   var name=evt.target.parentNode.getElementsByTagName("A")[0].getAttribute("title");
                		    	   if(evt.target.textContent==="添加"){
                		    		   if(!layerConfig.emergencyId){
                		    			   layer.msg("不能进行保存，没有和相应的响应对照");
                		    			   return;
                		    		   }
                		    		   var x=(parseFloat(target.getAttribute("x"))).toFixed(5),
                		    		   y=(parseFloat(target.getAttribute("y"))).toFixed(5);
                		    		   var tbLayer="RLZY_DP";
                		    		   $.post("/main/onemap/DecisionBufferRk",{tb:tbLayer,sgid:layerConfig.emergencyId,name:name,num:id,distance:that.distance(accidentPnt,[x,y]),position:"["+x+","+y+"]"}).done(function(data){
                		    			   if(data==="1"){
                		    				   layer.msg("添加成功");
                		    			   }else{
                		    				   layer.msg("添加失败");
                		    			   }
                		    		   })
                		    	   }else{
                		    		   if(!layerConfig.emergencyId){
                		    			   layer.msg("不能进行移除，没有和相应的响应对照");
                		    			   return;
                		    		   }
                		    		   $.post("/main/onemap/DecisionBufferDel",{sgid:layerConfig.emergencyId,jhdid:name,tb:"RLZY_DP"}).done(function(data){
                		    			   if(data==="1"){
                		    				   layer.msg("移除成功");
                		    			   }else{
                		    				   layer.msg("移除失败");
                		    			   }
                		    		   })
                		    	   }
                		     });
                	   }
                   })
               			    
                		 },function(){
                			 console.erro("人口数据获取数据失败！");
                		 });
                	   return;
                   }
              	 //var url = mapConfig.bufferUrl + dataStr;
              		 $.get(url).done(function(data){
              			 var features=null;
              				var json = new ol.format.GeoJSON();
              				features = that.bufferFilter(layerNames,json.readFeatures(data));
                           if (features.length>0) {
                               vector.addFeatures(features);
                               var html='<ul class="am-list am-list-static">';
                               features.map(function(val,index){
                            	     var gid=val.getId().split(".")[1];
                            	     var xy=val.getGeometry().getCoordinates(),name=null;
                            	     switch(layerNames){
                            	     case "GEOM_YJYA_YJWZ"://物资
                            	    	 name=val.get("WZMC");
                            	    	 break;
                            	     case "GEOM_YJZY_YJJYZB"://装备
                            	    	 name=val.get("ZBMC");
                            	    	 break;
                            	     case "GEOM_YJZY_YJJYDW"://队伍
                            	    	 name=val.get("DWMC");
                            	    	 break;
                            	     case "GEOM_WXYHZB"://重大危险源
                            	    	 name=val.get("WXYMC");
                            	    	 break;
                            	     case "GEOM_VB_TARGET"://脆弱性目标
                            	    	 name=val.get("CRXMBMC");
                            	    	 break;
                            	     case "GEOM_RISK_POINT"://风险点
                            	    	 name=val.get("FXDMC");
                            	    	 break;
                            	     case "GEOM_RISK_POINT"://风险点
                            	    	 name=val.get("NAME");
                            	    	 break;
                            	     }
                            	    // html+="<li gid='"+gid+"'>"+val.get("DWMC")+"</p>";
                            	     html+='<li style="margin-left:15px;padding:0px 0px;"><button class="am-badge am-badge-success" style="margin-top: 14px;">添加</button> <button class="am-badge am-badge-danger" style="margin-top: 14px;">移除</button><a x="'+xy[0]+'" y="'+xy[1]+'" href="#" style="width:150px;" title="'+name+'" class="am-text-truncate" gid='+gid+'><span>'+name+'</span></a></li>';
                               });
                               html+='</ul>'
                               layer.open({
                            	   content:html,
                            	   type:1,
                            	   title:"分析结果",
                            	   area:["400px","300px"],
                            	   shade:0,
                            	   offset:"r",
                            	   success:function(layero,index){
                            		   $(layero).find(".layui-layer-content a").hover(function(){
                            			   for(var j=0,k=features.length;j<k;j++){
                            			    	  if(features[j].getId().split(".")[1]===$(this).attr("gid")){
                            			    		  features[j].set("hasStyle",true);
                            			    		  features[j].setStyle( new ol.style.Style({
                            			    			  image:new ol.style.Circle({
                             			    				  radius:6,
                             			    				  fill:new ol.style.Fill({
                             			    					  color:"#ffff00"
                             			    				  }),
                             			    				  stroke:new ol.style.Stroke({
                             			    					  color:"#ff0000",
                             			    					  width:2
                             			    				  })
                             			    			  }),
                             			    			 zIndex:150
                            						}));
                            			    		  break;
                            			    	  }
                            			   }
                            		   },function(){
                            			   for(var j=0,k=features.length;j<k;j++){
                         			    	  //if(features[j].getId().split(".")[1]===$(this).attr("gid")){
                         			    		 // features[j].set("hasStyle",true);
                         			    		  features[j].setStyle(new ol.style.Style({
                         			    			 image: new ol.style.Circle({
                         								radius: 4,
                         								fill: new ol.style.Fill({
                         									color: "#FFCC99"
                         								}),
                         								stroke: new ol.style.Stroke({
                         									color: "#FFFFFF",
                         									width: 1
                         								})
                         							})
                         			    		  }));
                         			    		//  break;
                         			    	 // }
                         			   }
                            		   });
                            		     $(layero).find(".layui-layer-content button").click(function(evt){
                            		    	   var target=evt.target.parentNode.getElementsByTagName("A")[0];
                            		    	   var id=evt.target.parentNode.getElementsByTagName("A")[0].getAttribute("gid");
                            		    	   if(evt.target.textContent==="添加"){
                            		    		   if(!layerConfig.emergencyId){
                            		    			   layer.msg("不能进行保存，没有和相应的响应对照");
                            		    			   return;
                            		    		   }
                            		    		   var x=(parseFloat(target.getAttribute("x"))).toFixed(5),
                            		    		   y=(parseFloat(target.getAttribute("y"))).toFixed(5);
                            		    		   var tbLayer="";
                            		    		   switch(layerNames){
                            		    		   case "GEOM_YJZY_YJJYZB": //装备
                            		    			   tbLayer="EQUIP_DISTRIBUTING";
                            		    			   break;
                            		    		   case "GEOM_YJZY_YJJYDW":    //队伍
                            		    			   tbLayer="AMBULANCE_DISTRIBUTING";
                            		    			   break;
                            		    		   case "GEOM_YJYA_YJWZ":    //物资
                            		    			   tbLayer="MATERIAL_DISTRIBUTING";
                            		    			   break;
                            		    		   }
                            		    		   $.post("/main/onemap/DecisionBuffer",{tb:tbLayer,sgid:layerConfig.emergencyId,jhdid:id,distance:that.distance(accidentPnt,[x,y]),position:"["+x+","+y+"]"}).done(function(data){
                            		    			   if(data==="1"){
                            		    				   layer.msg("添加成功");
                            		    			   }else{
                            		    				   layer.msg("添加失败");
                            		    			   }
                            		    		   })
                            		    	   }else{
                            		    		   if(!layerConfig.emergencyId){
                            		    			   layer.msg("不能进行移除，没有和相应的响应对照");
                            		    			   return;
                            		    		   }
                            		    		   $.post("/main/onemap/DecisionBufferDel",{sgid:layerConfig.emergencyId,jhdid:id,tb:layerNames}).done(function(data){
                            		    			   if(data==="1"){
                            		    				   layer.msg("移除成功");
                            		    			   }else{
                            		    				   layer.msg("移除失败");
                            		    			   }
                            		    		   })
                            		    	   }
                            		     });
                            	   }
                               })
                           }else{
                        	   layer.msg("此范围内没有查找到数据");
                           }
                       }).fail(function(){
                       	console.error("获取数据失败");
                       });
        	  }else{
        		  
        	  }
        },
        /**
		 * @api {类型 function} 缓冲区分析用来查出范围内的点,并加载到地图上 strAssembly
		 * @apiParam {Array} polygonStr 缓冲区面的坐标数组
		 * @apiParam {ol.layer.Vector} vector 矢量图层对象
		 * @apiParam {ol.layer.Vector} layerNames 缓冲区搜索出来的结果所展示的图层
		 * @apiParam {Array} accidentPnt 事故点的经纬度坐标
		 * @apiName strAssembly 
		 * @apiGroup buffer
		 */
        strAssembly: function (polygonStr, vector, layerNames,accidentPnt) {
        	var that=this;
        	var index = layer.load();
            //var layerStr = layerNames.join(",");
            var bufResult=[],codes=[],total,count=0;
            $("#fieldPoi input:checked").each(function (index, element) {
                codes.push($(this).attr("code"));
            });
            total=layerNames.length+codes.length;//统计总计有多少个图层参与请求数据
            var deferred=$.Deferred();
            deferred.done(function(data){
            	layer.close(index);
            	if(data.length===0){
  				  layer.msg("此范围内没有数据！");
  				  return;
  			  }
            	layer.open({
            		  type: 1,
            		  title: false,
            		  closeBtn:1,
            		  title:"分析结果",
            		  shadeClose: false,
            		  shade:0,
            		  resize:false,
            		  content: "<div id='bufferResult' class='buffer'></div>",
            		  area:["300px","300px"],
            		  success:function(layero,index){
            			  var $layero=$("#bufferResult").append("<ul></ul>").find("ul");
            			  for(var j=0,k=data.length;j<k;j++){
            				  $layero.append("<li><span>"+data[j].name+"</span>共计:<strong>"+data[j].length+"</strong></li>");
            			  }
            			  
            			  var twoIndex;
            			  $("#bufferResult ul").click(function(evt){
            				  var $target=$(evt.target).prop("tagName")==="SPAN"||$(evt.target).prop("tagName")==="STRONG"?$(evt.target).parent():$(evt.target);
            				  if($target.prop("tagName")==="LI"){
            					  for(var p=0,q=data.length;p<q;p++){
            						  if($target.find("span").text()==data[p].name){
                						  !twoIndex?"":layer.close(twoIndex);
            							  var width=(document.body.clientWidth/2+200).toString()+"px";
            							  var height=(document.body.clientHeight/2-150).toString()+"px";
            							  twoIndex=layer.open({
                							  type:1,
                							  title:data[p].name,
                							  closeBtn:1,
                							  shade:0,
                							  content: "<div id='bufferPart' class='bufferPart'></div>",
                		            		  area:["400px","300px"],
                		            		  offset: [height,width],
                		            		  success:function(layero,index){
                		            			  var $bufPart=$(".bufferPart").append("<ul></ul>").find("ul");
                		            			  var targetObj=data[p].data,sortTarget=[];
                		            			  for(var i=0,j=targetObj.length;i<j;i++){
                		            				  var distance=that.distance(accidentPnt,targetObj[i].getGeometry().getCoordinates());
                		            				  targetObj[i].set("distance",distance);
                		            				  sortTarget.push(targetObj[i]);
                		            			  }
                		            			  sortTarget.sort(function(a,b){
                		            				  return a.get("distance")-b.get("distance");
                		            			  });
                		            			  $(sortTarget).each(function(index,ele){
                		            				  var targetName="";
                		            				  switch(true){
                		            				  case !!ele.get("name"):
                		            					  targetName=ele.get("name");
                		            					  break;
                		            				  case !!ele.get("QYMC"):
                		            					  targetName=ele.get("QYMC");
            		            					     break;
                		            				  case !!ele.get("WZMC"):
                		            					  targetName=ele.get("WZMC");
                		            					  break;
                		            				  case !!ele.get("NAME"):
                		            					  targetName=ele.get("NAME");
                		            					  break;
                		            				  case !!ele.get("WKKMC"):
                		            					  targetName=ele.get("WKKMC");
                		            					  break;
                		            				  case !!ele.get("ZBMC"):
                		            					  targetName=ele.get("ZBMC");
                		            					  break;
                		            				  case !!ele.get("DWMC"):
                		            					  targetName=ele.get("DWMC");
                		            					  break;
                		            				  case !!ele.get("DWMC"):
                		            					  targetName=ele.get("DWMC");
                		            					  break;
                		            				  case !!ele.get("YHMC"):
                		            					  targetName=ele.get("YHMC");
                		            					  break;
                		            				  case !!ele.get("CRXMBMC")://脆弱性目标
                		            					  targetName=ele.get("CRXMBMC");
                	                            	    	 break;
                	                            	     case !!ele.get("FXDMC")://风险点
                	                            	    	 targetName=ele.get("FXDMC");
                	                            	    	 break;
                		            				  }
                		            				  if(!!targetName){
														  var xq=(data[p].name === "应急物资" || data[p].name === "救援装备" || data[p].name === "救援队伍")?"<span class='particilar'>详情</span></li>":"";
														  var id=!!ele.getId()?ele.getId().split(".")[1]:"";
														  var distance=ele.get("distance")>1000?(ele.get("distance")/1000).toString()+"千":ele.get("distance");
														  $bufPart.append("<li jyid='"+id+"' position='"+ele.getGeometry().getCoordinates().join(",")+"'> <span class='jianjie' title='"+targetName+"'>"+targetName+"</span> <span class='juli'>距离为:"+distance+"米</span> "+xq);
                		            				  }
                		            				 
                		            			  });
												  
												  var UseLayer={"应急物资":"/main/yjyabasqbManager/getYjWzListForMap","救援装备":"/main/yjzyManager/jyzbMapOpen","救援队伍":"/main/yjzyManager/jydwMapOpen"}
												  $bufPart.click(function (e) {
													  var $target = $(e.target);
													  if (data[p].name === "应急物资" || data[p].name === "救援装备" || data[p].name === "救援队伍") {
														 
														  if($target.hasClass("juli")){
															//点击距离跳转到高德导航页面
																window.open("/main/onemap/gaode?start=" + accidentPnt.join(",") + "&end=" + $target.parent().attr("position"));
														  }
														  else if($target.hasClass("particilar"))
														  {
															var getUrl = UseLayer[data[p].name];
															$.post(getUrl+"?ids="+$target.parent().attr("jyid")).done(function(data){
																var objs=JSON.parse(data);
																if(objs.length!==1){
																	   layer.msg("打开详情页失败!");
                                                                       return;
																}
																mapTools.openDetail(objs[0].url, objs[0].type, objs[0].width, objs[0].height, objs[0].title, false);
															})
														  }
														  else if($target.hasClass("jianjie")){
															  if($target.parent().find("div").get(0)){
																$target.parent().find("div").stop(true).slideUp("fast",function(){
                                                                        $(this).remove();
																});
																	return;
															  }
															$target.parent().parent().find("div").stop(true).slideUp("fast",function(){
																$(this).remove();
														    });
															var num,phone,phone;
															switch (data[p].name) {
																case "应急物资":
																	if ($target.hasClass("jianjie")) {//点击名称显示该条信息的简介
																		$.post("/main/yjzyManager/jywzDataMapOpen?id=" + $target.parent().attr("jyid")).done(function (data) {
																			var obj = JSON.parse(data);
																			num=obj.num?obj.num:"未知";
																			type=obj.type?obj.type:"未知";
																			phone=obj.phone?obj.phone:"未知";
																			var ssdw=obj.ssdw?obj.ssdw:"未知";
																			$target.parent().append("<div class='details' style='display:none'></div>").find("div").append("所属单位:" + ssdw + " 数量:" + num + " <br/>保管人联系方式:" + phone).slideDown("fast");
																		}).fail(function(){
																			layer.msg("获取数据失败,请再次点击!");
																		});
																	}
																	break;
																case "救援装备":
																	if ( $target.hasClass("jianjie")) {//点击名称显示该条信息的简介
																		$.post("/main/yjzyManager/jyzbDataMapOpen?id=" + $target.parent().attr("jyid")).done(function (data) {
																			var obj = JSON.parse(data);
																			num=obj.num?obj.num:"未知";
																			type=obj.type?obj.type:"未知";
																			phone=obj.phone?obj.phone:"未知";
																			$target.parent().append("<div class='details' style='display:none'></div>").find("div").append("装备类别:" + type + " 数量:" + num + " <br/>保管人联系方式:" +phone).slideDown("fast");
																		}).fail(function(){
																		  layer.msg("获取数据失败,请再次点击!");
																	  });
																	}
																	break;
																case "救援队伍":
																	if ($target.hasClass("jianjie")) {//点击名称显示该条信息的简介
																		$.post("/main/yjzyManager/jydwDataMapOpen?id=" + $target.parent().attr("jyid")).done(function (data) {
																			var obj = JSON.parse(data);
																			num=obj.num?obj.num:"未知";
																			type=obj.type?obj.type:"未知";
																			phone=obj.phone?obj.phone:"未知";
																			$target.parent().append("<div class='details' style='display:none'></div>").find("div").append("队伍类型:" + type + " 人数:" + num + " <br/>负责人电话:" + phone).slideDown("fast");
																		}).fail(function(){
																		  layer.msg("获取数据失败,请再次点击!");
																	  });
																	}
																	break;
															}
														  }
														 

													  } else {
														  if ($target.hasClass("juli")) {
															  window.open("/main/onemap/gaode?start=" + $target.parent().attr("position") + "&end=" + accidentPnt.join(","));
														  }
													  }
												  });
                		            			  
                		            		  }
                						  })
                						  break;
                					  }
            					  }
            					  
            				  }
            			  });
            		  }
            		});
            	
            });
           
            for(var i=0,z=layerNames.length;i<z;i++){
            	var dataStr = "service=WFS&version=1.0.0&REQUEST=GetFeature&typeName=" + layerNames[i] + "&srsName=EPSG:4326&outputFormat=application/json&CQL_FILTER=INTERSECTS(GEOM,";
                dataStr += encodeURIComponent(polygonStr);
                dataStr += encodeURIComponent(") and ");
                dataStr +=encodeURIComponent(mapConfig.userFilters.split("=")[1]);
            	 var ss = mapConfig.bufferUrl + dataStr;
            	 (function(lyName,url){
            		 $.get(url).done(function(data){
                     	var json = new ol.format.GeoJSON();
                     	count++;
                         if (data.features) {
                             var features = json.readFeatures(data);
                             vector.addFeatures(features);
                             var obj={
                             		name:$("[ly="+lyName.split(":")[1]+"]").text(),
                             		length:features.length,
                             		data:features
                             }
                             features.length!==0?bufResult.push(obj):"";
                         }
                         count===total?deferred.resolve(bufResult):"";
                     }).fail(function(){
                     	console.log("获取数据失败");
                     });
            	 })(layerNames[i],ss)
            	
            }
            
            //天地图热点查询
            var polygon = polygonStr.split("((")[1].split(")")[0].split(",");
            var poiPolygon = "";
            for (var m = 0, n = polygon.length; m < n; m++) {
                polygon[m].split(" ");
                poiPolygon += polygon[m].split(" ")[0].slice(0, 9);
                poiPolygon += ",";
                poiPolygon += polygon[m].split(" ")[1].slice(0, 9);
                if (m !== n - 1) {
                    poiPolygon += ",";
                }
            }
            
            if (codes.length !== 0) {
            	/*var style=new ol.style.Style({
            		image:new ol.style.Circle({
            			radius:4,
            			fill:new ol.style.Fill({
            				color:"#FFCC99"
            			}),
            			stroke:new ol.style.Stroke({
            				color:"#FFFFFF",
            				width:1
            			})
            		})
            	});*/
            	
                for (var j = 0, k = codes.length; j < k; j++) {
                    var url = mapConfig.poiUrl + "output=json&request=GeoCoder&maxCount=9000&service=GeoCoding&categoryCode=" + codes[j] + "&bbox=" + poiPolygon;
                    (function(code,url){
                    	$.ajax({
                            type: "GET",
                            url: url,
                            dataType: "jsonp",
                            jsonp: "callback",
                            contentType: 'text/xml',
                            success: function (json) {
                            	count++;
                                var data = json.results[0].result;
                                var features = [];
                                for (var i = 0, z = data.length; i < z; i++) {
                                    var feature = new ol.Feature({
                                        geometry: new ol.geom.Point([data[i].poiArray[0].location.lng, data[i].poiArray[0].location.lat]),
                                        name: data[i].poiArray[0].name,
                                        //id:i.toString()
                                    });
                                    features.push(feature);
                                }
                                var obj={
                                		name:$("#mapBufferSet [code="+code+"]").parent().text(),
                                		length:features.length,
                                		data:features
                                }
                                
                                vector.addFeatures(features);
                                features.length!==0?bufResult.push(obj):"";
                                count===total?deferred.resolve(bufResult):"";
                                
                            },
                            error: function (e) {
                                layer.msg("查询失败");
                            },
                            context: this
                        });
                    })(codes[j],url)
                }
            }


        }
    }
});