define(["mapConfig"],function (mapConfig) {
    /**
     * 本文档用来保存对多个图层进行判断的方法
     */
    /**
       * @api {类型 function} 根据图层名称显示不同的概要信息 getInfo
       * @apiParam {String} layerName 专题图图层名称
       * @apiParam {obj} data 该条数据概要信息
       * 
       * @apiName getInfo 
       * @apiGroup judge
       */
    function getInfo(layerName, data, dom) {
    	dom.style.height="108px";
        var details="<p><span style='position:absolute;right: 11px;text-decoration: underline;color:#0066cc;font-weight:normal;cursor:pointer;'>查看详情</span></p>";
        if(!!data.length){
            for (var i = 0, z = data.length; i < z; i++) {
                switch (layerName) {
                    case "GEOM_WXYHZB"://重大危险源
                        dom.innerHTML = "<p title='"+data[i].name+"'><span>重大危险源名称:</span>" + data[i].name + "</p><p><span>重大危险源级别:</span>" + data[i].grade + "</p><p><span>企业名称:</span>" + data[i].qymc + "</p><p style='display:inline-flex;'><span>类别:</span><i>" + data[i].type +"</i></p>"+details;
                        break;
                    case "GEOM_SGBS":  //事故
                        dom.innerHTML = "<p title='"+data[i].title+"'><span>事故标题:</span>" + data[i].title + "</p><p><span>事故等级:</span>" + data[i].grade + "</p><p><span>企业名称:</span>" + data[i].name + "</p><p style='display:inline-flex;'><span>地点:</span><i title='"+data[i].address+"'>" + data[i].address+"</i></p>"+details;
                        break;
                    case "GEOM_DYJYA_BASQB":  //应急预案
                        dom.innerHTML = "<p title='"+data[i].name+"'><span>企业名称:</span>" + data[i].name + "</p><p><span>备案部门:</span>" + data[i].babm + "</p><p style='display:inline-flex;'><span>备案编号:</span>" + data[i].babh + "</p>"+details;
                        dom.style.height="91px";
                        break;
                    case "GEOM_SPECIAL":  //专项检查
                        dom.innerHTML = "<p title='"+data[i].jcbm+"'><span>检查部门:</span>" + data[i].jcbm + "</p><p><span>检查时间:</span>" + data[i].jcsj + "</p><p style='display:inline-flex;'><span>检查名称:</span><i title='"+data[i].name+"'>" + data[i].name +"</i></p>"+details;
                        dom.style.height="91px";
                        break;
                    case "GEOM_SUPERVISION":  //监管监察
                        dom.innerHTML = "<p title='"+data[i].name+"'><span>企业名称:</span>" + data[i].name + "</p><p><span>检查时间:</span>" + data[i].jcsj + "</p><p style='display:inline-flex;'><span>检查部门:</span><i title='"+data[i].jcbm+"'>" + data[i].jcbm +"</i></p>"+details;
                        break;
                    case "GEOM_WKK":     //尾矿库
                        dom.innerHTML = "<p title='"+data[i].name+"'><span>尾矿库名称:</span>" + data[i].name + "</p><p><span>等级:</span>" + data[i].grade + "</p><p style='display:inline-flex;'><span>地址:</span><i>" + data[i].address +"</i></p>"+details;
                        break;
                    case "GEOM_ZYBWH":  //职业病危害
                        dom.innerHTML = "<p title='"+data[i].name+"'><span>企业名称:</span>" + data[i].name + "</p><p><span>等级:</span>" + data[i].grade + "</p><p style='display:inline-flex;'><span>安监行业:</span>" + data[i].type +"</p>"+details;
                        dom.style.height="91px";
                        break;
                    case "GEOM_STANDARD":  //标准化
                        dom.innerHTML = "<p title='"+data[i].name+"'><span>企业名称:</span>" + data[i].name + "</p><p><span>等级:</span>" + data[i].grade + "</p><p><span>证书编号:</span>" + data[i].zsbh + "</p><p style='display:inline-flex;'><span>运行状态:</span>" + data[i].yxzt + "</p>"+details;
                        break;
                    case "GEOM_EMERG_RESPONSE":  //应急响应
                        dom.innerHTML = "<p title='"+data[i].name+"'><span>名称:</span>" + data[i].name + "</p><p><span>等级:</span>" + data[i].grade + "</p><p><span>时间:</span>" + data[i].time  + "</p>"+details;
                        break;
                    case "GEOM_HON_CHMAIN":  //诚信企业
                        dom.innerHTML = "<p title='"+data[i].name+"'><span>企业名称:</span>" + data[i].name + "</p><p><span>等级:</span>" + data[i].grade + "</p><p><span>证书编号:</span>" + data[i].zsbh + "</p><p><span>时间:</span>" + data[i].yxq  + "</p>"+details;
                        break;
                }
            }
        }else{
            switch(layerName){
                case "GEOM_Danger_Report": //隐患排查
                dom.innerHTML = "<p><span>隐患名称：</span>" + data.name + "</p><p><span>企业名称：</span>" + data.qymc + "</p><p><span>所在地：</span>" + data.address + "</p><p style='display:inline-flex;'><span>级别：</span>" + data.grade + "</p>"+details;
                break;
                case "GEOM_YJYA_YJWZ":   //应急物资
                dom.innerHTML = "<p><span>物资名称：</span>" + data.name + "</p><p><span>所属单位名称：</span>" + data.ssdw + "</p><p><span>联系人电话：</span>" + data.phone + "</p><p style='display:inline-flex;'><span>数量：</span>" + data.amout +"</p>"+details;
                break;
                case "GEOM_YJZY_YJJYDW":  //救援队伍
                dom.innerHTML = "<p><span>救护队名称：</span>" + data.name + "</p><p><span>救护队类型：</span>" + data.type + "</p><p><span>联系人电话：</span>" + data.phone + "</p><p style='display:inline-flex;'><span>人数：</span>" + data.amout + "</p>"+details;
                break;
                case "GEOM_YJZY_YJJYZB":  //救援装备
                dom.innerHTML = "<p><span>装备名称：</span>" + data.name + "</p><p><span>所属企业：</span>" + data.ssdw + "</p><p><span>联系电话：</span>" + data.phone + "</p><p><span>装备数量：</span>" + data.amout + "</p><p style='display:inline-flex;'><span>物资所属单位分类：</span>" + data.zbtype +"</p>"+details;
                break;
                case "GEOM_LAWINFO_PLAN":  //执法监察
                    dom.innerHTML = "<p title='"+data.name+"'><span>案件名称:</span>" + data.name + "</p><p><span>立案时间:</span>" + data.date + "</p><p style='display:inline-flex;'><span>部门立案号:</span><i title='"+data.code+"'>" + data.code +"</i>"+ "</p>"+details;
                    dom.style.height="91px";
                    break;
                case "GEOM_ZJJG":  //中介机构
                    dom.innerHTML = "<p title='"+data.name+"'><span>机构名称:</span>" + data.name + "</p><p><span>等级:</span>" + data.grade + "</p><p style='display:inline-flex;'><span>类型:</span>" + data.type + "</p>"+details;
                    break;
                case "GEOM_RISK_POINT":  //风险点
                    dom.innerHTML = "<p title='"+data.name+"'><span>风险点名称:</span>" + data.name + "</p><p><span>日期:</span>" + data.date + "</p><p style='display:inline-flex;'><span>所属企业:</span>" + data.qyname + "</p>"+details;
                    dom.style.height="91px";
                    break;
                case "GEOM_VB_TARGET":  //脆弱性目标
                    dom.innerHTML = "<p title='"+data.name+"'><span>脆弱性目标名称:</span>" + data.name + "</p><p><span>日期:</span>" + data.date + "</p><p style='display:inline-flex;'><span>所属企业:</span>" + data.qyname + "</p>"+details;
                    dom.style.height="91px";
                    break;
            }
        }
       
    }
    
    
    /**
     * @api {类型 function} 对不同图层进行过滤 updateLayers
     * @apiParam {String} layerName 专题图图层名称
     * @apiParam {ol.layer.Vector} layer 该图层对象
     * @apiParam {String} filter 图层过滤条件
     * @apiName updateLayers 
     * @apiGroup judge
     */
    function updateLayers(layerName,layer,filter){
    
    	var original=mapConfig.userFilters.slice(12).split("and");
    	
    	   var cql="";
    	  switch(layerName){
    	  case "GEOM_QYJCXX"://企业基础信息
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  
    		  if(!!filter.fl){
    			  cql+="and JGTYPE IN("+filter.fl+")";
    		  }
    		  var wxhfp="1418,1419,1419";
    		  if(!!filter.lfl){
    			  if(wxhfp.indexOf(wxhfp.substr(0,4))>-1){
    				  cql+="and WHQYLX IN("+filter.lfl+")";
    			  }else{
    				  cql+="and YHBZQYLX IN("+filter.lfl+")";
    			  } 
    		  }
    		  cql=original[0]+" and "+original[1]+cql;
    		  break;
    	  case "GEOM_WXYHZB":  //重大危险源
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfl){
    			  cql+="and LX IN("+filter.lfl+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and GRADE IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_SGBS":  //事故
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and GRADE IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_Danger_Report":  //隐患排查
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and GRADE IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_DYJYA_BASQB":  //应急预案
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_STANDARD":  //标准化
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.fl){
    			  cql+="and JGTYPE IN("+filter.fl+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and BZHDJ IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_YJYA_YJWZ":  //应急物资
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfl){
    			  //cql+="and FTYPE IN("+filter.lfl+")";
    			  var arr=filter.lfl.split("#");
    			  var likeFilter=arr[0].split("OR");
    			  var inFilter=arr[1].split(",");
    			  var a="",b="";
    			  if(likeFilter.length>0&&likeFilter[0]!==""){
    				  a=likeFilter.map(function(val,index){
  			            return "FTYPE like '"+parseInt(val.slice(val.length-4))+"%'";
  			              });
  			          a=a.join(" or ");
    			  }
    			  if(inFilter.length>0&&inFilter[0]!==""){
    				  b=inFilter.map(function(val,index){
  			            return val;
  			                    });
  			          b=" FTYPE IN("+b.join(",")+")";
    			  }
    			  if(!!b&&!!a){
    				  cql=cql+"and "+a+" or "+b;
    			  }else{
    				  cql=cql+"and "+a+b;
    			  }
    			  
    		  }
    		  cql=original[0]+"and XZQH like '13%' "+cql;
    		  break;
    	  case "GEOM_YJZY_YJJYDW":  //救援队伍
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfl){
    			  cql+="and DWSX IN("+filter.lfl+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and FTYPE IN("+filter.lfj+")";
    		  }
    		  
    		  
    		  cql=original[0]+"and XZQH like '13%' "+cql;
    		  break;
    	  case "GEOM_YJZY_YJJYZB":  //救援装备
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfl){
    			  var arr=filter.lfl.split("#");
    			  var likeFilter=arr[0].split("OR");
    			  var inFilter=arr[1].split(",");
    			  var a="",b="";
    			  if(likeFilter.length>0&&likeFilter[0]!==""){
    				  a=likeFilter.map(function(val,index){
  			            return "FTYPE like '"+parseInt(val.slice(val.length-4))+"%'";
  			              });
  			          a=a.join(" or ");
    			  }
    			  if(inFilter.length>0&&inFilter[0]!==""){
    				  b=inFilter.map(function(val,index){
  			            return val;
  			                    });
  			          b=" FTYPE IN("+b.join(",")+")";
    			  }
    			  if(!!b&&!!a){
    				  cql=cql+"and "+a+" or "+b;
    			  }else{
    				  cql=cql+"and "+a+b;
    			  }
    			  //cql+="and FTYPE IN("+filter.lfl+")";
    		  }
    		  cql=original[0]+"and XZQH like '13%' "+cql;
    		  break;
    	  case "GEOM_LAWINFO_PLAN":  //执法监察
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.fl){
    			  cql+="and ISSIMPLE IN("+filter.fl+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and LAWLEVEL IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_HON_CHMAIN":  //诚信企业
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and GRADE IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_ZYBWH":  //职业病危害
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and ZYWHDJ IN("+filter.lfj+")";
    		  }
/*    		  if(!!filter.fl){
    			  cql+="and JGTYPE IN("+filter.fl+")";
    		  }*/
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_SUPERVISION":  //监管监察
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and AREALEVEL IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_EMERG_RESPONSE":  //应急响应
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfl){
    			  cql+="and dd IN("+filter.lfl+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_ZJJG":  //中介机构
    		  /*if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }*/
    		  if(!!filter.lfj){
    			  cql=" and ORGTYPE IN("+filter.lfj+")";
    		  }
    		  /*if(!!filter.fl){
    			  cql+="and JGTYPE IN("+filter.fl+")";
    		  }*/
    		  cql=original[1]+cql;
    		  break;
    	  case "GEOM_SPECIAL":  //专项检查
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and ORGTYPE IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_WKK":  //尾矿库
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and GRADE IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_WKK":  //尾矿库
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and GRADE IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  case "GEOM_RISK_POINT":  //风险点
    		  if(!!filter.code){
    			  cql=" and HYLB IN("+filter.code+")";
    		  }
    		  if(!!filter.lfj){
    			  cql+="and GRADE IN("+filter.lfj+")";
    		  }
    		  cql=original[0]+"and"+original[1]+cql;
    		  break;
    	  }
    	  layer.updateParams({
    		  cql_filter:cql
    	  });
    }
    
    
    
    /**
     * @api {类型 function} 打开详情页 openDetail
     * @apiParam {String} layerName 专题图图层名称
     * @apiParam {String} id 该条数据的id
     * @apiName openDetail 
     * @apiGroup judge
     */
    function openDetail(layerName,id){
    	
    	  switch(layerName){
    	  case "GEOM_WXYHZB":  //重大危险源
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/zdwxySqManage/zdwxyDetailForMap?id="+id,
    			  area:["660px","600px"]
    		  });
    		  break;
    	  case "GEOM_SGBS":  //事故
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/accidentreprot/sgbsJump?id="+id,
    			  area:["739px","472px"]
    		  });
    		  break;
    	  case "GEOM_Danger_Report":  //隐患排查
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/dangerQy/toDangerReportLayerPage?id="+id,
    			  area:["730px","350px"]
    		  });
    		  break;
    	  case "GEOM_DYJYA_BASQB":  //应急预案
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/yjyabasqbManager/yjyaDetailForMap?id="+id,
    			  area:["618px","428px"]
    		  });
    		  break;
    	  case "GEOM_STANDARD":  //标准化
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/unifyStandard/standardDetailForMap?id="+id,
    			  area:["618px","340px"]
    		  });
    		  break;
    	  case "GEOM_YJYA_YJWZ":  //应急物资
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/yjzyManager/jywzDetailMapOpen?id="+id,
    			  area:["668px","330px"]
    		  });
    		  break;
    	  case "GEOM_YJZY_YJJYDW":  //救援队伍
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/yjzyManager/jydwDetailMapOpen?id="+id,
    			  area:["678px","440px"]
    		  });
    		  break;
    	  case "GEOM_YJZY_YJJYZB":  //救援装备
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/yjzyManager/jyzbDetailMapOpen?id="+id,
    			  area:["674px","330px"]
    		  });
    		  break;
    	  case "GEOM_LAWINFO_PLAN":  //执法监察
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/zfjc/iSearchLiAnDetail?id="+id,
    			  area:["770px","310px"]
    		  });
    		  break;
    	  case "GEOM_HON_CHMAIN":  //诚信企业
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/appli/toAppliMapLayer?id="+id,
    			  area:["720px", "320px"]
    		  });
    		  break;
    	  case "GEOM_ZYBWH":  //职业病危害
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/zyjkManager/toZybwhqyMapLayer?id="+id,
    			  area:["730px", "555px"]
    		  });
    		  break;
    	  case "GEOM_SUPERVISION":  //监管监察
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/superVisionRecord/toJGJCMapLayer?id="+id,
    			  area:["721px","344px"]
    		  });
    		  break;
    	  case "GEOM_EMERG_RESPONSE":  //应急响应
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/yjxy/yjxyDetailForMap?id="+id,
    			  area:["618px","490px"]
    		  });
    		  break;
    	  case "GEOM_ZJJG":  //中介机构
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/zjjgManager/zjjgDetailMapOpen?id="+id,
    			  area:["650px","360px"]
    		  });
    		  break;
    	  case "GEOM_SPECIAL":  //专项检查
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/superVisionRecord/toZXJCMapLayer?id="+id,
    			  area:["721px","344px"]
    		  });
    		  break;
    	  case "GEOM_WKK":  //尾矿库
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/wkk/jumpToWkkdetl?id="+id,
    			  area:["850px","505px"]
    		  });
    		  break;
    	  case "GEOM_RISK_POINT":  //风险点
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/riskPoint/iSearchFxdDetail?id="+id,
    			  area:["800px","505px"]
    		  });
    		  break;
    	  case "GEOM_VB_TARGET":  //脆弱性目标
    		  layer.open({
    			  type:2,
    			  title:"详细信息",
    			  content:"/main/vulnerbilityTarget/iSearchVbTargetDetail?id="+id,
    			  area:["800px","505px"]
    		  });
    		  break;
    	  }
    }


    return {
        getInfo: getInfo,
        updateLayers:updateLayers,
        openDetail:openDetail
    }

})