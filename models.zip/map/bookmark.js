/**
 * 书签管理 dqy 2017/11/2 下午7:34:28
 * 引用位置 main.js 
 * 页面位置 Map.jsp  .story
 * 功能描述：
 * 1.用户可以保存当前地图范围(中心点、缩放级别)。
 * 2.点击列表书签名称时，地图切换到对应范围。
 * 3.可以编辑书签，删除书签
 * 4.不同用户只能管理自己的书签      
 */

define(["initMap"],function(mapContent){
    var obj= {      
        mkList:[],
        layerIndex:null,
        init:function(){
            //书签点击事件
            $('.story').click(function(){
                if($('.story').hasClass('story_visited')){
                    $('.story').removeClass('story_visited');
                    if(obj.layerIndex){
                        layer.close(obj.layerIndex);
                        obj.layerIndex=null;
                    }
//                  $('.bookMList').hide();
                }else{
                    $('.story').addClass('story_visited');
                    obj.layerIndex=layer.open({
                        type: 1,
                        skin: 'layui-layer-rim', //加上边框
                        area: ['420px', '240px'], //宽高
                        content: '<div class="bookMList"></div>'
                      });
//                  $('.bookMList').show();
                    obj.getMarkList();
                }           
            });
        },
        
        getMarkList:function(){
            var url='/main/onemap/GetUserMarks';
            $.ajax({
                type: "GET",
                url: url,
                dataType: "json",               
                success: function (data) {                  
                    obj.mkList=data; 
                    if(data.length>0){
                        if(obj.layerIndex){
//                          layer.close(obj.layerIndex);
//                          obj.layerIndex=null;
                        }else{
                        obj.layerIndex=layer.open({
                            type: 1,
                            title:'书签',
//                          skin: 'layui-layer-rim', //加上边框
                            area: ["461px", "282px"], //宽高
                            content: '<div class="bookMList" style="overflow:auto;"></div>'
                          });
                        }
                        $('.bookMList').html('');
                        for(var i=0;i<data.length;i++){ 
                            var name=data[i].name;
                            if(name.length>5){
                                name=name.substring(0,15)+'...';
                            }
                            var htm='<div class="listLocation bklist" id="'+i+'" name="'+data[i].id+'" ><div class="bklist-item" title='+data[i].name+'>'+name+'</div><a class="bk_del">删除</a><a class="bk_edit">修改</a></div>';  
                            $('.bookMList').append(htm);
                        }
                        // 查看
                        $('.bklist-item').click(function(){
                            $('.bklist').removeClass('bklist_visited');
                            $(this).parent('.bklist').addClass('bklist_visited');
                            var num=parseInt($(this).parent('.bklist')[0].id);
                            var zoom=parseInt(obj.mkList[num].zoom);
                            var a=obj.mkList[num].position.split('-');
                            var center=[parseInt(a[0]),parseInt(a[1])];
                            mapContent.map.getView().setCenter(center);
                            mapContent.map.getView().setZoom(zoom);
                        });
                        // 编辑
                        $('.bk_edit').click(function(){
                            var bkid=$(this).parent('.bklist').attr('name');
                            var num=parseInt($(this).parent('.bklist')[0].id);
                            var prename= obj.mkList[num].name;
                            var zoom=mapContent.map.getView().getZoom();
                            var center=mapContent.map.getView().getCenter();
                            var position=Math.floor(center[0] * 10000) / 10000+'-'+Math.floor(center[1] * 10000) / 10000;           
                            layer.prompt({title: '请输入修改书签名称：', formType:0,value:prename,btn:['保存','取消']}, function(name, index){
                                if(!name){
                                    layer.msg('请输入书签名称！');
                                    return;
                                }
                                layer.close(index);
                                obj.updateMark('modify',bkid,position,name,zoom);   
                            })
                        });
                        // 删除
                        $('.bk_del').click(function(){
                            var bkid=$(this).parent('.bklist').attr('name');
                            layer.confirm('是否要删除此书签？', {
                                  btn: ['是','否'] // 按钮
                                }, function(){                                  
                                    obj.updateMark('delete',bkid);
                                    obj.getMarkList();
                                }, function(){
                                  
                                });
                        });
                        
                    }else{
                        $('.story').removeClass('story_visited')
                        layer.msg('未添加任何书签！');
                        $('.bookMList').hide();
                    }
                },
                error: function (e) {                   
                    this.markList=[];
                    
                    layer.msg('获取书签列表失败！');
                }
            });
        },
        // 添加
        updateMark:function(type,id,position,name,zoom){
            var url='/main/onemap/UpdateUserMark';
            $.ajax({
                type: "POST",
                url: url,
                dataType: "json",
                data:{
                    type:type,
                    id:id,
                    position:position,
                    name:name,
                    zoom:zoom               
                },
                success: function (data) {
                    if(data.flag){
                        layer.msg(data.msg);
                        if(type=='delete'||type=='modify'){
                            obj.getMarkList();
                        }else{
                         //书签展开状态，刷新
                        if($('.story').hasClass('story_visited')){
                            obj.getMarkList();
                        }
                        }
                        return true;
                    }else{
                        layer.msg(data.msg);
                        return false;
                    }
                    
                },
                error: function (e) {
                    layer.msg("操作失败！");
                    return false;
                }
            });
        
        }
        
    }
    
    return obj;
})