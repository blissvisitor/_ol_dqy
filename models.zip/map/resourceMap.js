

require(["ol", "mapTools", "mapConfig"], function (ol, mapTools, mapConfig) {


	//河北省界图层
	var hbsjLayer = new ol.layer.Tile({
		minResolution: 0.0013766455078125,
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "HBSJ/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=HBSJ&STYLE=HBSJ&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	//矢量地图
	var sl_dtLayer = new ol.layer.Tile({
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "sl_dt/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_dt&STYLE=sl_dt&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	//矢量地图标注
	var sl_zjLayer = new ol.layer.Tile({
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "sl_zj/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_zj&STYLE=sl_zj&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	var view = new ol.View({
		zoom: 7,
		center: [115.80688, 39.67163],
		projection: "EPSG:4326"
	});

	var vectorLayer = new ol.layer.Vector({
		source: new ol.source.Vector()
	});

	var map = new ol.Map({
		target: "map",
		layers: [sl_dtLayer, hbsjLayer, sl_zjLayer, vectorLayer],
		view: view,
		logo: false
	});





	//根据图层数字获得图层名称
	function getLayer(layerNumber) {
		var layerName = "";
		switch (layerNumber) {
			case "1129":
				layerName = "HBAJ:GEOM_YJZY_YJJYZB";//救援装备
				break;
			case "1128":
				layerName = "HBAJ:GEOM_YJYA_YJWZ";//物资
				break;
			case "1127":
				layerName = "HBAJ:GEOM_YJZY_YJJYDW";//救援队伍
				break;
		}

		return layerName;
	}















	var style = new ol.style.Style({
		image: new ol.style.Circle({
			radius: 5,
			fill: new ol.style.Fill({
				color: "#ff0000"
			}),
			stroke: new ol.style.Stroke({
				color: "#00ff00",
				width: 1
			})
		})
	});

	var style2 = new ol.style.Style({
		image: new ol.style.Circle({
			radius: 5,
			fill: new ol.style.Fill({
				color: "#ffffff"
			}),
			stroke: new ol.style.Stroke({
				color: "#00ff00",
				width: 1
			})
		}),
		zIndex: 100
	});
	var myid = window.location.search.split("=")[1], features = [];
	$.post("/main/emer/getEmersourcetypeByEmersourceId", { id: myid }, function (str) {
		var obj = JSON.parse(str);
		for (var j = 0, k = obj.length; j < k; j++) {
			var overlay = mapTools.overlayFunction();
			var feature = new ol.Feature({
				geometry: new ol.geom.Point([parseFloat(obj[j].jd), parseFloat(obj[j].wd)])
			});
			feature.setStyle(style2);
			features.push(feature);
			overlay.setPosition([parseFloat(obj[j].jd), parseFloat(obj[j].wd)]);
			overlay.getElement().children[1].innerHTML = obj[j].title;
			overlay.getElement().removeChild(overlay.getElement().children[0]);
			overlay.getElement().style.minWidth = "74px";
			map.addOverlay(overlay);
		}
		vectorLayer.getSource().addFeatures(features);
	});



})