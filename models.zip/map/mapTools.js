define(["chartsShow", "ol", "initMap", "mapConfig", "plot", "layerConfig", "judge"], function (chartsShow, ol, initMap, mapConfig, plot, layerConfig, judge) {



	//绘制圆角矩形
	/**
	 * @api {类型 function} 绘制圆角矩形 roundRect
	 * @apiParam {Number} x 圆角矩形的x轴坐标
	 * @apiParam {Number} y 圆角矩形的y轴坐标
	 * @apiParam {Number} w 圆角矩形的宽度
	 * @apiParam {Number} h 圆角矩形的高度
	 * @apiParam {Number} r 圆角矩形的半径
	 * @apiName roundRect 
	 * @apiGroup mapTools
	 */
	var roundRect = function (x, y, w, h, r) {
		if (w < 2 * r) r = w / 2;
		if (h < 2 * r) r = h / 2;
		this.beginPath();
		this.moveTo(x + r, y);
		this.arcTo(x + w, y, x + w, y + h, r);
		this.arcTo(x + w, y + h, x, y + h, r);
		this.arcTo(x, y + h, x, y, r);
		this.arcTo(x, y, x + w, y, r);
		this.closePath();
		return this;
	}

	var layerColor = function (layerName) {
		var color = "";
		switch (layerName) {
			case "GEOM_QYJCXX":
				color = "6,106,205";
				break;
			case "GEOM_WXYHZB":
				color = "182,12,12";
				break;
			case "GEOM_SGBS":
				color = "222,54,54";
				break;
			case "GEOM_Danger_Report":
				color = "251,120,24";
				break;
			case "GEOM_DYJYA_BASQB":
				color = "46,123,227";
				break;
			case "GEOM_STANDARD":
				color = "0,172,16";
				break;
			case "GEOM_YJYA_YJWZ":
				color = "63,153,215";
				break;
			case "GEOM_YJZY_YJJYDW":
				color = "249,164,42";
				break;
			case "GEOM_YJZY_YJJYZB":
				color = "233,150,19";
				break;
			case "GEOM_LAWINFO_PLAN":
				color = "51,104,239";
				break;
			case "GEOM_HON_CHMAIN":
				color = "56,196,59";
				break;
			case "GEOM_YJSJ":
				color = "54,98,199";
				break;
			case "GEOM_ZYBWH":  //职业病危害
				color = "25,164,84";
				break;
			case "GEOM_FIREWORKS":  //烟花爆竹
				color = "197,47,47";
				break;
			case "GEOM_SUPERVISION":  //监督监察
				color = "7,190,184";
				break;
			case "GEOM_ZJJG":  //中介服务机构
				color = "158,43,248";
				break;
			case "GEOM_REGULATION_SUBJECT":  //监管主题
				color = "8,151,204";
				break;
			case "GEOM_SPECIAL":  //专项检查
				color = "72,173,220";
				break;
			case "GEOM_WKK":  //尾矿库
				color = "107,72,220";
				break;
			case "GEOM_EMERG_RESPONSE":  //应急响应
				color = "196,58,194";
				break;
			case "GEOM_KSK":  //矿山库
				color = "143,0,0";
				break;
			case "GEOM_VB_TARGET":  //脆弱性目标
				color = "166,6,195";
				break;
			case "GEOM_RISK_POINT":  //风险点
				color = "134,0,150";
				break;
			case "RKSJ"://人口数据
				color = "134,0,150";
				break;
			case "GEOM_WXYQY"://危险源企业
				color = "159,0,0";
				break;
		}
		return color;
	}


	return {
		//根据不同图层返回不同的颜色值
		layerColor: layerColor,
		//绘制圆角矩形
		roundRect: roundRect,
		/**
		 * @api {类型 function} 新建一个带数字的圆角矩形样式 setStyle
		 * @apiParam {Number} count 圆角矩形显示的文本统计数量
		 * @apiParam {Number} layerName 圆角矩形所属图层名称
		 * @apiName setStyle 
		 * @apiGroup mapTools
		 */
		setStyle: function (count, layerName) {
			var color = this.layerColor(layerName);
			var countStr = count.toString();
            
			var radius = 5;
			switch (countStr.length) {
				case 1:
					radius = 30;
					break;
				case 2:
					radius = 30;
					break;
				case 3:
					radius = 30;
					break;
				case 4:
					radius = 30;
					break;
				case 5:
					radius = 40;
					break;
				case 6:
					radius = 48;
					break;
			}
			if(layerName==="RKSJ"){
            	countStr=countStr+"万";
            	radius=45;
			 }

			var canvas = document.createElement('canvas');
			canvas.width = radius;
			canvas.height = 20;
			var context = canvas.getContext("2d");
			context.fillStyle = "rgba(" + color + ",0.7)";
			context.lineWidth = 1;
			context.roundRect = this.roundRect;
			context.roundRect(0, 0, radius, 20, 5);
			context.fill();
			context.strokeStyle = "rgba(" + color + ",1)";
			context.stroke();


			var canvasStyle = new ol.style.Style({
				image: new ol.style.Icon({
					img: canvas,
					imgSize: [canvas.width, canvas.height]
				}),
				text: new ol.style.Text({
					font: "12px 微软雅黑",
					fill: new ol.style.Fill({
						color: "#ffffff"
					}),
					text: countStr
				})
			});
			return canvasStyle;
		},
		//移除图例所在的div   待删除
		// removeLengend: function (layer) {
		// 	$("#lengends>div [ly='" + layer + "']").next().remove();
		// 	$("#lengends>div [ly='" + layer + "']").remove();
		// },
		/**
		 * @api {类型 function} 创建右上角图例功能 createLengend
		 * @apiParam {String} text 暂时无用
		 * @apiParam {Number} layer 图层名称
		 * @apiName createLengend 
		 * @apiGroup mapTools
		 */
		 createLengend: function (text, layer) {
			 if(!layer){
				 $("#lengends").slideUp("fast");
				 return;
			 }
			 var $legends=$("#lengends");
			 if($legends.attr("legends")===layer&&$legends.css("display")==="block"){
				 $legends.slideUp("fast");
				 return;
			 }
			 $legends.attr("legends",layer);
			 $legends.html("");
			 var src=null;
			 if(layer!=="GEOM_QYJCXX"){
				 src = mapConfig.hebeiBordr + "?Request=GetLegendGraphic&version=1.0.0&format=image/png&width=39&height=20&layer=HBAJ:" + layer + "&legend_options=fontName:%E5%BE%AE%E8%BD%AF%E9%9B%85%E9%BB%91;fontSize:12;bgColor=0xF5F5F5";
			 }else{
				 src="/main/resources/image/map/qiye.png";
			 }
		 	
		 	$legends.append("<img src='"+src+"'></img>");
		 	$legends.slideDown("fast");

		 },
		//创建图层
		/**
		 * @api {类型 function} 创建图层 createLayer
		 * @apiParam {Number} layerName 圆角矩形所属图层名称
		 * @apiName createLayer 
		 * @apiGroup mapTools
		 */
		createLayer: function (layerName, map) {
             
			var controls=mapConfig.userFilters.split("=")[1];

				switch(layerName){
				case "GEOM_YJYA_YJWZ":
				case "GEOM_YJZY_YJJYDW":
				case "GEOM_YJZY_YJJYZB":
					controls=controls.split("and")[0]+" and XZQH like '13%'";
					break;
			}

			
			var layer = new ol.layer.Image({
				source: new ol.source.ImageWMS({
					crossOrigin: "anonymous",
					ratio: 1,
					url: mapConfig.hebeiBordr,
					params: {
						format: "image/png",
						version: "1.1.1",
						layers: "HBAJ:" + layerName,
						cql_filter: controls
					}
				}),
				maxResolution: 0.0006866455078125, //0.00034332275390625
				layerName: layerName
			});
			map.addLayer(layer);
			return layer;
		},
		//用来保存统计图层的图层名称
		layerName: "",
		/**
		 * @api {类型 function} 根据图层名称显示专题图统计数量 showData
		 * @apiParam {Number} count 圆角矩形显示的文本统计数量
		 * @apiParam {String} layerName 圆角矩形所属图层名称
		 * @apiName showData 
		 * @apiGroup mapTools
		 */
		showData: function (layerName, obj) {
			if (!layerName) {
				return;
			}
			//清除空间统计图层
			//initMap.themeMap.getSource().clear();
			//清除空间统计图层图例
			//$("#statisticsLegend").html("");//清除空间统计的图例
			var that = this;
			that.layerName = layerName;
			var format = new ol.format.WKT();
			initMap.statisticalLayer.getSource().clear();
			var url = "/main/onemap/DiffrentLevel";
			var params = {
				xzqhLevel: "1",
				tb: layerName
			};
			if(obj){
				if(obj.code!==""){
					url = "/main/onemap/LayerFilter";
					params.code = obj.code;
					params.fl = obj.fl;
					params.lfl=obj.lfl;
					params.lfj=obj.lfj;
				}
				if(obj.fl!==""){
					url = "/main/onemap/LayerFilter";
					params.code = obj.code;
					params.fl = obj.fl;
					params.lfl=obj.lfl;
					params.lfj=obj.lfj;
				}
				if(layerName==="GEOM_ZJJG"&&obj.lfj!==""){
					url = "/main/onemap/LayerFilter";
					params.code = obj.code;
					params.fl = obj.fl;
					params.lfl=obj.lfl;
					params.lfj=obj.lfj;
				}
				if(layerName==="GEOM_YJZY_YJJYZB"||layerName==="GEOM_YJYA_YJWZ"){
					if(obj.lfl!=="#"){
						url = "/main/onemap/LayerFilter";
						params.code = obj.code;
						params.fl = obj.fl;
						params.lfl=obj.lfl;
						params.lfj=obj.lfj;
					}
				}else{
					if(obj.lfl!==""){
						url = "/main/onemap/LayerFilter";
						params.code = obj.code;
						params.fl = obj.fl;
						params.lfl=obj.lfl;
						params.lfj=obj.lfj;
					}
				}
				
				if(obj.lfj!==""){
					url = "/main/onemap/LayerFilter";
					params.code = obj.code;
					params.fl = obj.fl;
					params.lfl=obj.lfl;
					params.lfj=obj.lfj;
				}
			}
			
			$.post(url, params).done(function (data) {
				if (data.length === 0) {
					initMap.statisticalLayer.getSource().clear();
					return;
				}
				var features = [];
				for (var i = 0, z = data.length; i < z; i++) {
					var feature = format.readFeature(data[i].point);
					feature.set("xzqh", data[i].xzqh);
					feature.set("city", data[i].city);
					feature.set("layerName", layerName);
					feature.set("count", data[i].count);
					feature.setStyle(that.setStyle(parseInt(data[i].count), layerName));
					features.push(feature);
				}
				initMap.statisticalLayer.getSource().clear();
				initMap.statisticalLayer.getSource().addFeatures(features);
			}).fail(function (data) {
				layer.msg("获取数据失败!");
			});
		},
		// 专题图的点数组
		themePoint: null,
		// 工具工具是否激活
		isActive: true,
		getCountyData: function (layerName, obj) {
			//清除空间统计图层
			//initMap.themeMap.getSource().clear();
			//清除空间统计图层图例
			//$("#statisticsLegend").html("");
			if (!layerName) {
				return;
			}
			var that = this;
			that.layerName = layerName;
			var format = new ol.format.WKT();
			initMap.statisticalLayer.getSource().clear();
			var params = {
				xzqhLevel: "2",
				tb: layerName
			};
			var url = "/main/onemap/DiffrentLevel";
			/*if (obj && obj.classification) {
				url = "/main/onemap/LayerClassification";
				params.code = obj.code;
			}*/
			if(obj){
				if(obj.code!==""){
					url = "/main/onemap/LayerFilter";
					params.code = obj.code;
					params.fl = obj.fl;
					params.lfl=obj.lfl;
					params.lfj=obj.lfj;
				}
				if(obj.fl!==""){
					url = "/main/onemap/LayerFilter";
					params.code = obj.code;
					params.fl = obj.fl;
					params.lfl=obj.lfl;
					params.lfj=obj.lfj;
				}
				if(layerName==="GEOM_ZJJG"&&obj.lfj!==""){
					url = "/main/onemap/LayerFilter";
					params.code = obj.code;
					params.fl = obj.fl;
					params.lfl=obj.lfl;
					params.lfj=obj.lfj;
				}
				if(layerName==="GEOM_YJZY_YJJYZB"||layerName==="GEOM_YJYA_YJWZ"){
					if(obj.lfl!=="#"){
						url = "/main/onemap/LayerFilter";
						params.code = obj.code;
						params.fl = obj.fl;
						params.lfl=obj.lfl;
						params.lfj=obj.lfj;
					}
				}else{
					if(obj.lfl!==""){
						url = "/main/onemap/LayerFilter";
						params.code = obj.code;
						params.fl = obj.fl;
						params.lfl=obj.lfl;
						params.lfj=obj.lfj;
					}
				}
				if(obj.lfj!==""){
					url = "/main/onemap/LayerFilter";
					params.code = obj.code;
					params.fl = obj.fl;
					params.lfl=obj.lfl;
					params.lfj=obj.lfj;
				}
			}
			$.post(url, params).done(function (data) {
				var features = [];
				for (var i = 0, z = data.length; i < z; i++) {
					var feature = format.readFeature(data[i].point);
					feature.set("city", data[i].city);
					feature.set("xzqh", data[i].xzqh);
					feature.set("layerName", layerName);
					feature.set("count", data[i].count);
					feature.setStyle(that.setStyle(parseInt(data[i].count), layerName));
					features.push(feature);
				}
				initMap.statisticalLayer.getSource().clear();
				initMap.statisticalLayer.getSource().addFeatures(features);
			}).fail(function () {
				layer.msg("获取数据失败!");
			});
		},
		//用来显示分类的五个专题图，如柱状图、饼状图
		showTheme: function (data, map, layer) {
			var isSearch = this.getLayerById(map, "themeMap");
			if (isSearch === true) {
				layer.getSource().clear();
			} else {
				map.addLayer(layer);
			}
			var format = new ol.format.WKT();
			var features = data.map(function (val) {
				var feature = format.readFeature(val.point);
				var array = val.count.split("#").map(function (val) {
					var intVal = parseInt(val);
					return intVal;
				});
				var size = 0;
				array.map(function (val) {
					var intVal = parseInt(val) ? parseInt(val) : 0;
					size += intVal;
					return intVal;
				});
				if (val.grade) {
					feature.set("city", val.city);
					feature.set("data", array);
					feature.set("size", size);
					feature.set("grades", val.grade.split("#"));
				} else {
					feature.set("city", val.city);
					feature.set("data", array);
					feature.set("size", size);
					feature.set("grades", [0]);
				}
				return feature;
			});
			this.themePoint = features;
			layer.getSource().addFeatures(features);
			layer.setStyle(chartsShow.chartTypeStyle);
			chartsShow.doAnimate(layer);
		},
		showThemeMap: function (layer, map, url) {
			var that = this;
			var isSearch = that.getLayerById(map, "themeMap");
			if (isSearch === true) {
			} else {
				map.addLayer(layer);
			}
			// 这个url是根据layerJson获得的
			//var url = app.layerJson.getSource().getUrl();
			var format = new ol.format.GeoJSON();
			// 如果不为空，则直接显示图标，不需要再次请求数据
			if (that.themePoint != null) {
				chartsShow.doAnimate(layer);
				return;
			}
			$.get(url, function (data) {
				var features = format.readFeatures(JSON.stringify(data));
				var points = features.map(that.getInteriorPoint);
				that.themePoint = points;
				layer.getSource().addFeatures(points);
				layer.setStyle(chartsShow.chartTypeStyle);
				chartsShow.doAnimate(layer);
			});
		},
		/**
		 * 根据id查找相应的图层并返回该图层
		 * 
		 * @param {ol.Map} map
		 * @param {string} id
		 * @returns {boolean}
		 */
		/**
		 * @api {类型 function} 根据id查找相应的图层并返回该图层 getLayer
		 * @apiParam {ol.Map} map 地图容器
		 * @apiParam {String} id 查找图层的ID值
		 * @apiName getLayer 
		 * @apiGroup mapTools
		 */
		getLayer: function (map, id) {
			var layerArray = map.getLayers().getArray();
			for (var i = 0, length = layerArray.length; i < length; i++) {
				if (layerArray[i].get('id') === id) {
					return layerArray[i];
				}
			}
			return null;
		},
		/**
		 * 根据id查找相应的图层并返回true或者false
		 * 
		 * @param {ol.Map} map
		 * @param {string} id
		 * @returns {boolean}
		 */
		getLayerById: function (map, id) {
			var layerArray = map.getLayers().getArray();
			for (var i = 0, length = layerArray.length; i < length; i++) {
				if (layerArray[i].get('id') === id) {
					return true;
				}
			}
			return false;
		},
		/*
		 * 用来获得面的内部中心点 
		 * @param {ol.Feature} feature return {ol.Feature}
		 * return {ol.Feature()}
		 */
		getInteriorPoint: function (feature) {
			var point = feature.getGeometry().getInteriorPoints().getCoordinates()[0];
			var confirmPoint = new ol.proj.fromLonLat(point);
			var x1 = Math.ceil(Math.random() * 10);
			var x2 = Math.ceil(Math.random() * 10);
			var x3 = Math.ceil(Math.random() * 10);
			var size = x1 + x2 + x3;
			var newFeature = new ol.Feature({
				geometry: new ol.geom.Point(confirmPoint),
				size: size,
				data: [x1, x2, x3]
			});
			return newFeature;
		},
		// 用来绘制企业点
		/*
		 * @param ol.Map map @param String dialogId
		 */
		plotPoint: function (map, dialogId) {
			var that = this;
			if (!this.isActive) {
				return;
			}
			this.isActive = false;
			var vector = new ol.layer.Vector({
				source: new ol.source.Vector(),
				// id:"addPoint"
			});
			map.addLayer(vector);
			var style = new ol.style.Style({
				image: new ol.style.Icon({
					src: mapConfig.imagePoint,
					anchor: [0.5, 1]
				})
			});
			vector.setStyle(style);
			var draw = new ol.interaction.Draw({
				style: style,
				source: vector.getSource(),
				type: "Point"
			});
			map.addInteraction(draw);
			draw.on("drawend", function (evt) {
				var coordinate = new ol.proj.toLonLat(evt.feature.getGeometry()
					.getCoordinates());
				$("input[name='x']").val(coordinate[0].toFixed(7).toString());
				$("input[name='y']").val(coordinate[1].toFixed(7).toString());
				// 弹出框
				//$("#" + dialogId).dialog("open");

				$("#companyInfo").css("display", "block");
				layer.open({
					title: "请输入经纬度",
					type: 1,
					area: ["auto", "auto"],
					content: $("#companyInfo"),
					closeBtn: 1,
					cancel: function () {
						$("#companyInfo").css("display", "none");
						map.removeLayer(vector);
					},
					end: function () {
						$("#companyInfo").css("display", "none");
					}
				});




				/*var div = document.getElementsByClassName("panel-tool-close");
				div[0].onclick = function() {
					map.removeLayer(vector);
				}*/
				that.isActive = true;
				map.removeInteraction(draw);
			});
			return vector;
		},
		drawLocation1: null,
		vector1: null,
		feature1: null,
		style1: null,
		iniLocation: function (map, lon, lat, vector1) {
			//定位
			//var lon=$("#xCoord").val();
			//var lat=$("#yCoord").val();
			if (lon != "" && lat != "") {
				lon = parseFloat(lon);
				lat = parseFloat(lat);
				//增加要素点
				feature1 = new ol.Feature({
					geometry: new ol.geom.Point([lon, lat])
					//name: 'point'
				});
				vector1.getSource().addFeature(feature1);

				//initMap.panToPoint([lon, lat]);
				map.getView().setCenter([lon, lat]);
				map.getView().setZoom(12);
			} else {
				feature1 = null;
			}
		},
		//移走
		confirmDrawLocation: function (map, vector1) {
			//清除绘制方法
			map.removeInteraction(drawLocation1);
			map.removeLayer(vector1);
		},
		/**
		 * @api {类型 function} 处理多面标注显示 multiTextStyle
		 * @apiParam {Geometry} geom  
		 * @apiParam {String} label 行政区划名称
		 * @apiName multiTextStyle 
		 * @apiGroup mapTools
		 */
		multiTextStyle:function(geom,label){
			var geomType=geom.getType();
	         var point,feature;
	         if(geomType=='MultiPolygon'){
	             //求出面积最大的polygon
	             var maxArea=0;
	             var maxPolygon;
	             var polygons=geom.getPolygons();
	             polygons.forEach(function(item,index){
	                 var area=item.getArea();
	                 if(area>maxArea){
	                     maxPolygon=item;
	                     maxArea=area;
	                 }
	             });
	             point=new ol.geom.Point(ol.extent.getCenter(maxPolygon.getExtent()));
	             if(label=='廊坊市'){
	                 var polygons=geom.getPolygons();
	                 var points=[];
	                 polygons.forEach(function(poly,index){
	                     var point1=new ol.geom.Point(ol.extent.getCenter(poly.getExtent()));
	                     points.push(point1.getCoordinates());
	                 });
	                 point=new ol.geom.MultiPoint(points);
	             }
	         }else{
	             point=new ol.geom.Point(ol.extent.getCenter(geom.getExtent()));
	         }
	         feature=new ol.Feature(point);
	         feature.setStyle(new ol.style.Style({
	             fill:new ol.style.Fill({
	                 color:'rgba(255,0,0,0)'
	             }),
	             stroke:new ol.style.Stroke({
	                 width:0,
	                 color:'rgba(255,0,0,0)'
	             }),
	             text:new ol.style.Text({
	                 font: '12px 微软雅黑',
	                 fill: new ol.style.Fill({ color: 'black' }),
	                 text: label
	             })
	         }));
	         return feature;
		},
		/**
		 * @api {类型 function} 清除风险地图 destroyRisk
		 * @apiName destroyRisk 
		 * @apiGroup mapTools
		 */
		destroyRisk:function(){
			initMap.riskLayer.getSource().clear();
			initMap.riskLayer.set("isRisk",0);
		},
		/**
		 * @api {类型 function} 风险地图样式 riskStyle
		 * @apiName {Number} risk 该地图的风险值
		 * @apiName {String} sta 县or市 该地区的行政区划编码
		 * @apiName riskStyle 
		 * @apiGroup mapTools
		 */
		riskStyle:function(risk,riskName){
			var strokeColor='#005fd5';
	         var fillColor='rgba(255,0,0,0.1)';
	         if(risk<=150){
	             fillColor='#2196f3';
	         }else if(risk>150&&risk<=300){
	             fillColor='#ffc107';
	         }else if(risk>300&&risk<=1000){
	             fillColor='#ff5722';
	         }else if(risk>1000){
	             fillColor='#ff0000';
	         }else{
	             fillColor='rgba(255,0,0,0)';
	         }
	         return new ol.style.Style({
	             fill:new ol.style.Fill({
	                 color:fillColor
	             }),
	             stroke:new ol.style.Stroke({
	                 width:4,
	                 color:strokeColor
	             }),
	             text:new ol.style.Text({
	                 font: '12px 微软雅黑',
	                 fill: new ol.style.Fill({ color: 'black' }),
	                 text: riskName
	             })
	         })
		},
		/**
		 * @api {类型 function} 获取风险地图数据 getRiskData
		 * @apiParam {String} url 风险值请求地址
		 * @apiParam {String} url1 行政区划地址
		 * @apiParam {String} sta 县or市
		 * @apiName getRiskData 
		 * @apiGroup mapTools
		 */
		getRiskData:function(url,url1,sta){
			var that=this;
			 $.ajax({
	             url: url,
	             success: function(response,status,xhr){
	                 if (status =="success") {
	                     var data=response;
	                     $.ajax({
	                         url: url1,
	                         success: function(value,status,xhr){
	                             if (status =="success") {
	                                 var data1=value;
	                                 var gjFormat=new ol.format.GeoJSON(),labelFeatures=[];
	                                 var features=gjFormat.readFeatures(data1);
	                                 features.forEach(function(item,index){                     
	                                     var code=0;
	                                     var riskName=item.getProperties().NAME_1;
	                                     if(!riskName){
	                                         riskName=item.getProperties().name;
	                                     }           
	                                     if(sta==1){
	                                         code=item.getProperties().xzqh;
	                                       }else{
	                                          code=item.getProperties().code_1;
	                                       }
	                                     if(data[code]>=0){
	                                    	 var style=that.riskStyle(parseFloat(data[code]));
	                                         item.setStyle(style);
	                                         var labelFeature=that.multiTextStyle(item.getGeometry(),riskName);
	                                         labelFeatures.push(labelFeature);
	                                     }
	                                     
	                                 });
	                                 initMap.riskLayer.getSource().clear();
	                                 initMap.riskLayer.getSource().addFeatures(features);
	                                 initMap.riskLayer.getSource().addFeatures(labelFeatures);
	                                 riskStatus=sta;
	                             } else {
	                                 that.CityOrCountyRisk();
	                             }
	                         },
	                         dataType: 'json'
	                       });
	                     } else {
	                    layer.msg('请求风险值失败！');
	                 }
	             },
	             dataType: 'json'
	           });   
		},
		/**
		 * @api {类型 function} 显示 CityOrCountyRisk
		 * @apiName CityOrCountyRisk 
		 * @apiGroup mapTools
		 */
		CityOrCountyRisk:function(){
			 if(initMap.riskLayer.get("isRisk")==1){
		         if (initMap.map.getView().getZoom() > 8) {
		             //县 1
		             if(initMap.riskLayer.get("riskStatus")!=1){
		                 this.getRiskData('/main/riskPoint/iVeryAreaXFxValue',mapConfig.riskCountyUrl,1);
		             }
		         } else {
		             //市 2
		             if(initMap.riskLayer.get("riskStatus")!=2){
		                 this.getRiskData('/main/riskPoint/iVeryCityFxValue',mapConfig.riskCityUrl,2); 
		             }
		         }
		        }
		},
		/**
		 * @api {类型 function} 距离测量 measureLength
		 * @apiParam {ol.Map} map 地图容器
		 * @apiName measureLength 
		 * @apiGroup mapTools
		 */
		measureLength: function (map) {
			var that = this;
			if (!this.isActive) {
				return;
			}

			//当触发测量事件时，把鼠标样式改为其他样式
			$("#map").css("cursor", "url(" + mapConfig.meatureIcon + "),auto");



			this.isActive = false;
			map.getInteractions().getArray()[1].setActive(false);
			// 创建测量绘制的线所在的图层
			var vectorSource = new ol.source.Vector();
			var vectorLayer = new ol.layer.Vector({
				source: vectorSource
			});
			map.addLayer(vectorLayer);
			// 添加绘图工具
			var draw = new ol.interaction.Draw({
				type: 'LineString',
				source: vectorSource
			});
			map.addInteraction(draw);

			var clickLength = 0;
			var mapClick;

			var overlayArray = [];
			// 创建点的样式
			var pointStyle = new ol.style.Style({
				image: new ol.style.Circle({
					radius: 5,
					stroke: new ol.style.Stroke({
						color: "#ff0000",
						width: "2"
					}),
					fill: new ol.style.Fill({
						color: "#00ff00"
					})
				})
			});

			// 创建测量帮助提示
			var helpDiv = document.createElement('div');
			helpDiv.innerHTML = '单击开始测量';
			helpDiv.id = 'overlay';
			helpDiv.className = 'ol-tooltip';
			var overlayHelp = new ol.Overlay({
				element: helpDiv,
				offset: [15, 0],
				positioning: 'center-left'
			});
			map.addOverlay(overlayHelp);

			// 创建测量结果显示
			var resultDiv = document.createElement('div');
			resultDiv.innerHTML = "0km";
			resultDiv.id = 'measureResult';
			resultDiv.className = 'ol-tooltip ol-tooltip-measure';
			var overlayMeasure = new ol.Overlay({
				element: resultDiv,
				offset: [0, -15],
				positioning: 'bottom-center'
			});
			map.addOverlay(overlayMeasure);

			// 当鼠标移动时，帮助提示和测量结果的位置也跟随鼠标移动
			var pointerMove = map.on('pointermove', function (e) {
				overlayHelp.setPosition(e.coordinate);
				overlayMeasure.setPosition(e.coordinate);
			});

			draw.on('drawstart', function (e) {

				// 当触发绘制开始事件时，给地图添加单击事件
				mapClick = map.on('click',
					function (evt) {
						var createElement = document
							.createElement('div');
						createElement.innerHTML = clickLength;
						createElement.className = 'ol-tooltip ol-tooltip-measure';
						var newOverlay = new ol.Overlay(
							{
								element: createElement,
								position: evt.coordinate,
								offset: [0,
									-15],
								positioning: 'bottom-center'
							});
						// 每当单击的时候创建一个div，显示当前线的长度
						map.addOverlay(newOverlay);
						overlayArray
							.push(newOverlay);
						var featurePoint = new ol.Feature(
							{
								geometry: new ol.geom.Point(
									evt.coordinate)
							});
						featurePoint
							.setStyle(pointStyle);
						vectorSource
							.addFeature(featurePoint);
					});
				var drawFeature = e.feature;
				document.getElementById('measureResult').style.display = 'block';
				document.getElementById('overlay').innerHTML = '双击以结束测量';
				clickLength = '0km';
				var drawStartKey = drawFeature.get('geometry').on('change',
					function (e) {
						var measureResult = document.getElementById('measureResult');
						var length = drawFeature.get('geometry').clone().transform("EPSG:4326", "EPSG:3857").
							getLength();


						measureResult.innerHTML = (length / 1000.0)
							.toFixed(3)
							+ 'km';
						clickLength = (length / 1000.0)
							.toFixed(2)
							+ 'km';
					});
			});

			draw.on("drawend", function (e) {
				$("#map").css("cursor", "default");
				// 移除鼠标移动事件
				map.unByKey(pointerMove);
				// 移除overlay
				overlayMeasure.setPosition(undefined);
				overlayHelp.setPosition(undefined);
				// 移除绘制工具
				map.removeInteraction(draw);
				that.isActive = true;

				document.getElementById('measureResult').style.display = 'none';
				map.unByKey(mapClick);
				var coordinates = e.feature.get('geometry').getCoordinates();
				var createElement = document
					.createElement('div');
				var createA = document.createElement('a');
				createElement.zIndex = 100;
				createA.style.background = 'rgba(0, 0, 0, 0.5)';
				createA.className = 'ol-popup-closer ol-popup-closer2';
				createElement.innerHTML = "总长" + clickLength;
				createElement.appendChild(createA);
				createElement.className = 'ol-tooltip ol-tooltip-measure';
				var newOverlay = new ol.Overlay(
					{
						element: createElement,
						position: coordinates[coordinates.length - 1],
						offset: [0, -15],
						positioning: 'bottom-center'
					});

				map.removeOverlay(overlayArray[overlayArray.length - 1]);

				map.addOverlay(newOverlay);
				overlayArray.push(newOverlay);

				// 给x符号添加事件，用来取消所画的折线
				createA.onclick = function () {
					map.removeOverlay(overlayMeasure);
					map.removeOverlay(overlayHelp);
					createA.blur();
					map.removeLayer(vectorLayer);
					for (var i = 0, z = overlayArray.length; i < z; i++) {
						map.removeOverlay(overlayArray[i]);
					}
					// 当测量结果被关闭以后才可以双击放大
					map.getInteractions().getArray()[1]
						.setActive(true);
					return false;
				}
			});
		},
		/**
		 * @api {类型 function} 弹出i查询类似的框显示概要信息 showInfo
		 * @apiParam {ol.source.Vector} source 路径分析所显示到的图层
		 * @apiName showInfo 
		 * @apiGroup mapTools
		 */
		showInfo:function(id){
			var that=this;
			var infoUrl = layerConfig.infoLy["GEOM_EMERG_RESPONSE"] + "?id=" + id;
			$.get("/main/onemap/GetXyPosition",{id:id}).done(function(data){
				var p=data.split("#");
				var position=[parseFloat(p[0]),parseFloat(p[1])];
				initMap.map.getOverlays().clear();
				var overlay = that.overlayFunction();
				$.get(infoUrl).done(function (data) {
					judge.getInfo("GEOM_EMERG_RESPONSE", JSON.parse(data), overlay.getElement().lastChild);
					initMap.map.addOverlay(overlay);
					overlay.setPosition(position);
					initMap.panToPoint(position);
	                $(overlay.getElement().lastChild).on("click","p:last span:last",function(){
	                	judge.openDetail("GEOM_EMERG_RESPONSE",id);
	                })
				})
			});
		},
		getName:function(){},
		/**
		 * @api {类型 function} 路径分析 routeFind
		 * @apiParam {ol.source.Vector} source 路径分析所显示到的图层
		 * @apiName routeFind 
		 * @apiGroup mapTools
		 */
		routeFind: function (source) {
			var start, end, features = source.getFeatures();
			for (var i = 0, j = features.length; i < j; i++) {
				if (features[i].get('name') === "start") {
					start = features[i].getGeometry().getCoordinates().join(",");
				} else if (features[i].get('name') === "end") {
					end = features[i].getGeometry().getCoordinates().join(",");
				}
			}
			source.clear();
			window.open("/main/onemap/gaode?start=" + end + "&end=" + start);

			//http://10.100.1.61:5210/tdt/sl_dt/wmts
			/*$.ajax({
				url: mapConfig.tiandituUrl + "LW1/route?REQUEST=FindRoute&SERVICE=ROUTE&VERSION=1.0.0&DATA=lw&ORIG=" + start +
				"&DEST=" + end + "&RADIUS=100&MIDPOS=&AVOIDPOS=&FILTERROUTE=1",
				async: false,
				type: "get",
				error: function (req, err, t) {
					for (var p = 0, q = features.length; p < q; p++) {
						if (features[p].get("name") === "findRoute") {
							source.removeFeature(features[p]);
							break;
						}
					}
					layer.msg("请重新选择起点或者终点！");
				},
				success: function (data) {
					console.log(data);
					var coordinates = [];
					var $xml = $(data);

					for (var p = 0, q = features.length; p < q; p++) {
						if (features[p].get("name") === "findRoute") {
							source.removeFeature(features[p]);
							break;
						}
					}

					if ($xml.find("Route>Geometry").length === 0) {
						layer.msg("请重新选择起点或者终点！");
						return;
					}

					coordinates = $xml.find("Route>Geometry LineString").text().split(" ").map(function (val, index) {
						var p = val.split(",");
						return [parseFloat(p[0]), parseFloat(p[1])]
					});
					coordinates=$.trim($xml.find("Route>Geometry").text()).split(" ").map(function (val, index) {
						var p = val.split(",");
						return [parseFloat(p[0]), parseFloat(p[1])]
					});

					var feature = new ol.Feature({
						geometry: new ol.geom.LineString(coordinates),
						name: "findRoute"
					});
					source.addFeature(feature);
				}
			});*/

		},

		/**
		 * @api {类型 function} 查询天地图中的兴趣点 poiSearch
		 * @apiParam {String} keyword 搜索兴趣点的关键词
		 * @apiParam {String} code 搜索那个图层的分类码
		 * @apiParam {ol.Map} map 地图容器
		 * @apiName poiSearch 
		 * @apiGroup mapTools
		 */
		poiSearch: function (keyword, code, map) {
			if (!keyword) {
				return;
			}
			var overlay = this.overlayFunction();
			var $div = $("#list");
			$div.html(" ");
			code = "&categoryCode=" + code;
			var url = mapConfig.poiUrl + "output=json&version=1.1.0&startPosition=1&reverseMatch=false&semanticAnalysis=true&request=GeoCoder&maxCount=55&service=GeoCoding&scoreFilter=score>=55&keyword=" + keyword + code;
			jQuery.ajax({
				type: "get",
				async: false,
				url: url,
				dataType: "jsonp",
				jsonp: "callback",//传递给请求处理程序或页面的，用以获得jsonp回调函数名的参数名(一般默认为:callback)
				success: function (json) {
					var data = json.results[0].result;
					if (data.length > 15) {
						$("#list").css("height", "530px");
					} else {
						$("#list").css("height", "auto");
					}
					initMap.searchLayer.getSource().clear();
					var features = [];
					var style = new ol.style.Style({
						image: new ol.style.Circle({
							radius: 4,
							fill: new ol.style.Fill({
								color: "#FFCC99"
							}),
							stroke: new ol.style.Stroke({
								color: "#FFFFFF",
								width: 1
							})
						})
					});
					for (var i = 0, z = data.length; i < z; i++) {
						var feature = new ol.Feature({
							geometry: new ol.geom.Point([data[i].poiArray[0].location.lng, data[i].poiArray[0].location.lat]),
							name: data[i].poiArray[0].name,
							id: i.toString()
						});
						feature.setStyle(style);
						features.push(feature);
					}
					initMap.searchLayer.getSource().addFeatures(features);




					//创建查询结果列表
					for (var i = 0, z = features.length; i < z; i++) {
						var aLabel = $("<a></a>");
						var id = features[i].get("id"), name = features[i].get("name");
						aLabel.appendTo($div);
						aLabel.html("<span></span>"+name);
						aLabel.attr("title", name);
						aLabel.attr("id", id);
						aLabel.addClass("listLocation");
						features[i].i = id;
					}
					$div.slideDown("fast");
					// 当点击名称的时候显示数据
					$("#list a").click(function () {
						initMap.map.getOverlays().clear();
						$(this).attr("style", "background-color:#00bfff").siblings().removeAttr("style");
						var featureId = $(this).attr("id");
						for (var j = 0, z = features.length; j < z; j++) {
							if (features[j].get("id") === featureId) {
								var table = features[j].get('name');
								overlay.getElement().lastChild.innerHTML = table;
								initMap.map.addOverlay(overlay);
								overlay.setPosition(features[j].getGeometry().getCoordinates());
								initMap.panToPoint(features[j].getGeometry().getCoordinates());
								break;
							}
						}
					});

				},
				error: function () {
					layer.msg('请输入正确的关键字，并选择正确的分类，然后重新查询');
				}
			});
		},




		/**
		 * @api {类型 function} 用来显示属性查询的数据 attributeQuery
		 * @apiParam {String} typenames 属性查询的图层名称
		 * @apiParam {ol.Map} searchVal 搜索的关键字
		 * @apiName attributeQuery 
		 * @apiGroup mapTools
		 */
		attributeQuery: function (typenames, searchVal) {
			if (!searchVal) {
				layer.msg("请输入关键字");
				return;
			}
			var that = this, searchLayer = initMap.searchLayer, map = initMap.map, element = $("#list");
			element.html("");
			var overlay = this.overlayFunction(), val = "", url;
			if (typenames.indexOf("GEOM_QYJCXX") > -1) {
				val = "QYMC like '%" + searchVal.toString().replace("%", "/%") + "%'";
				url = mapConfig.queryUrl
					+ "service=WFS&version=1.1.0&REQUEST=GetFeature&maxFeatures=30&outputFormat=GML3&typename=HBAJ:"
					+ typenames + "&SRS=EPSG:4326&CQL_FILTER="
					+ encodeURIComponent(val);
				$.ajax({
					type: "POST",
					url: url,
					// data: "",
					contentType: "text/xml",
					success: function (gml) {
						searchLayer.getSource().clear();
						var gml3 = new ol.format.GML3();
						var features = gml3.readFeatures(gml);
						if (features.length > 15) {
							element.css("height", "530px");
						} else {
							element.css("height", "auto");
						}

						searchLayer.getSource().addFeatures(features);
						element.html(" ");
						for (var i = 0, z = features.length; i < z; i++) {
							var aLabel = $("<a></a>").html("<span></span>"+features[i].get("QYMC"))
								.attr({ "title": features[i].get("QYMC"), "id": features[i].i, "class": "listLocation" })
								.appendTo(element);
						}
						element.slideDown("fast");
						//element.find(".listLocation").css({"text-overflow": "ellipsis","white-space":"nowrap","overflow":"hidden"});
						var isSearch = this.getLayerById(map, "searchLayer");
						if (isSearch !== true) {
							map.addLayer(searchLayer);
						}
						var ids = "";
						for (var m = 0, n = features.length; m < n; m++) {
							if (m !== n - 1) {
								ids += features[m].i.split(".")[1];
								ids += ",";
							} else {
								ids += features[m].i.split(".")[1];
							}
						}

						$.post("/main/qyjcxxManager/getQyBusinessInformationForMap", { ids: ids }, function (data) {
							var obj = JSON.parse(data);
							// 如果点击的位置没有相应企业，报错以后，清除i查询中的map的click事件
							try {
								element.find("a").click(function () {
									map.getOverlays().clear();
									$(this).css("color", "rgb(244,126,54)").siblings().css("color", "#555");
									var featureId = $(this).attr("id");
									for (var j = 0, z = features.length; j < z; j++) {
										if (features[j].i === featureId) {
											var table = '<a class="am-btn am-btn-link" title="' + features[j].get("QYMC") + '" href="javascript:void(0);" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:300px;" ids="' + features[j].i.split(".")[1] + '">' + features[j].get("QYMC") + '</a>';
											overlay.getElement().lastChild.innerHTML = table;
											$(".ssk_dss").val(features[j].get("QYMC"));
											map.addOverlay(overlay);
											overlay.setPosition(features[j].getGeometry().getCoordinates());
											initMap.panToPoint(features[j].getGeometry().getCoordinates());
											$(".am-btn.am-btn-link").click(function () {
												for (var p = 0, q = obj.length; p < q; p++) {
													if (obj[p].id === $(this).attr("ids")) {
														that.openDetail(obj[p].url, obj[p].type, obj[p].width, obj[p].height, obj[p].title, true);
														break;
													}
												}
											});
											break;
										}
									}
								});
							} catch (error) {
								map.unByKey(key);
							}
						});

					},
					error: function () {
						layer.msg("请输入正确的关键字搜索");
					},
					context: this
				});
			} else {
				url = layerConfig.searchLy[typenames] + "?keyword=" + searchVal;
				$.get(url).done(function (data) {
					var obj = JSON.parse(data), features = [];
					if (obj.length > 15) {
						element.css("height", "530px");
					} else {
						element.css("height", "auto");
					}
					for (var i = 0, z = obj.length; i < z; i++) {
						var aLabel = $("<a></a>").html(obj[i].name)
							.attr({ "title": obj[i].name, "id": obj[i].id, "class": "listLocation", "lon": obj[i].lon, "lat": obj[i].lat })
							.appendTo(element);
						features.push(new ol.Feature({
							geometry: new ol.geom.Point([parseFloat(obj[i].lon), parseFloat(obj[i].lat)])
						}));
					}
					element.slideDown("fast");
					searchLayer.getSource().addFeatures(features);
					element.find("a").on("click", function (evt) {
						$(this).css("color", "rgb(244,126,54)").siblings().css("color", "#0066cc");
						if (evt.target.tagName === "A") {
							var id = evt.target.id;
							var infoUrl = layerConfig.infoLy[typenames] + "?id=" + id;
							map.getOverlays().clear();
							$.get(infoUrl).done(function (data) {
								judge.getInfo(typenames, JSON.parse(data), overlay.getElement().lastChild);
								map.addOverlay(overlay);
								var point = [parseFloat(evt.target.getAttribute("lon")), parseFloat(evt.target.getAttribute("lat"))];
								overlay.setPosition(point);
								initMap.panToPoint(point);
								$(overlay.getElement().lastChild).off();//移除上一次添加的click事件
								 $(overlay.getElement().lastChild).on("click","p:last span:last",function(){
			                        	judge.openDetail(typenames,id);
			                        })
							})
						}
					});
				})
			}

			//element.style.display = "block";

		},
		//根据不同图层，使用不同的请求地址获得相应名称
		/**
		 * @api {类型 function} i查询根据不同图层，使用不同的请求地址获得不同列表数据 getUrl
		 * @apiParam {String} layerName 专题图图层名称
		 * @apiName getUrl 
		 * @apiGroup mapTools
		 */
		getUrl: function (layerName) {
			var url = "";
			switch (layerName) {
				case "GEOM_QYJCXX"://企业信息
					//url="/main/qyjcxxManager/qyMapOpen";
					url = "/main/qyjcxxManager/getQyBusinessInformationForMap";
					break;
				case "GEOM_YJZY_YJJYDW": //救援队伍
					url = "/main/yjzyManager/jydwMapOpen";
					break;
				case "GEOM_YJZY_YJJYZB":   //救援装备
					url = "/main/yjzyManager/jyzbMapOpen";
					break;
				case "GEOM_LAWINFO_PLAN":   //执法监察
					url = "/main/lawinfosec/getlawinfoseclistbyids";
					break;
				case "GEOM_STANDARD":                  //标准化
					url = "/main/unifyStandard/standardEntInfo";
					break;
				case "GEOM_WXYHZB":           //重大危险源
					url = "/main/zdwxySqManage/getZdwxyListForMap";
					break;
				case "GEOM_DYJYA_BASQB":                //应急预案
					url = "/main/yjyabasqbManager/getYjyaListForMap";
					break;
				case "GEOM_YJYA_YJWZ":                //应急物资
					url = "/main/yjyabasqbManager/getYjWzListForMap";
					break;
				case "GEOM_Danger_Report":   //隐患排查
					url = "/main/danger/getDangerNamesByIds";
					break;
				case "GEOM_SGBS":            //事故
					url = "/main/accident/accidentMapOne";
					break;
				case "GEOM_YJSJ":            //应急事件
					url = "/main/emer/iSearchYjjy";
					break;
				case "GEOM_HON_CHMAIN":            //诚信企业
					url = "/main/appli/chengxinMapOne";
					break;
				case "GEOM_ZYBWH":  //职业病危害等级
					url = "/main/qyjcxxManager/getQyBusinessInformationForMap";
					break;
				case "GEOM_FIREWORKS":  //烟花爆竹
					url = "/main/firework/openyanhuamap";
					break;
				case "GEOM_ZJJG":  //中介服务机构
					url = "/main/qyjcxxManager/getQyBusinessInformationForMap";
					break;
				case "GEOM_REGULATION_SUBJECT":  //监管主题
					url = "/main/qyjcxxManager/getQyBusinessInformationForMap";
					break;
				case "GEOM_SUPERVISION":   //监管监察
					url = "/main/superVisionRecord/iSearchJgJc";
					break;
				case "GEOM_SPECIAL":   //专项检查
					url = "/main/superspecialrecord/iSearchzxjc";
					break;
				case "GEOM_EMERG_RESPONSE":   //应急响应
					url = "/main/yjxy/openyjxymap";
					break;
				case "GEOM_WKK":   //尾矿库
					url = "/main/wkk/wkkMapOpen";
					break;
				case "GEOM_KSK":   //矿山库
					url = "/main/wkk/kskMapOpen";
					break;
			}

			return url;
		},
		//关闭卷帘功能
		/**
		 * @api {类型 function} 关闭卷帘功能 closeSwipe
		 * @apiParam {ol.Map} map 地图容器
		 * @apiName closeSwipe 
		 * @apiGroup mapTools
		 */
		closeSwipe: function (map) {
			var arr = this.swipeKey;
			var un = new ol.Observable();
			for (var i = 0, z = arr.length; i < z; i++) {
				un.unByKey(arr[i]);
			}
			$("#map").off("mousemove");
			$("#map").css("cursor", "default");
			initMap.tiandituSatellite.setVisible(false);
		},
		//地图卷帘渲染事件key值
		swipeKey: [],
		//开启卷帘功能
		/**
		 * @api {类型 function} 开启卷帘功能 openSwipe
		 * @apiParam {ol.Map} map 地图容器
		 * @apiName openSwipe 
		 * @apiGroup mapTools
		 */
		openSwipe: function (map) {
			if ($("#vectorMap span").attr("class").indexOf("primary") === -1) {
				$("#vectorMap span").addClass("am-badge-primary");
				$("#satelliteImage span").removeClass("am-badge-primary");
				initMap.tiandituVector.setVisible(true);
				initMap.tiandituSatellite.setVisible(false);
			}
			var height = 0;
			var satellite = initMap.tiandituSatellite.getLayers().getArray();
			initMap.tiandituSatellite.setVisible(true);
			//initMap.tiandituVector.setVisible(true);
			this.swipeKey.push(satellite[0].on('precompose', function (event) {
				var ctx = event.context;
				var width = height;

				ctx.save();
				ctx.beginPath();
				ctx.rect(width, 0, ctx.canvas.width - width, ctx.canvas.height);
				ctx.clip();
			}));

			this.swipeKey.push(satellite[0].on('postcompose', function (event) {
				var ctx = event.context;
				ctx.restore();
			}));

			this.swipeKey.push(satellite[1].on('precompose', function (event) {
				var ctx = event.context;
				var width = height;
				ctx.save();
				ctx.beginPath();
				ctx.rect(width, 0, ctx.canvas.width - width, ctx.canvas.height);
				ctx.clip();
			}));

			this.swipeKey.push(satellite[1].on('postcompose', function (event) {
				var ctx = event.context;
				ctx.restore();
			}));


			$("#map").on("mousemove", function (evt) {
				height = evt.clientX
				map.render();
			});
			$("#map").css("cursor", "e-resize");
		},
		//根据不同图层，获得不同图层的等级列表
		/**
		 * @api {类型 function} 根据不同图层，获得不同图层的等级列表 getTitles
		 * @apiParam {String} layerName 图层名称
		 * @apiName getTitles 
		 * @apiGroup mapTools
		 */
		getTitles: function (layerName) {
			var titles = "";
			switch (layerName) {
				case "GEOM_QYJCXX"://企业信息
					url = "/main/qyjcxxManager/qyMapOpen";
					break;
				case "GEOM_YJZY_YJJYDW": //救援队伍
					url = "/main/yjzyManager/jydwMapOpen";
					break;
				case "GEOM_YJZY_YJJYZB":   //救援装备
					url = "/main/yjzyManager/jyzbMapOpen";
					break;
				case "GEOM_LAWINFO_PLAN":   //执法监察
					titles = ["执法监察"];
					break;
				case "GEOM_VB_TARGET":   //脆弱性目标
					titles = ["脆弱性目标"];
					break;
				case "GEOM_STANDARD":                  //标准化
					titles = ["一级", "二级", "三级", "已达标", "未达标"];
					break;
				case "GEOM_WXYHZB":           //重大危险源
					titles = ["一级", "二级", "三级", "四级"];
					break;
				case "GEOM_DYJYA_BASQB":                //应急预案
					titles = ["国家级", "省部级", "地市级", "县级", "基层级", "集团级", "公司级", "厂级", "车间级"];
					break;
				case "GEOM_RISK_POINT":                //风险点
					titles = ["重大风险","较大风险","一般风险","低风险"];
					break;
				case "GEOM_Danger_Report":   //隐患排查
					titles = ["重大隐患", "一般隐患"];
					break;
				case "GEOM_SGBS":            //事故
					titles = ["特别重大事故", "重大事故", "较大事故", "一般事故"];
					break;
				case "GEOM_HON_CHMAIN":            //诚信企业
					titles = ["A级", "B级", "C级", "D级"];
					break;
				case "GEOM_ZYBWH":            //职业病危害
					titles = ["严重", "较重", "一般", "未知"];
					break;
			}
			return titles;
		},

		/*
		 * 汽车实时位置
		 * @param plateno 车牌号
		 * @param type  汽车类型
		 * */

		currentLocation: function (plateno, type) {
			var that = this;
			that.closeTrack();
			initMap.animationLay.getSource().clear();
			$.post("/main/vehicle/getVehicleLastPort?plateno=" + plateno, function (data) {
				var obj = JSON.parse(data);
				if (obj.longitude !== undefined) {
					var feature = new ol.Feature({
						geometry: new ol.geom.Point([parseFloat(obj.longitude), parseFloat(obj.latitude)]),
						cameraid: obj.cameraid
					});
					initMap.panToPoint2([parseFloat(obj.longitude), parseFloat(obj.latitude)]);
					feature.setStyle(initMap.setCarStyle("1121"));
					initMap.animationLay.getSource().addFeature(feature);
				} else {
					clearInterval(initMap.stopAnim);
					layer.msg("暂时没有实时数据");
				}
			});
		},

		/*
		 * 汽车实时位置
		 * @param id 车辆ID
		 * */
		/**
		 * @api {类型 function} 汽车实时位置 currentLocation2
		 * @apiParam {String} id 车辆ID
		 * @apiParam {Object} mapTools 地图工具对象，是mapTools本身
		 * @apiName currentLocation2 
		 * @apiGroup mapTools
		 */
		currentLocation2: function (id, mapTools) {
			var that = mapTools;
			// that.closeTrack();
			cancelAnimationFrame(initMap.requestAnimationKey)
			initMap.animationLay.getSource().clear();
			$.post("/main/vehicle/getVehicleLastPort", { deviceid: id }, function (data) {
				var obj = JSON.parse(data);
				if (obj.longitude !== undefined) {
					var feature = new ol.Feature({
						geometry: new ol.geom.Point([parseFloat(obj.longitude), parseFloat(obj.latitude)]),
						cameraid: obj.cameraid
					});
					initMap.panToPoint2([parseFloat(obj.longitude), parseFloat(obj.latitude)]);
					feature.setStyle(initMap.setCarStyle("1121"));
					initMap.animationLay.getSource().addFeature(feature);
				} else {
					clearInterval(initMap.stopAnim);
					layer.msg("暂时没有实时数据");
				}
			});
		},
		stopAnim: "",
		/**
		 * @api {类型 function} 清除车辆历史轨迹 closeTrack
		 * @apiName closeTrack 
		 * @apiGroup mapTools
		 */
		closeTrack: function () {
			clearInterval(this.stopAnim);
			cancelAnimationFrame(initMap.requestAnimationKey)
			initMap.animationLay.getSource().clear();
		},
		/*
		 * @param start 起点
		 * @param end   终点
		 * @param ratio 比例
		 * */
		addPoint: function (start, end, ratio) {
			try {
				if (end[0] - start[0] > 180)//比如从-179到179
					end[0] -= 360;
				else if (end[0] - start[0] < -180)//比如从179到-179
					end[0] += 360;
				var delta = [end[0] - start[0], end[1] - start[1]];
				var offset = [delta[0] * ratio, delta[1] * ratio];
				return [start[0] + offset[0], start[1] + offset[1]];
			} catch (e) {
				console.log("经纬度有误");
			}
		},
		/*
		 * 历史轨迹
		 * @param id 车辆ID
		 * @param starttime  起始时间
		 * @param endtime  结束时间
		 * */
		/**
		 * @api {类型 function} 汽车实时位置 historyTrack
		 * @apiParam {String} id 车辆ID
		 * @apiParam {String} starttime 起始时间
		 * @apiParam {String} endtime 结束时间
		 * @apiName historyTrack 
		 * @apiGroup mapTools
		 */
		historyTrack: function (id, starttime, endtime) {
			var that = this;
			layer.close(layer.index);
			initMap.animationLay.getSource().clear();
			$.post("/main/vehicle/getVehicleGuiji", { deviceid: id, starttime: starttime, endtime: endtime, length: 0 }, function (data) {
				var obj = JSON.parse(data);
				if (obj.length !== 0) {
					var animationLayer = initMap.animationLay.getSource();
					var points = [];
					for (var i = 0, z = obj.length - 1; i < z; i++) {
						var lon = parseFloat(obj[i].longitude), lat = parseFloat(obj[i].latitude);
						var lon2 = parseFloat(obj[i + 1].longitude), lat2 = parseFloat(obj[i + 1].latitude);
						for (var p = 0; p < 100; p++) {

							if (p == 99) {
								points.push([[lon2, lat2], obj[i].direction]);
							} else {

								points.push([that.addPoint([lon, lat], [lon2, lat2], p / 100.0), obj[i].direction]);
							}
						}
					}

					var linePoints = [];
					for (i = 0, z = obj.length; i < z; i++) {
						linePoints.push([parseFloat(obj[i].longitude), parseFloat(obj[i].latitude)]);
					}
					var line = new ol.Feature({
						geometry: new ol.geom.LineString(linePoints)
					});
					var lineStyle = new ol.style.Style({
						stroke: new ol.style.Stroke({
							width: 4,
							color: "#ff0000"
						})
					});
					line.setStyle(lineStyle);
					animationLayer.addFeature(line);
					var j = 0;
					initMap.panToPoint3(points[j][0], 16);
					function animation() {
						//console.log(points[j][0]);
						var feature = new ol.Feature({
							geometry: new ol.geom.Point(points[j][0]),
							id: "animation"
						});
						for (var m = 0, n = animationLayer.getFeatures().length; m < n; m++) {
							if (animationLayer.getFeatures()[m].get("id")) {
								animationLayer.removeFeature(animationLayer.getFeatures()[m]);
							}
						}
						var angle = 0;
						if (parseFloat(points[j][1].direction) !== 0) {
							angle = parseFloat(points[j][1].direction) * (Math.PI / 180.0) - Math.PI / 2;
						}
						var style = initMap.setCarStyle("1121", angle);
						feature.setStyle(style);
						animationLayer.addFeature(feature);
						j++;
						if (j >= points.length * 100) {
							return;
						}
						initMap.requestAnimationKey = requestAnimationFrame(animation);
					}
					animation();

				} else {
					layer.msg("此时间段没有历史轨迹信息");
				}
			});
		},
		/**
		 * @api {类型 function} 汽车实时位置 openDetail
		 * @apiParam {String} url 弹出框的url地址
		 * @apiParam {String} type 弹出类型1为弹出框，2为tab页
		 * @apiParam {String} width 弹出框宽度
		 * @apiParam {String} height 弹出框高度
		 * @apiParam {String} title 弹出框标题
		 * @apiParam {Boolean} isOffset 是否需要按照点位置居中
		 * @apiName openDetail 
		 * @apiGroup mapTools
		 */
		openDetail: function (url, type, width, height, title, isOffset) {
			if (type == "1") {//弹出层 
				var top, left;
				if (isOffset) {
					top = parseFloat($(".ol-overlay-container").css("top")) - 152;
					left = parseFloat($(".ol-overlay-container").css("left")) - 225;
					var z = layer.open({
						type: 2,
						offset: [top, left],
						skin: "dome-layer",
						title: title,
						area: [width, height],
						fix: false, //不固定
						content: url,
						btn: false,
						closeBtn: 1,
						success: function (layero, index) {
							$(layero).css("background", "none");
						},
						end: function () {
						}
					});
				} else {
					var z = layer.open({
						type: 2,
						skin: "dome-layer",
						title: title,
						area: [width, height],
						fix: false, //不固定
						content: url,
						btn: false,
						closeBtn: 1,
						success: function (layero, index) {
							$(layero).css("background", "none");
						},
						end: function () {
						}
					});
				}


			} else if (type == "2") {//tab页
				window.parent.commonAddTabs(title, url);
			}
		}
		,
		/**
		 * 创建一个地图弹出框，显示相应信息
		 * 
		 * @returns {ol.Overlay()}
		 */
		/**
		 * @api {类型 function} 创建一个地图弹出框，显示相应信息 overlayFunction
		 * @apiName overlayFunction 
		 * @apiGroup mapTools
		 */
		overlayFunction: function () {
			// 创建弹出框的div
			var popup = document.createElement('div');
			popup.className = 'ol-popup';
			// 创建弹出来框用来显示内容的div
			var popupContent = document.createElement('div');
			popupContent.id = 'popup-content';
			// 创建弹出框右上角的关闭按钮
			var closer = document.createElement('a');
			closer.id = 'popop-closer';
			closer.className = 'ol-popup-closer';
			closer.href = '#';

			// 把div和a标签放入弹出框的div中
			popup.appendChild(closer);
			popup.appendChild(popupContent);
			var overlay = new ol.Overlay({
				element: popup,
				autoPan: true,
				autoPanAnimation: undefined
			});

			closer.onclick = function () {
				overlay.setPosition(undefined);
				closer.blur();
				initMap.themeSelect.getFeatures().clear();
				return false;
			};
			return overlay;
		},
		//车辆超速显示
		/**
		 * @api {类型 function} 车辆超速显示 overspeed
		 * @apiParam {String} id 车辆ID
		 * @apiParam {ol.Map} map 地图容器
		 * @apiName overspeed 
		 * @apiGroup mapTools
		 */
		overspeed: function (id, map) {
			var that = this;
			$.post("/main/vehicle/getVehicleLastSpeedout", { deviceid: id }, function (data) {
				var obj = JSON.parse(data);
				if (obj.lon) {
					initMap.animationLay.getSource().clear();
					var feature = new ol.Feature(new ol.geom.Point([parseFloat(obj.lon), parseFloat(obj.lat)]));
					feature.setStyle(initMap.setCarStyle("1121"));
					initMap.animationLay.getSource().addFeature(feature);
					map.getOverlays().clear();
					var overlay = that.overlayFunction();
					map.addOverlay(overlay);
					var str = "超速起始时间为：" + obj.begtime + ";超速持续时间为：" + (Math.round(parseInt(obj.times) / 60.0)) + "分";
					overlay.getElement().children[1].innerHTML = str;
					overlay.setPosition([parseFloat(obj.lon), parseFloat(obj.lat)]);
					initMap.panToPoint([parseFloat(obj.lon), parseFloat(obj.lat)]);
				}
			});
		},
		//车辆最后停止超时位置
		vehicleLastPosition: function (id, map) {
			var that = this;
			$.post("/main/vehicle/getVehicleLastTimeout", { deviceid: id }, function (data) {
				var obj = JSON.parse(data);
				if (obj.lon) {
					initMap.animationLay.getSource().clear();
					var feature = new ol.Feature(new ol.geom.Point([parseFloat(obj.lon), parseFloat(obj.lat)]));
					feature.setStyle(initMap.setCarStyle("1121"));
					initMap.animationLay.getSource().addFeature(feature);
					var overlay = that.overlayFunction();
					map.addOverlay(overlay);
					var str = "超时起始时间为：" + obj.begtime + ";超时持续时间为：" + (parseFloat(obj.times) / 60.0) + "分";
					overlay.getElement().children[1].innerHTML = str;
					overlay.setPosition([parseFloat(obj.lon), parseFloat(obj.lat)]);
					initMap.panToPoint([parseFloat(obj.lon), parseFloat(obj.lat)]);
				}
			});
		},
		//显示监管图层或者隐藏
		superviseLayer: function (styleName) {
			if (initMap.supervise.getSource().getParams().STYLES === styleName) {
				initMap.supervise.setVisible(false);
			} else {
				initMap.supervise.setVisible(true);
				initMap.supervise.getSource().updateParams({ STYLES: styleName });
			}
		},
		//绘制简单箭头
		/**
		 * @api {类型 function} 绘制简单箭头 simpleArrow
		 * @apiParam {ol.Map} map 地图容器
		 * @apiParam {ol.source.Vector} source 标绘箭头即将绘制到的矢量图层
		 * @apiName simpleArrow 
		 * @apiGroup mapTools
		 */
		simpleArrow: function (map, source) {
			var draw = new ol.interaction.Draw({
				source: source,
				type: "LineString",
				maxPoints: 2,
				geometryFunction: function (coordinates, geometry) {
					if (!geometry) {
						geometry = new ol.geom.LineString(coordinates);
					} else {
						var arrPtn = plot.createArrow(coordinates);
						geometry.setCoordinates(arrPtn);
					}
					return geometry;
				}
			});
			map.addInteraction(draw);
			return draw;
		},
		//绘制直箭头
		/**
		 * @api {类型 function} 绘制直箭头 fineArrow
		 * @apiParam {ol.Map} map 地图容器
		 * @apiParam {ol.source.Vector} source 标绘箭头即将绘制到的矢量图层
		 * @apiName fineArrow 
		 * @apiGroup mapTools
		 */
		fineArrow: function (map, source) {
			var draw = new ol.interaction.Draw({
				source: source,
				type: "LineString",
				maxPoints: 2,
				geometryFunction: function (coordinates, geometry) {
					if (!geometry) {
						geometry = new ol.geom.Polygon([coordinates]);
					} else {
						var arrPtn = plot.createFineArrow(coordinates);
						geometry.setCoordinates([arrPtn]);
					}
					return geometry;
				}
			});
			map.addInteraction(draw);
			return draw;
		},
		//绘制长箭头
		/**
		 * @api {类型 function} 绘制直箭头 longArrow
		 * @apiParam {ol.Map} map 地图容器
		 * @apiParam {ol.source.Vector} source 标绘箭头即将绘制到的矢量图层
		 * @apiName longArrow 
		 * @apiGroup mapTools
		 */
		longArrow: function (map, source) {
			var draw = new ol.interaction.Draw({
				source: source,
				type: "LineString",
				maxPoints: 3,
				geometryFunction: function (coordinates, geometry) {
					if (!geometry) {
						geometry = new ol.geom.Polygon([coordinates]);
					} else {
						var arrPtn = plot.createLongArrow(coordinates);
						geometry.setCoordinates(arrPtn);
					}
					return geometry;
				}
			});
			map.addInteraction(draw);
			return draw;
		},
		//绘制聚集地
		/**
		 * @api {类型 function} 绘制直箭头 drawHabitation
		 * @apiParam {ol.Map} map 地图容器
		 * @apiParam {ol.source.Vector} source 标绘箭头即将绘制到的矢量图层
		 * @apiName drawHabitation 
		 * @apiGroup mapTools
		 */
		drawHabitation: function (map, source) {
			var draw = new ol.interaction.Draw({
				source: source,
				type: "LineString",
				maxPoints: 2,
				geometryFunction: function (coordinates, geometry) {
					if (!geometry) {
						geometry = new ol.geom.Polygon([coordinates]);
					} else {
						var arr, arrPtn;
						if (coordinates.length > 2) {
							arr = coordinates.slice(0, 2);
							arrPtn = plot.createHabitation(arr);
						} else {
							arrPtn = plot.createHabitation(coordinates);
						}
						geometry.setCoordinates(arrPtn);
					}
					return geometry;
				}
			});
			map.addInteraction(draw);
			return draw;
		}
		,
		/**
		 *@param name String 城市名称
		 *@param view ol.View 
		* 获得地级市的面
		* @param ol.Map map 
		*/
		/**
		 * @api {类型 function} 获得当前用户的面 getCityPolygon
		 * @apiParam {String} name 城市名称
		 * @apiParam {ol.View} view 地图视图容器
		 * @apiParam {Array} center 地图中心点，当只有是县级时才使用
		 * @apiName getCityPolygon 
		 * @apiGroup mapTools
		 */
		getCityPolygon: function (name, view, center) {
			var str = '<ogc:Filter xmlns:ogc="http://www.opengis.net/ogc"> <ogc:PropertyIsEqualTo> <ogc:PropertyName>NAME</ogc:PropertyName> <ogc:Literal>' + name + '</ogc:Literal> </ogc:PropertyIsEqualTo> </ogc:Filter>';
			/*function trim(str) {
			 	return  str.replace(/^\s*(.*?)[\s\n]*$/g,'$1');
			}*/
			$.ajax({
				url: mapConfig.tiandituUrl + "HBBOU/wfs?" + "VERSION=1.1.0&SERVICE=WFS&REQUEST=GetFeature&TYPENAME=HBBOUPY&FILTER=" + str,
				data: "",
				type: "GET",
				contentType: 'application/xml;charset=utf-8',
				cache: true,
				success: function (data) {
					try {
						var $xml = $(data), pos = [], points = [];
						$xml.find("posList").html().split(" ").forEach(function (val) {
							var number = parseFloat(val);
							if (number > 0) {
								pos.push(number);
							}
						});
						pos.reverse();
						for (var i = 0, z = pos.length; i < z; i += 2) {
							points.push([pos[i], pos[i + 1]]);
						}
						var feature = new ol.Feature({
							geometry: new ol.geom.LineString(points)
						});
						view.setCenter(ol.extent.getCenter(feature.getGeometry().getExtent()));
						initMap.dijishiLayer.getSource().addFeature(feature);
					} catch (e) {
						$.get(mapConfig.bufferUrl + "service=WFS&version=1.0.0&REQUEST=GetFeature&typeName=HBAJ:hbcounty&srsName=EPSG:4326&outputFormat=application/json&CQL_FILTER=name='" + name + "'", function (json) {
							var format = new ol.format.GeoJSON();
							var fs = [];
							for (var m = 0, n = json.features.length; m < n; m++) {
								var f = new ol.Feature({
									geometry: new ol.geom.MultiPolygon(json.features[m].geometry.coordinates)
								});
								fs.push(f);
							}
							initMap.dijishiLayer.getSource().addFeatures(fs);
							view.setCenter(center);
							view.setZoom(12);
						});
					}

				}
			});
		},
		/**
		 * @api {类型 function} 根据不同的缩放级别显示不同 zoomStatistics
		 * @apiParam {ol.Map} map 地图容器
		 * @apiName zoomStatistics 
		 * @apiGroup mapTools
		 */
		zoomStatistics: function (layerName, obj) {
			var zoom = initMap.map.getView().getZoom();
			if (zoom >= 9) {
				this.getCountyData(layerName, obj);
			}
			if (zoom <= 8) {
				this.showData(layerName, obj);
			}
		},
		/**
		 * @api {类型 function} 点击统计数字显示概要信息列表，当点击列表的时候显示概要信息 showSummary
		 * @apiParam {String} currentLayer 当前图层
		 * @apiParam {String} id 概要信息
		 * @apiParam {ol.Overlay} overlay 概要信息的弹出气泡
		 * @apiParam {Array} position 位置信息
		 * @apiName showSummary 
		 * @apiGroup mapTools
		 */
		showSummary:function(currentLayer,id,overlay,position,qymc){
			var that=this;
			initMap.map.getOverlays().clear();
			if(currentLayer==="GEOM_QYJCXX"){
				var table = '<a class="am-btn am-btn-link" title="' + qymc + '" href="javascript:void(0);" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:300px;" ids="' + id + '">' + qymc + '</a>';
				overlay.getElement().lastChild.innerHTML = table;
				initMap.map.addOverlay(overlay);
				overlay.setPosition(position);
				initMap.panToPoint(position);
				$.post("/main/qyjcxxManager/getQyBusinessInformationForMap", { ids: id }, function (data) {
					var obj = JSON.parse(data);
					$(".am-btn.am-btn-link").click(function () {
						that.openDetail(obj[0].url, obj[0].type, obj[0].width, obj[0].height, obj[0].title, true);
					});
				})
			}else if(currentLayer==="GEOM_WXYQY"){//危险源企业
				var table = '<a class="am-btn am-btn-link" title="' + qymc + '" href="javascript:void(0);" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:300px;" ids="' + id + '">' + qymc + '</a>';
				overlay.getElement().lastChild.innerHTML = table;
				initMap.map.addOverlay(overlay);
				overlay.setPosition(position);
				initMap.panToPoint(position);
				$("#popup-content a").click(function(){
					layer.open({
						type:2,
						title:qymc,
						content:"/main/zdwxySqManage/zdwxyHzblistForMap?qyguid="+id,
						area:["500px","500px"]
					});
				});
				
			}else{
				var infoUrl = layerConfig.infoLy[currentLayer] + "?id=" + id;
				$.get(infoUrl).done(function (data) {
					judge.getInfo(currentLayer, JSON.parse(data), overlay.getElement().lastChild);
					initMap.map.addOverlay(overlay);
					overlay.setPosition(position);
					initMap.panToPoint(position);
					$(overlay.getElement().lastChild).off("click");
	                $(overlay.getElement().lastChild).on("click","p:last span:last",function(){
	                	judge.openDetail(currentLayer,id);
	                })
				})
			}
			
		},
		/**
		 * @api {类型 function} 点击应急救援图层时，显示当前点的概要信息 emergencyRescue
		 * @apiParam {ol.Map} map 地图容器
		 * @apiParam {Boolean} state 是否是历史响应信息
		 * @apiName emergencyRescue 
		 * @apiGroup mapTools
		 */
		emergencyRescue: function (id,position,state) {
			initMap.map.getOverlays().clear();
			var overlay = this.overlayFunction();
			var infoUrl = layerConfig.infoLy["GEOM_EMERG_RESPONSE"] + "?id=" + id;
			$.get(infoUrl).done(function (data) {
				judge.getInfo("GEOM_EMERG_RESPONSE", JSON.parse(data), overlay.getElement().lastChild);
				if(!state){//如果点击的应急响应点是历史信息则添加辅助决策方案
					overlay.getElement().lastChild.innerHTML=overlay.getElement().lastChild.innerHTML+"<p><span>辅助决策方案</span></p>";
				}
				initMap.map.addOverlay(overlay);
				overlay.setPosition(position);
				initMap.panToPoint(position);
                $(overlay.getElement().lastChild).on("click","p span",function(){
                	if($(this).text()==="查看详情"){
                		judge.openDetail("GEOM_EMERG_RESPONSE",id);
                	}
                	else if($(this).text()==="辅助决策方案"){
                		window.parent.parent.commonAddTabs("救援方案","/main/yjxy/yjczfaDetail?respguid="+layerConfig.emergencyId+"&readonly=false");
                	}
                })
			})
			
			
		},
		/**
		 * @api {类型 function} 根据不同层级和不同图层显示不同的统计数字 difLevelData
		 * @apiParam {String} currentLayer 当前图层名称
		 * @apiParam {String} params 其他过滤条件的参数
		 * @apiName difLevelData 
		 * @apiGroup mapTools
		 */
		difLevelData:function(currentLayer,params){
			var that=this;
			var zoom=initMap.map.getView().getZoom();
			  if(zoom<=8){
				  that.showData(currentLayer,params);
			  }else{
				  that.getCountyData(currentLayer,params);
			  }
		},
		/**
		 * @api {类型 function} 测量面积 measureArea
		 * @apiParam {ol.Map} map 地图容器
		 * @apiName measureArea 
		 * @apiGroup mapTools
		 */
		measureArea: function (map) {
			var that = this;
			if (!this.isActive) {
				return;
			}
			this.isActive = false;

			$("#map").css("cursor", "url(" + mapConfig.meatureIcon + "),auto");
			//禁止地图上的双击放大
			map.getInteractions().getArray()[1].setActive(false);
			//创建测量绘制的面所在的图层
			var vectorSource = new ol.source.Vector();
			var vectorLayer = new ol.layer.Vector({
				source: vectorSource
			});
			map.addLayer(vectorLayer);
			//添加绘图工具
			var draw = new ol.interaction.Draw({
				type: 'Polygon',
				source: vectorSource
			});
			map.addInteraction(draw);

			//地图上单击事件的key值
			var mapClick;
			//创建点的样式
			var pointStyle = new ol.style.Style({
				image: new ol.style.Circle({
					radius: 5,
					stroke: new ol.style.Stroke({
						color: "#ff0000",
						width: "2"
					}),
					fill: new ol.style.Fill({
						color: "#00ff00"
					})
				})
			});


			//创建测量帮助提示
			var helpDiv = document.createElement('div');
			helpDiv.innerHTML = '单击开始测量';
			helpDiv.id = 'overlay';
			helpDiv.className = 'ol-tooltip';
			var overlayHelp = new ol.Overlay({
				element: helpDiv,
				offset: [15, 0],
				positioning: 'center-left'
			});
			map.addOverlay(overlayHelp);



			//创建测量结果显示
			var resultDiv = document.createElement('div');
			resultDiv.innerHTML = "0";
			resultDiv.id = 'measureResult';
			resultDiv.className = 'ol-tooltip ol-tooltip-measure';
			var overlayMeasure = new ol.Overlay({
				element: resultDiv,
				offset: [0, -15],
				positioning: 'bottom-center'
			});
			map.addOverlay(overlayMeasure);

			//当鼠标移动时，帮助提示跟随鼠标移动
			var pointerMove = map.on('pointermove', function (e) {
				overlayHelp.setPosition(e.coordinate);
			});



			draw.on('drawstart', function (e) {
				//当触发绘制开始事件时，给地图添加单击事件
				mapClick = map.on('click', function (evt) {
					var featurePoint = new ol.Feature({
						geometry: new ol.geom.Point(evt.coordinate)
					});
					featurePoint.setStyle(pointStyle);
					vectorSource.addFeature(featurePoint);
				});
				var drawFeature = e.feature;
				document.getElementById('measureResult').style.display = 'block';
				document.getElementById('overlay').innerHTML = '双击以结束测量';
				var drawStartKey = drawFeature.get('geometry').on('change', function (evt) {
					overlayMeasure.setPosition(evt.target.getInteriorPoint().getCoordinates());
					var measureResult = document.getElementById('measureResult');
					var area = drawFeature.get('geometry').clone().transform("EPSG:4326", "EPSG:3857").getArea();
					if (area > 10000) {
						area = (Math.round(area / 1000000 * 100) / 100) + "km<sup>2</sup>";
					} else {
						area = (Math.round(area * 100) / 100) + "m<sup>2</sup>";
					}
					measureResult.innerHTML = area;
				});
			});


			draw.on("drawend", function (e) {
				$("#map").css("cursor", "default");
				var createElement = document.getElementById('measureResult');
				var createA = document.createElement('a');
				createA.style.zIndex = 100;
				createA.style.background = 'rgba(0, 0, 0, 0.5)';
				createA.className = 'ol-popup-closer ol-popup-closer2';
				createElement.appendChild(createA);
				//给x符号添加事件，用来取消所画的折线
				createA.onclick = function () {
					map.removeOverlay(overlayMeasure);
					createA.blur();
					map.removeLayer(vectorLayer);
					//当测量结果被关闭以后才可以双击放大
					map.getInteractions().getArray()[1].setActive(true);
					return false;
				}
				//移除鼠标移动事件
				map.unByKey(pointerMove);
				//移除overlay
				map.removeOverlay(overlayHelp);
				//移除绘制工具
				map.removeInteraction(draw);
				that.isActive = true;
				map.unByKey(mapClick);
			});
		},
		//获取渐变色
		getGradientColor:function(color,num,feature){
		    var canvas = document.createElement('canvas');
		    var context = canvas.getContext('2d');
		    var pixelRatio = ol.has.DEVICE_PIXEL_RATIO;
		    var extent = feature.getGeometry().getExtent();
	        // Gradient starts on the left edge of each feature, and ends on the right.
	        // Coordinate origin is the top-left corner of the extent of the geometry, so
	        // we just divide the geometry's extent width by resolution and multiply with
	        // pixelRatio to match the renderer's pixel coordinate system.
	        var grad = context.createLinearGradient(0, 0,
	            ol.extent.getWidth(extent) / resolution * pixelRatio, 0);
	        grad.addColorStop(0, 'red');
	        grad.addColorStop(1 / 6, 'orange');
	        grad.addColorStop(2 / 6, 'yellow');
	        grad.addColorStop(3 / 6, 'green');
	        grad.addColorStop(4 / 6, 'aqua');
	        grad.addColorStop(5 / 6, 'blue');
	        grad.addColorStop(1, 'purple');
	        return grad;
		}
	}
});