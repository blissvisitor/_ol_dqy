require.config({
    urlArgs:"v="+new Date()
});
require(["ol","mapConfig","mapTools"],function (ol,mapConfig,mapTools) {
    //天地图街道地图
    var streetLayer = new ol.layer.Tile({
        source: new ol.source.XYZ({
            projection: "EPSG:4326",
            url: mapConfig.tiandituUrl + "sl_dt/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_dt&STYLE=sl_dt&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
        })
    });
    //天地图注记图层
    var streetAnnotationLayer = new ol.layer.Tile({
        //visible:false,
        preload: 0,
        useInterimTilesOnError: false,
        source: new ol.source.XYZ({
            projection: "EPSG:4326",
            url: mapConfig.tiandituUrl + 'sl_zj/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_zj&STYLE=sl_zj&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
        })
    });


    var boundaryLayer = new ol.layer.Tile({
        title: "河北省边界",
        minResolution: 0.001373291015625,
        source: new ol.source.XYZ({
            projection: "EPSG:4326",
            url: mapConfig.tiandituUrl + 'HBSJ/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=HBSJ&STYLE=HBSJ&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
        })
    });

    var map = new ol.Map({
        target: "map",
        interactions: ol.interaction.defaults({
            doubleClickZoom:false
        }),
        layers: [streetLayer, boundaryLayer, streetAnnotationLayer],
        view: new ol.View({
            zoom: 7,
            maxZoom: 18,
            minZoom: 6,
            center: [116.112212109375, 38.566251171875],
            projection: "EPSG:4326"
        }),
        logo: false
    });
    var view=map.getView();
    
    var mousePosition = new ol.control.MousePosition({
        coordinateFormat: ol.coordinate.createStringXY(5),
        projection: 'EPSG:4326',
        className: "ol-mouse-position2"
    });
    map.addControl(mousePosition);

    
    var statisticalLayer = new ol.layer.Vector({
        source: new ol.source.Vector()
    });
    map.addLayer(statisticalLayer);
    
    //雄安新区的边界
    var XIONGAN = new ol.layer.Image({
        minResolution: 0.001373291015625,
        source: new ol.source.ImageWMS({
          ratio: 1,
          url: mapConfig.hebeiBordr,
          params: {'FORMAT': "image/png",
                   'VERSION': '1.1.1',  
                STYLES: '',
                LAYERS: 'HBAJ:XIONGAN',
          }
        })
      });
    map.addLayer(XIONGAN);
    //风险指数渲染图层
    var riskLayer=new ol.layer.Vector({
        source: new ol.source.Vector()      
 });
    map.addLayer(riskLayer);
    var format = new ol.format.WKT();
    
     var XIONGANPOINT = new ol.layer.Image({
         minResolution: 0.001373291015625,
            source: new ol.source.ImageWMS({
              ratio: 1,
              url: mapConfig.hebeiBordr,
              params: {'FORMAT': "image/png",
                       'VERSION': '1.1.1',  
                    STYLES: '',
                    LAYERS: 'HBAJ:xionganPoint',
              }
            })
          });
     map.addLayer(XIONGANPOINT);
     
    function getCountyData(layerName) {

        var format = new ol.format.WKT();
        statisticalLayer.getSource().clear();
        $.post("/main/onemap/DiffrentLevel", { xzqhLevel: "2", tb: layerName, isapp: $("#isapp").val(), usernum: $("#usernum").val(), areaId: $("#areaId").val(), industyIds: $("#industyIds").val() }, function (data) {
            var features = [];
            for (var i = 0, z = data.length; i < z; i++) {
                var feature = format.readFeature(data[i].point);
                feature.set("city", data[i].city);
                feature.set("layerName", layerName);
                feature.setStyle(mapTools.setStyle(parseInt(data[i].count), layerName));
                features.push(feature);
            }
            statisticalLayer.getSource().clear();
            statisticalLayer.getSource().addFeatures(features);
        });
    };
    
    function showData(layerName) {
        selectLayer = layerName;
        statisticalLayer.getSource().clear();
        //$.post("/main/onemap/DiffrentLevel",{xzqhLevel:"1",tb:layerName},function(data){
        $.post("/main/onemap/DiffrentLevel", { xzqhLevel: "1", tb: layerName, isapp: $("#isapp").val(), usernum: $("#usernum").val(), areaId: $("#areaId").val(), industyIds: $("#industyIds").val() }, function (data) {
            //$.post(mapConfig.statistical,{layerName:layerName,isapp:$("#isapp").val(),usernum:$("#usernum").val(),areaId:$("#areaId").val(),industyIds:$("#industyIds").val()},function(data){
            var features = [];
            for (var i = 0, z = data.length; i < z; i++) {
                var feature = format.readFeature(data[i].point);
                feature.set("city", data[i].city);
                feature.setStyle(mapTools.setStyle(parseInt(data[i].count), layerName));
                features.push(feature);
            }
            statisticalLayer.getSource().clear();
            statisticalLayer.getSource().addFeatures(features);
        });
    }
    
    var ly = "GEOM_FXZS";
    view.on("change:resolution", function (evt) {
        if (view.getZoom() > 8) {
            getCountyData(ly);
        } else {
            showData(ly);
        }
        //风险指数市县监听
        CityOrCountyRisk();

    });
    
    
    
    
     $(".mapcutcon li a").click(function(){
             //销毁风险指数
             destroyRisk();
             if ($(this).parent().hasClass("active")) {
                 $(this).parent().removeClass("active");
             
             }
             else{
                 $(this).parent().addClass("active").siblings().removeClass("active");
                 ly=$(this).attr("ly");
                 if(ly==="GEOM_FXZS"){//风险指数
                     initRisk();    
                 }else{
                     if (view.getZoom() > 8) {
                        getCountyData(ly);
                    } else {
                        showData(ly);
                    } 
                 }
             }
     });
     var gjFormat=new ol.format.GeoJSON();
     //风险指数模块是否激活，0否，1是
     var isRisk=0;
     //监听resolution变化，判断显示市或县
     var riskStatus=0;
     function CityOrCountyRisk(){
         // status风险指数模块图层数据状态，0无，1县，2市
         if(isRisk==1){
         if (view.getZoom() > 8) {
             //县 1
             if(riskStatus!=1){
                 getRiskData('/main/riskPoint/iVeryAreaXFxValue',mapConfig.riskCountyUrl,1);
             }
         } else {
             //市 2
             if(riskStatus!=2){
                 getRiskData('/main/riskPoint/iVeryCityFxValue',mapConfig.riskCityUrl,2); 
             }
         }
        }
     }
     //根据风险值获取渲染
     function getStyle(risk){
         var strokeColor='#00ff00';
         var fillColor='rgba(255,0,0,0.1)';
         if(risk<=150){
             fillColor='#2196f3';
         }else if(risk>150&&risk<=300){
             fillColor='#ffc107';
         }else if(risk>300&&risk<=1000){
             fillColor='#ff5722';
         }else if(risk>1000){
             fillColor='#ff0000';
         }else{
             fillColor='rgba(255,0,0,0)';
         }
         return new ol.style.Style({            
             fill:new ol.style.Fill({
                 color:fillColor
             }),
             stroke:new ol.style.Stroke({
                 width:4,
                 color:strokeColor
             })
         })
     }
     //多面符号化处理
     function multiTextStyle(geom,label){
         var geomType=geom.getType();
         var point,feature;
         if(geomType=='MultiPolygon'){
             //求出面积最大的polygon
             var maxArea=0;
             var maxPolygon;
             var polygons=geom.getPolygons();
             polygons.forEach(function(item,index){
                 var area=item.getArea();
                 if(area>maxArea){
                     maxPolygon=item;
                     maxArea=area;
                 }
             });
             point=new ol.geom.Point(ol.extent.getCenter(maxPolygon.getExtent()));
             if(label=='廊坊市'){
                 var polygons=geom.getPolygons();
                 var points=[];
                 polygons.forEach(function(poly,index){
                     var point1=new ol.geom.Point(ol.extent.getCenter(poly.getExtent()));
                     points.push(point1.getCoordinates());
                 });
                 point=new ol.geom.MultiPoint(points);
             }
         }else{
             point=new ol.geom.Point(ol.extent.getCenter(geom.getExtent()));
         }
         feature=new ol.Feature(point);
         feature.setStyle(new ol.style.Style({
             fill:new ol.style.Fill({
                 color:'rgba(255,0,0,0)'
             }),
             stroke:new ol.style.Stroke({
                 width:0,
                 color:'rgba(255,0,0,0)'
             }),
             text:new ol.style.Text({
                 font: '12px 微软雅黑',
                 fill: new ol.style.Fill({ color: 'black' }),
                 text: label
             })
         }));
         return feature;
     }
     //获取风险值数据，行政区划数据，对比赋风险值，添加到图层
     //url 风险值请求地址，url1行政区划地址，sta县or市
     function getRiskData(url,url1,sta){
         $.ajax({
             url: url,
             success: function(response,status,xhr){
                 if (status =="success") {
                     var data=response;
                     $.ajax({
                         url: url1,
                         data: {},
                         success: function(value,status,xhr){
                             if (status =="success") {
                                 var data1=value;
                                 var features=gjFormat.readFeatures(data1);
                                 var labelFeatures=[];
                                 features.forEach(function(item,index){                     
                                     var code=0;
                                     var riskName=item.getProperties().NAME_1;
                                     if(!riskName){
                                         riskName=item.getProperties().name;
                                     }           
                                     if(sta==1){
                                         code=item.getProperties().xzqh;
                                       }else{
                                          code=item.getProperties().code_1;
                                       }
                                     if(data[parseInt(code)]>=0){
                                         var style=getStyle(parseFloat(data[code]));
                                         item.setStyle(style);
                                         var labelFeature=multiTextStyle(item.getGeometry(),riskName);
                                         labelFeatures.push(labelFeature);
                                     }
                                     
                                     
                                 });
                                 riskLayer.getSource().clear();
                                 riskLayer.getSource().addFeatures(features);
                                 riskLayer.getSource().addFeatures(labelFeatures);
                                 riskStatus=sta;
                             } else {
                                 CityOrCountyRisk();
                             }
                         },
                         dataType: 'json'
                       });
                     } else {
                    layer.msg('请求风险值失败！');
                 }
             },
             dataType: 'json'
           });         
     } 
     //移除风险指数
     function destroyRisk(){
         riskLayer.getSource().clear();
         isRisk=0;
       
     }
     //初始化风险指数模块
     function initRisk(){
         isRisk=1;
         riskStatus=0;
         CityOrCountyRisk();
       
     }   
     //跳转到一张图
     $("#onemap").click(function(){
            var url = '/main/onemap/map?layer=' + ly;
            window.parent.parent.commonAddTabs("一张图", url);
     });
    
    
    
    
    
    
    
    
    
    
})