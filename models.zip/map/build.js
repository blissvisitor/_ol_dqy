({
    baseUrl: ".",
    name: "main",
    out: "main22.js"
})