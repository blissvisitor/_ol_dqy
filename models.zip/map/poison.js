/**
 * dqy 模拟分析 毒气泄漏 2017-11-30 10:48
 */
define(["ol", "initMap", "mapTools", "text!poison.html", "turf"], function(ol, mapContent, mapTools, poisonHtm, turf) {
    var that = this;
    var Py, // 水平扩散系数
        Pz, // 垂直扩散系数
        x,
        y;
    var maxR = 100; // x轴方向最远距离m
    var Q, // 泄漏源连续泄漏速率kg/s
        Pi = Math.PI, //
        V, // 泄漏高度平均风速，m/s
        C, // 临界浓度值大于0
        A,//风向
        result = [], // 结果
        b = [];
    var cArr = [];
    var lines = [];
    var breaks = [];
    var colorRamp = ['#e88b62', '#f07675', '#e72319', '#b40c08', '#4d1919'];
    var poisonCoord; // 爆炸点坐标
    var centerPoint;
    var distanceArr = [50, 150, 300, 500]; // 关注范围
    var geojson = {
        'type': 'FeatureCollection',
        'crs': {
            'type': 'name',
            'properties': {
                'name': 'EPSG:3857'
            }
        },
        'features': [{
            'type': 'Feature',
            'geometry': {
                'type': 'Point',
                'coordinates': [0, 0]
            }
        }]
    }
    //角度旋转
    var Rotate = function(coord,Angle)//Angle为正时逆时针转动, 单位为弧度
    {
        var Source={X:coord[0],Y:coord[1]};
        var A,R;
        A = Math.atan2(Source.Y,Source.X)//atan2自带坐标系识别, 注意X,Y的顺序
        A += Angle//旋转
        R = Math.sqrt(Source.X * Source.X + Source.Y * Source.Y)//半径
        return [Math.cos(A) * R,Math.sin(A) * R];
    }
    // create a grid of points with random z-values in their properties
    //分析
    var loadingIndex=null;
    function poisonAnalysis() {
        if (!poisonCoord) return;
        Q = $('#Q').val();
        V = $('#V').val();
        A= $('#A').val();
        if(A>360||A<0){
            layer.msg('角度为0~360！');
            return; 
        }
        if (!Q||parseFloat(Q)<=0) {
            layer.msg('请输入泄漏速率并且不能为负值！');
            return;
        }
        if (!V||parseFloat(V)<0) {
            layer.msg('请输入平均风速并且不能为负值!');
            return;
        }
        if(loadingIndex){
            layer.close(loadingIndex);
            loadingIndex=null;
        }
        loadingIndex= layer.load(1);
        var Pasquill = $('#pasquill').val();
        geojson.features = [];
        var diss=4;
        for (var i = 1; i <= 500; i += diss) {
            x = i;
            var dis = diss/2;
            for (var m = -500; m <= 500; m += diss) {
                y = m;
                switch (Pasquill) {
                    case 'A':
                        Py = 0.22 * x / Math.sqrt(1 + 0.0001 * x);
                        Pz = 0.2 * x;
                        break;
                    case 'B':
                        Py = 0.16 * x / Math.sqrt(1 + 0.0001 * x);
                        Pz = 0.12 * x;
                        break;
                    case 'C':
                        Py = 0.11 * x / Math.sqrt(1 + 0.0001 * x);
                        Pz = 0.08 * x / Math.sqrt(1 + 0.0015 * x);
                        break;
                    case 'D':
                        Py = 0.08 * x / Math.sqrt(1 + 0.0001 * x);
                        Pz = 0.06 * x / Math.sqrt(1 + 0.0015 * x);
                        break;
                    case 'E':
                        Py = 0.06 * x / Math.sqrt(1 + 0.0001 * x);
                        Pz = 0.03 * x / Math.sqrt(1 + 0.0003 * x);
                        break;
                    case 'F':
                        Py = 0.04 * x / Math.sqrt(1 + 0.0001 * x);
                        Pz = 0.016 * x / Math.sqrt(1 + 0.0003 * x);
                        break;
                }
                var c1 = Q * Math.exp(-Math.pow(y, 2) / (2 * Math.pow(Py, 2))) / (Pi * V * Py * Pz);
                c1 = c1 * 1000;
                if (c1) {
                    cArr.push(c1);
                    //转为经纬度
                    var pt = turf.point(poisonCoord);
                    var converted = turf.toMercator(pt).geometry.coordinates;;
        
                    var coord1=[x-dis,y-dis];
                    var newCoord1=Rotate(coord1,Math.PI*A/180);
                    var coord2=[x+dis,y-dis];
                    var newCoord2=Rotate(coord2,Math.PI*A/180);
                    var coord3=[x+dis,y+dis];
                    var newCoord3=Rotate(coord3,Math.PI*A/180);
                    var coord4=[x-dis,y+dis];
                    var newCoord4=Rotate(coord4,Math.PI*A/180);
                    
                    var point1 = [converted[0]+newCoord1[0], converted[1]+newCoord1[1]];
                    var point2 = [converted[0]+newCoord2[0], converted[1]+newCoord2[1]];
                    var point3 = [converted[0]+newCoord3[0], converted[1]+newCoord3[1]];
                    var point4 = [converted[0]+newCoord4[0], converted[1]+newCoord4[1]];
                    geojson.features.push({
                        'type': 'Feature',
                        'geometry': {
                            'type': 'Polygon',
                            'coordinates': [
                                [
                                    WgsToWeb(point1),
                                    WgsToWeb(point2),
                                    WgsToWeb(point3),
                                    WgsToWeb(point4)
                                ]
                            ]
                            // 'coordinates':[lng,lat]
                        },
                        'properties': {
                            'nd': c1
                        }
                    });
                }
            }
        }
        isonlines();
    }

    function WgsToWeb(coord) {
        return turf.toWgs84(turf.point(coord)).geometry.coordinates;
    }

    function isonlines() {
        var gastype = $('#gastype').val();
        switch (gastype) {
            case '氯气':
                breaks = [1.5,18, 90,180, 300, 3000];
                break;
            case '氨气':
                breaks = [20,175, 210, 350, 553,1750];// 轻度中度严重重度
                break;
            case '一氧化碳':
                breaks =[10,100,250, 500, 1000,2000];
                break;
        }

        var features = gjFormat.readFeatures(geojson);
        analysisLyr.getSource().clear();
        analysisLyr.getSource().addFeatures(features);
        layer.close(loadingIndex);
        loadingIndex=null;
    }

    // 绘制爆炸点
    function drawPosition() {
        // body...
        poisonCoord = null;
        // 清空图层
        analysisLyr.getSource().clear();
        vectorLyr.getSource().clear();
        if (drawTool) return;
        drawTool = new ol.interaction.Draw({
            source: vectorLyr.getSource(),
            type: 'Point'
        });
        mapContent.map.addInteraction(drawTool);
        drawTool.on('drawend', function(e) {
            // body...
            mapContent.map.removeInteraction(drawTool);
            drawTool = null;
            centerPoint = e.feature;
            poisonCoord = e.feature.getGeometry().getCoordinates();
            // 添加关注范围
            var distanceF = [];
            for (var i = 0; i < distanceArr.length; i++) {
                var r = distanceArr[i] / (2 * Math.PI * 6378137.0) * 360;
                var bufferCircle = new ol.geom.Circle(poisonCoord, r, 'XY');
                var polygon = ol.geom.Polygon.fromCircle(bufferCircle);
                bufferCircle = new ol.Feature(bufferCircle);
                bufferCircle.setStyle(new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        color: 'red',
                        width: 1
                    })
                }));
                var label = new ol.Feature({
                    geometry: new ol.geom.Point(polygon.getFirstCoordinate()),
                    zIndex: 100
                })
                label.setStyle(new ol.style.Style({
                    text: new ol.style.Text({
                        font: '14px 微软雅黑',
                        fill: new ol.style.Fill({ color: 'black' }),
                        fill: new ol.style.Fill({ color: '#075db3' }),
                        // text: tempR+'米，浓度范围'+S*Per[i],
                        text: distanceArr[i] + 'm',
                        rotation: 0,
                        offsetY: 15,
                        // textAlign: 'line'
                        textBaseline: 'bottom'
                    })
                }));
                distanceF.push(bufferCircle);
                distanceF.push(label);
            }
            vectorLyr.getSource().addFeatures(distanceF);
            mapContent.map.getView().fit(distanceF[distanceF.length - 2].getGeometry(), mapContent.map.getSize());
        });
    }
    var drawTool;
    var gjFormat = new ol.format.GeoJSON();;
    var vectorLyr, analysisLyr;
    // 初始化本模块
    var init = function() {
        vectorLyr = new ol.layer.Vector({
            source: new ol.source.Vector(),
            style: function(feature, res) {
                return new ol.style.Style({
                    image: new ol.style.Icon({
                        anchor: [0.5, 0.5],
                        size: [32, 32],
                        src: document.getElementById('poison').src
                    })
                })
            },
            zIndex: 90
        });
        analysisLyr = new ol.layer.Vector({
            source: new ol.source.Vector(),
            style: function(feature, res) {
                var fillColor = '';
                var nd = feature.getProperties().nd;
                fillColor = 'rgba(255,0,0,0)';
                for (var i = 0; i < breaks.length; i++) {                   
                    if (i == 0) {
                        if (nd < breaks[i+1] && nd >= breaks[i]) {
                            fillColor = colorRamp[i];
                        }
                    } else if (i == breaks.length - 1) {
                        if (nd >= breaks[i]) {
                            fillColor = colorRamp[i];
                        } 
                    } else {
                        if (nd < breaks[i+1] && nd >= breaks[i]) {
                            fillColor = colorRamp[i];
                        }
                    }
                }
                return new ol.style.Style({
                    fill: new ol.style.Fill({ color: fillColor }),
                    stroke: new ol.style.Stroke({ color: 'rgba(255,0,0,0)', width: 1 })
                });
            },
            zIndex: 80

        });
        mapContent.map.addLayer(analysisLyr);
        mapContent.map.addLayer(vectorLyr);
        // 展开面板
        // todo
        $('.fundo').show();
        $('.fundo').html(poisonHtm);
        $('#drawPosition').click(function() {
            drawPosition();
        });
        $('#poisonAnalysis').click(function() {
            poisonAnalysis();
        });
    };
    // 销毁本模块
    var destroy = function() {
        if (vectorLyr) {
            mapContent.map.removeLayer(vectorLyr);
            vectorLyr = null;
        }
        if (analysisLyr) {
            mapContent.map.removeLayer(analysisLyr);
            analysisLyr = null;
        }
        if (drawTool) {
            mapContent.map.removeInteraction(drawTool);
            drawTool = null;
        }
        $('.fundo').hide();
        $('.fundo').html('');
    };
    var content = {
        init: init,
        destroy: destroy
    };
    return content;
})