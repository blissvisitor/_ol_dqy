
function getCode() {
			var params = { code: "", fl: "" ,lfl:"",lfj:""};
			//行业分类
			$("#industry ul li").each(function (index, ele) {
				if (ele.firstChild.classList.contains("layerList")) {
					params.code = params.code + ele.firstChild.getAttribute("codenum") + ",";
				}
			})
            //监管类型
			$("#supervise2 ul li").each(function (index, ele) {
				if (ele.firstChild.classList.contains("layerList")) {
					params.fl = params.fl + ele.firstChild.getAttribute("codenum") + ",";
				}
			})
			var secondLfl="",currentLayer=$("#currentLy span").attr("currentLy");
		
			if(currentLayer==="GEOM_YJYA_YJWZ"||currentLayer==="GEOM_YJZY_YJJYZB"){ //如果等于应急物资
				//左侧分类列表
				$(".cemain ul:eq(0) li a").each(function (index, ele) {
					var $ele=$(ele);
					if (ele.classList.contains("listActive")&&!ele.classList.contains("third_item")) {
						if($ele.parent().find("a.listActive").length===1&&$ele.attr("son")){
							params.lfl = params.lfl + "substr(FTYPE, 0, 2) = '"+ele.getAttribute("codenum").slice(0,2) + "' OR ";
						}
					}
					//二级分类
					if (ele.classList.contains("third_item")&&ele.classList.contains("listActive")) {
						secondLfl = secondLfl + ele.getAttribute("codenum") + ",";
					}
				})
				params.lfl = (params.lfl?params.lfl.substr(0, params.lfl.length - 3):"")+"#"+secondLfl.substr(0, secondLfl.length - 1);
			}else{
				$(".cemain ul:eq(0) li a").each(function (index, ele) {
				if (ele.classList.contains("listActive")) {
					params.lfl = params.lfl + ele.getAttribute("codenum") + ",";
				}
				})
				params.lfl = params.lfl.substr(0, params.lfl.length - 1);
			}
			
          //左侧分级列表
			$(".cemain ul:last li a").each(function (index, ele) {
				if (ele.classList.contains("listActive")) {
					params.lfj = params.lfj + ele.getAttribute("codenum") + ",";
				}
			})

			
			
			params.code = params.code.substr(0, params.code.length - 1);
			params.fl = params.fl.substr(0, params.fl.length - 1);
			
			params.lfj = params.lfj.substr(0, params.lfj.length - 1);
			
			return params;
		}

define(["mapConfig", "initMap", "ol", "mapTools", "mapConfig","layerConfig"], function (mapConfig, initMap, ol, mapTools, mapConfig,layerConfig) {

	var jqueryExtend = function () {
		$.fn.verify = function (type) {
			var number = parseFloat(this.val()), isConfirm;
			switch (type) {
				case "lon":  //经度
					isConfirm = (number <= 180 && number >= -180 && number != NaN ? true : false);
					if (!isConfirm) {
						layer.msg("经度必须在[-180,180]之间");
					}
					break;
				case "lat":  //纬度
					isConfirm = (number <= 90 && number >= -90 && number != NaN ? true : false);
					if (!isConfirm) {
						layer.msg("纬度必须在[-90,90]之间");
					}
					break;
			}
			return isConfirm;
		}
	}
	
	
	
	
	
	
	
	
	

	//创建事故点样式
	function createStyle2(obj) {
		var style = new ol.style.Style({
			image: new ol.style.Icon({
				src: obj.src || "/main/resources/image/map/sgd.png"
			}),
			stroke: new ol.style.Stroke({
				width: 2,
				color: obj.strokeColor || "#ff0000",
				lineDash: [5, 5]
			})
		});
		if (!obj.src) {
			style.getImage = undefined;
		}
		return style;
	}


	//事故点的辅助虚线
	function auxiliaryLine(getAccientPoint) {
		var original = ol.proj.toLonLat([0, 10000]);
		var circle = new ol.Feature({
			geometry: new ol.geom.Circle(getAccientPoint, original[1])
		});
		var circlePolygon = ol.geom.Polygon.fromCircle(circle.getGeometry(), 50);
		showLayersData(circlePolygon.getCoordinates()[0]);
		circle.setStyle(createStyle2({ strokeColor: "#1774D1" }));
		initMap.yjxyLayer.getSource().addFeature(circle);

		var vLine = new ol.Feature({
			geometry: new ol.geom.LineString([[getAccientPoint[0], getAccientPoint[1] + 0.1], [getAccientPoint[0], getAccientPoint[1] - 0.1]])
		});
		vLine.setStyle(createStyle2({ strokeColor: "#ADCEEF" }));
		initMap.yjxyLayer.getSource().addFeature(vLine);


		var hLine = new ol.Feature({
			geometry: new ol.geom.LineString([[getAccientPoint[0] + 0.1, getAccientPoint[1]], [getAccientPoint[0] - 0.1, getAccientPoint[1]]])
		});
		hLine.setStyle(createStyle2({ strokeColor: "#ADCEEF" }));
		initMap.yjxyLayer.getSource().addFeature(hLine);
	}
	//展示10km范围内的救援队伍、救援装备、救援物资
	function showLayersData(coordinates) {
		var points = "";
		var url = mapConfig.queryUrl + "service=WFS&version=1.0.0&REQUEST=GetFeature&typeName=HBAJ:GEOM_YJYA_YJWZ,HBAJ:GEOM_YJZY_YJJYDW,HBAJ:GEOM_YJZY_YJJYZB&srsName=EPSG:4326&outputFormat=application/json&CQL_FILTER=INTERSECTS(GEOM,POLYGON((";
		for (var i = 0, z = coordinates.length; i < z; i++) {
			if (i === z - 1) {
				points += coordinates[i][0];
				points += " ";
				points += coordinates[i][1];
			} else {
				points += coordinates[i][0];
				points += " ";
				points += coordinates[i][1];
				points += ",";
			}

		}
		$.post(url + points + ")))", function (data) {
			var features = [];
			if (data.features.length === 0) {
				return;
			}
			data.features.forEach(function (val, index) {
				var feature = new ol.Feature({
					geometry: new ol.geom.Point(val.geometry.coordinates)
				});
				if (val.id.indexOf("GEOM_YJYA_YJWZ") > -1) { //应急物资
					feature.setStyle(createStyle2({ src: "/main/resources/image/map/GEOM_YJYA_YJWZ.png" }));
				} else if (val.id.indexOf("GEOM_YJZY_YJJYDW") > -1) {  //救援队伍
					feature.setStyle(createStyle2({ src: "/main/resources/image/map/GEOM_YJZY_YJJYDW.png" }));
				} else if (val.id.indexOf("GEOM_YJZY_YJJYZB") > -1) {  //救援装备
					feature.setStyle(createStyle2({ src: "/main/resources/image/map/GEOM_YJZY_YJJYZB.png" }));
				}
				features.push(feature);
			});
			initMap.yjxyLayer.getSource().addFeatures(features);
		});
	}

	//点向下落的动态效果
	function animationPoint(geometry) {

		var map = initMap.map;
		var view = map.getView();
		var xy = geometry.getCoordinates();
		var extent = view.calculateExtent(map.getSize());
		var dy = (extent[3] - xy[1]) / 100.0;
		var i = 0;

		function time() {
			var key = map.on("postcompose", function (e) {
				if (i > 100) {
					map.unByKey(key);
					clearInterval(clearTime);
				} else {
					geometry.setCoordinates([xy[0], extent[3] - dy * i]);
					i++;
				}
			});
		}
		var clearTime = setInterval(time, 80);
	}

	//展示当前事故点
	function currentEvent(getAccientPoint) {
		var feature = new ol.Feature({
			geometry: new ol.geom.Point(getAccientPoint)
		});
		initMap.yjxyLayer.getSource().clear();
		feature.setStyle(createStyle2({ src: "/main/resources/image/map/sgd.png" }));
		initMap.yjxyLayer.getSource().addFeature(feature);
		animationPoint(feature.getGeometry());
		auxiliaryLine(getAccientPoint);
	}
	var flyToLocation = function (coordinates) {
		mapTools.createLayer("GEOM_EMERG_RESPONSE", initMap.map);//添加应急响应图层
		initMap.panToPoint3(coordinates, 12);
		setTimeout(currentEvent, 2000, coordinates);
	}


	function IsPC() {
		var userAgentInfo = navigator.userAgent;
		var Agents = ["Android", "iPhone",
			"SymbianOS", "Windows Phone",
			"iPad", "iPod"];
		var flag = true;
		for (var v = 0; v < Agents.length; v++) {
			if (userAgentInfo.indexOf(Agents[v]) > 0) {
				flag = false;
				break;
			}
		}
		return flag;
	}




	return {
		/**
		 * @api {类型 function} 增加资源时，判断是哪个图层来获取不同的名称 resourceJudge
		 * @apiParam {ol.Feature} feature 元素对象
		 * @apiParam {String} layer 图层名称
		 * @apiName resourceJudge 
		 * @apiGroup domOperation
		 */
		resourceJudge:function(feature,layer){
			var name="";
			switch(layer){
			case "GEOM_YJZY_YJJYDW":
				name=feature.get("DWMC");
				break;
			case "GEOM_YJZY_YJJYZB":
				name=feature.get("ZBMC");
				break;
			case "GEOM_YJYA_YJWZ":
				name=feature.get("WZMC");
				break;
			}
			return name;
		},
		/**
		 * @api {类型 function} 资源清单中判断是哪个图层 rescueLy
		 * @apiParam {String} text 当前图层名称
		 * @apiParam {String} page 当前页
		 * @apiName rescueLy 
		 * @apiGroup domOperation
		 */
	   rescueLy:function(text){
		   var ly="";
			switch(text){
			case "救护队":
				ly="GEOM_YJZY_YJJYDW";
				break;
			case "救援装备":
				ly="GEOM_YJZY_YJJYZB";
				break;
			case "应急物资":
				ly="GEOM_YJYA_YJWZ";
				break;
			}
			return ly;
	   },
		/**
		 * @api {类型 function} 显示资源清单 rescueList
		 * @apiParam {String} text 当前图层名称
		 * @apiParam {String} page 当前页
		 * @apiName rescueList 
		 * @apiGroup domOperation
		 */
		rescueList(text,page){
			if(!layerConfig.emergencyId){
				layer.msg("请先和应急响应关联");
			}
			$(".resourcebottom tr td[gid]").html("").removeAttr("gid");
			$(".resourcebottom tr td[position]").html("").removeAttr("position");
			var obj=null;
			switch(text){
			case "救护队":
				$.get("/main/yjxy/getAmbulanceDistJsonForMap?page="+page+"&rows=10&sgid="+layerConfig.emergencyId).done(function(data){
					obj=JSON.parse(data);
					page===1?$(".resourcetable").attr("total",obj.total):"";
					 for(var i=0,z=obj.rows.length;i<z;i++){
						 $(".resourcebottom tr").eq(i+1).find("td").eq(0).attr("position",obj.rows[i].position).html("<p class='resourse-p' title='"+obj.rows[i].mc+"'>"+obj.rows[i].mc+"</p>");
						 $(".resourcebottom tr").eq(i+1).find("td").eq(1).html('<img src="/main/resources/image/images/icon-013.png" title="查看详情" style="cursor:pointer;"><img src="/main/resources/image/images/delete.png" title="删除" style="cursor:pointer;">').attr("gid",obj.rows[i].opguid);
					 }
					
				})
				break;
			case "救援装备":
				$.get("/main/yjxy/getEquipDistJsonForMap?page="+page+"&rows=10&sgid="+layerConfig.emergencyId).done(function(data){
					obj=JSON.parse(data);
					page===1?$(".resourcetable").attr("total",obj.total):"";
					 for(var i=0,z=obj.rows.length;i<z;i++){
						 $(".resourcebottom tr").eq(i+1).find("td").eq(0).attr("position",obj.rows[i].position).html("<p class='resourse-p' title='"+obj.rows[i].mc+"'>"+obj.rows[i].mc+"<p>");
						 $(".resourcebottom tr").eq(i+1).find("td").eq(1).html('<img src="/main/resources/image/images/icon-013.png" title="查看详情" style="cursor:pointer;"><img src="/main/resources/image/images/delete.png" title="删除" style="cursor:pointer;">').attr("gid",obj.rows[i].opguid);
					 }
					
				})
				break;
			case "应急物资":
				$.get("/main/yjxy/getMaterialDistJsonForMap?page="+page+"&rows=10&sgid="+layerConfig.emergencyId).done(function(data){
					obj=JSON.parse(data);
					page===1?$(".resourcetable").attr("total",obj.total):"";
					 for(var i=0,z=obj.rows.length;i<z;i++){
						 $(".resourcebottom tr").eq(i+1).find("td").attr("position",obj.rows[i].position).eq(0).html("<p class='resourse-p' title='"+obj.rows[i].mc+"'>"+obj.rows[i].mc+"<p>");
						 $(".resourcebottom tr").eq(i+1).find("td").eq(1).html('<img src="/main/resources/image/images/icon-013.png" title="查看详情" style="cursor:pointer;"><img src="/main/resources/image/images/delete.png" title="删除" style="cursor:pointer;">').attr("gid",obj.rows[i].opguid);
					 }
					
				})
				break;
			}
		},
		/**
		 * @api {类型 function} 如果是从风险地图哪里进来，则隐藏应急救援的功能 riskLayerHide
		 * @apiParam {String} ly 当前图层名称
		 * @apiName riskLayerHide 
		 * @apiGroup domOperation
		 */
		riskLayerHide:function(){
			$(".yingmain").css("display","none");
			$(".bottom-fun").css("display","none");
            $(".botfun").append('<a herf="#2" class="fl" title="风险地图" id="geom_fxdt"><img src="/main/resources/image/map/bg_fx.png"/></a>');
			 //用来删除缓冲区分析中的一些选项
			$("#mapBufferSet label").each(function(index,ele){
				var $for=$(ele);
				 switch(true){
				 case $for.prop("for").indexOf("HBAJ:GEOM_SGBS")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_DYJYA_BASQB")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_STANDARD")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_LAWINFO_PLAN")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_HON_CHMAIN")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_YJSJ")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_ZYBWH")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_SUPERVISION")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_ZJJG")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_REGULATION_SUBJECT")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_EMERG_RESPONSE")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_SPECIAL")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_KSK")>-1:
					 $for.remove();
					 break; 
				 case $for.prop("for").indexOf("HBAJ:GEOM_FIREWORKS")>-1:
					 $for.remove();
					 break; 
				 }
			})
			
			
			 //用来删除缓冲区分析中的一些选项
			$("#mapBufferSet label").each(function(index,ele){
				var $for=$(ele);
				 switch(true){
				 case $for.prop("for").indexOf("HBAJ:GEOM_SGBS")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_DYJYA_BASQB")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_STANDARD")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_LAWINFO_PLAN")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_HON_CHMAIN")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_YJSJ")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_ZYBWH")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_SUPERVISION")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_ZJJG")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_REGULATION_SUBJECT")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_EMERG_RESPONSE")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_SPECIAL")>-1:
					 $for.remove();
					 break;
				 case $for.prop("for").indexOf("HBAJ:GEOM_KSK")>-1:
					 $for.remove();
					 break; 
				 case $for.prop("for").indexOf("HBAJ:GEOM_FIREWORKS")>-1:
					 $for.remove();
					 break; 
				 }
			})
		},
		/**
		 * @api {类型 function} 根据点击顺序，来确定当前图层 layerQueue
		 * @apiParam {Array} lys 当前选中图层名称的图层数组
		 * @apiParam {String} currentLy 当前图层名称的图层数组
		 * @apiName layerQueue 
		 * @apiGroup domOperation
		 */
		layerQueue:function(lys,currentLy){
			var index=lys.indexOf(currentLy);
			if(index>-1){
				lys.splice(index,1);
			}else{
				lys.push(currentLy);
			}
			return lys;
		},
		/**
		 * @api {类型 function} 判断是否可以按照监管类型和行业类别进过滤行显示 hasJg
		 * @apiParam {String} ly 当前图层名称
		 * @apiName hasJg 
		 * @apiGroup domOperation
		 */
		hasJg:function(ly){
			//当图层不能进行监管类型筛选的时候要隐藏监管类型的列表
			if(layerConfig.lyJg[ly]){
				$("#supervise2 ul").attr("style","");
				$("#supervise2 a:first").css("cursor","pointer");
			}else{
				$("#supervise2 ul").css("display","none");
				$("#supervise2 a:first").css("cursor","not-allowed");
			}
			if(layerConfig.lyHylb[ly]){
				$("#industry ul").attr("style","");
				$("#industry a:first").css("cursor","pointer");
			}else{
				$("#industry ul").css("display","none");
				$("#industry a:first").css("cursor","not-allowed");
			}
		},
		//判断是电脑还是手机端
		IsPC:IsPC,
		/**
		 * @api {类型 function} 根据不同层级和不同图层显示不同的统计数字 hasFlFj
		 * @apiParam {Object} obj 分类分级的参数对象
		 * @apiName hasFlFj 
		 * @apiGroup domOperation
		 */
		hasFlFj:function(obj){
			if(obj.fl.length==1&&obj.grade.length==1){
				$(".cemain").slideUp();
				return;
			}
			if(obj.fl.length===1){
				$(".cemain ul:eq(0)").css("display","none");
			}else{
				$(".cemain ul:eq(0)").attr("style","");
			}
            if(obj.grade.length===1){
            	$(".cemain ul:eq(1)").css("display","none");
			}else{
				$(".cemain ul:eq(1)").attr("style","");
			}
		},
		//图层分类分级
		createList:function(currentLayer){
			var $list=$(".cemain");
			var that=this;
			$list.slideDown();
			$list.find("h3").text($("#themeticMap li[ly="+currentLayer+"]").text());
			$list.find("ul li.cefenji").remove();
			switch(currentLayer){
			case "GEOM_YJZY_YJJYZB":  //救援装备
			
				$.get("/main/onemap/dif?name=zjyb").then(function (data) {
					var obj = JSON.parse(data);
					var partList=obj[0].zb;
					that.hasFlFj({fl:[],grade:[]});
					 for (var i = 0; i < partList.length; i++) {
						 $list.find("ul").eq(0).append("<li class='cefenji'><a href='#2' codenum="+partList[i].code+" son='"+JSON.stringify(partList[i].son)+"'>"+partList[i].codename+"</a></li>");
					 }
					 $list.find("ul").eq(1).append("<li style='text-align:center;line-height:35px' class='cefenji'>本图层没有分级<li>");
				})

				break
			case "GEOM_YJYA_YJWZ":  //救援物资
				$.get("/main/onemap/dif?name=yjwz").then(function (data) {
					var obj = JSON.parse(data);
					partList=obj[0].wz;
					that.hasFlFj({fl:[],grade:[]});
					for (var i = 0; i < partList.length; i++) {
						$list.find("ul").eq(0).append("<li class='cefenji'><a href='#2' style='height:29px;' codenum="+partList[i].code+" son='"+JSON.stringify(partList[i].son)+"'>"+partList[i].codename+"</a></li>");
					}
					$list.find("ul").eq(1).append("<li style='text-align:center;line-height:35px' class='cefenji'>本图层没有分级<li>");
				})
				break;
				default:
					 $.post("/main/zjjgManager/flfjMapOpen?name="+currentLayer).done(function(data){
						  var list=JSON.parse(data);
						   that.hasFlFj(list);
						  if(list.fl.length===1){
							  $list.find("ul").eq(0).append("<li style='text-align:center;line-height:35px' class='cefenji'>本图层没有分类<li>");
						  }else{
							  for(var i=0,z=list.fl.length;i<z;i++){
								  $list.find("ul").eq(0).append('<li class="cefenji"><a href="#2" codenum='+list.fl[i].codenum+'>'+list.fl[i].codename+'</a></li>');
							  }
							  
						  }
						  if(list.grade.length===1){
							  $list.find("ul").eq(1).append("<li style='text-align:center;line-height:35px' class='cefenji'>本图层没有分级<li>");
						  }else{
							  if(currentLayer==="GEOM_Danger_Report"){//隐患排查的一般隐患禁止选择
								  for(var i=0,z=list.grade.length;i<z;i++){
									  if(list.grade[i].codename==="一般隐患"){
										  $list.find("ul").eq(1).append('<li class="cefenji" style="cursor:not-allowed;"><a disabled style="cursor:not-allowed;pointer-events: none;" href="#2" codenum='+list.grade[i].codenum+'>'+list.grade[i].codename+'</a></li>');
									  }else{
										  $list.find("ul").eq(1).append('<li class="cefenji"><a href="#2" codenum='+list.grade[i].codenum+'>'+list.grade[i].codename+'</a></li>');
									  }
								  }
							  }else{
								  for(var i=0,z=list.grade.length;i<z;i++){
									  $list.find("ul").eq(1).append('<li class="cefenji"><a href="#2" codenum='+list.grade[i].codenum+'>'+list.grade[i].codename+'</a></li>');
								  }
							  }
							  
						  }
						  
					  })
			}
		},
		//清除选择的行业类别和监管类型
		clearSel:function(){
			$("#industry ul li a").each(function(index,ele){
				ele.classList.remove("layerList")
      		     })
      		     $("#supervise2 ul li a").each(function(index,ele){
      		    	ele.classList.remove("layerList")
      		     })
		},
		//获得行业类别和监管类型的code码
		getCode: function () {
			var params = { code: "", fl: "" ,lfl:"",lfj:""};
			//行业分类
			$("#industry ul li").each(function (index, ele) {
				if (ele.firstChild.classList.contains("layerList")) {
					params.code = params.code + ele.firstChild.getAttribute("codenum") + ",";
				}
			})
            //监管类型
			$("#supervise2 ul li").each(function (index, ele) {
				if (ele.firstChild.classList.contains("layerList")) {
					params.fl = params.fl + ele.firstChild.getAttribute("codenum") + ",";
				}
			})
			var secondLfl="",currentLayer=$("#currentLy span").attr("currentLy");
		
			if(currentLayer==="GEOM_YJYA_YJWZ"||currentLayer==="GEOM_YJZY_YJJYZB"){ //如果等于应急物资
				//左侧分类列表
				$(".cemain ul:eq(0) li a").each(function (index, ele) {
					var $ele=$(ele);
					if (ele.classList.contains("listActive")&&!ele.classList.contains("third_item")) {
						if($ele.parent().find("a.listActive").length===1&&$ele.attr("son")){
							params.lfl = params.lfl + "substr(FTYPE, 0, 2) = '"+ele.getAttribute("codenum").slice(0,2) + "' OR ";
						}
					}
					//二级分类
					if (ele.classList.contains("third_item")&&ele.classList.contains("listActive")) {
						secondLfl = secondLfl + ele.getAttribute("codenum") + ",";
					}
				})
				params.lfl = (params.lfl?params.lfl.substr(0, params.lfl.length - 3):"")+"#"+secondLfl.substr(0, secondLfl.length - 1);
			}else{
				$(".cemain ul:eq(0) li a").each(function (index, ele) {
				if (ele.classList.contains("listActive")) {
					params.lfl = params.lfl + ele.getAttribute("codenum") + ",";
				}
				})
				params.lfl = params.lfl.substr(0, params.lfl.length - 1);
			}
			
          //左侧分级列表
			$(".cemain ul:last li a").each(function (index, ele) {
				if (ele.classList.contains("listActive")) {
					params.lfj = params.lfj + ele.getAttribute("codenum") + ",";
				}
			})

			
			
			params.code = params.code.substr(0, params.code.length - 1);
			params.fl = params.fl.substr(0, params.fl.length - 1);
			
			params.lfj = params.lfj.substr(0, params.lfj.length - 1);
			
			return params;
		},
		//获得行业类型的code码和监管类型的分类
		getCodeFl: function (target) {
			if(target){
				if (target.hasClass("layerList")) {
					target.removeClass("layerList");
				} else {
					target.addClass("layerList");
				}
			}
			return this.getCode();
		},
		//根据元素表名称获得元素id名称
		selectLayer: function (selLay) {
			var ly = "";
			switch (selLay) {
				case "GEOM_QYJCXX": //企业
					ly = "qy";
					break;
				case "GEOM_YJYA_YJWZ"://救援物资
					ly = "wz";
					break;
				case "GEOM_YJZY_YJJYZB": //救援装备
					ly = "zb";
					break;
				case "GEOM_SGBS":   //事故
					ly = "sg";
					break;
				case "GEOM_WXYHZB":   //重大危险源
					ly = "wxy";
					break;
				case "GEOM_YJZY_YJJYDW"://救援队伍
					ly = "dw";
					break;
			}
			return ly;
		},
		//根据元素名称获得表名
		getLayerName: function (selLay) {
			var ly = "";
			switch (selLay) {
				case "qy": //企业
				case "qy_jglx": //企业按照监管行业进行分类
					ly = "GEOM_QYJCXX";
					break;
				case "wz"://救援物资
					ly = "GEOM_YJYA_YJWZ";
					break;
				case "zb": //救援装备
					ly = "GEOM_YJZY_YJJYZB";
					break;
				case "sg":   //事故
					ly = "GEOM_SGBS";
					break;
				case "wxy":   //重大危险源
					ly = "GEOM_WXYHZB";
					break;
				case "dw"://救援队伍
					ly = "GEOM_YJZY_YJJYDW";
					break;
			}
			return ly;
		},
		//根据不同图层返回不同的过滤条件
		filterSql: function (selLay, sql, layers) {
			var ly = "";
			var splitSql = sql.split("and");
			switch (selLay) {
				case "wxylb":
					if (layers.length === 0) {
						ly = mapConfig.userFilter.split("=")[1] + " and LX in(0) ";

					} else {
						ly = mapConfig.userFilter.split("=")[1] + " and LX in(" + '\'' + layers.join("','") + '\') ';
					}
					break;
				case "qy_jglx":
					if (layers.length === 0) {
						ly = mapConfig.userFilter.split("=")[1] + " and JGTYPE in(0) ";

					} else {
						ly = mapConfig.userFilter.split("=")[1] + " and JGTYPE in(" + '\'' + layers.join("','") + '\') ';
					}
					break;
				case "GEOM_QYJCXX": //企业
					if (splitSql.length >= 3) {
						ly = "HYLB in(" + '\'' + layers.join("','") + '\') ' + " and " + sql.split("and")[1];
					} else {
						ly = "HYLB in(" + '\'' + layers.join("','") + '\') ' + " and " + sql.split("and")[splitSql.length - 1];
					}
					break;
				case "GEOM_YJYA_YJWZ"://救援物资
					var orSql = $.map(layers, function (val) {
						return "FTYPE like '" + val.replace(/00$/, "%'");
					});
					if (splitSql.length >= 3) {
						ly = splitSql[0] + " and " + splitSql[1] + " and " + orSql.join(" or ");
					} else {
						ly = sql + " and " + orSql.join(" or ");
					}
					
					break;
				case "GEOM_SGBS":   //事故
				case "GEOM_WXYHZB":   //重大危险源
				case "GEOM_WKK"://尾矿库
					if (splitSql.length >= 3) {
						ly = splitSql[0] + "and" + splitSql[1] + "and GRADE in(" + "'" + layers.join("','") + "')";
					} else {
						ly = sql + "and GRADE in(" + "'" + layers.join("','") + "')";
					}
					break;
				case "GEOM_YJZY_YJJYZB":
				case "GEOM_YJZY_YJJYDW"://救援队伍
					if (splitSql.length >= 3) {
						ly = splitSql[0] + "and" + splitSql[1] + "and FTYPE like '"+layers[0]+"%'";
					} else {
						ly = sql + "and FTYPE like '"+layers[0]+"%'";
					}
					break;
			}
			return ly;
		},
		//根据专题图取消勾选
		cancelChecked: function (selLay) {
			var ly = this.selectLayer(selLay);
			if (ly === "") return;
			$("#" + ly + " input").each(function () {
				$(this).prop("checked", false);
			})
		},
		//根据专题地图的选择进行勾选
		checkLayer: function (selLay) {
			var ly = this.selectLayer(selLay);
			if (ly === "") return;
			$("#" + ly + " input").each(function () {
				$(this).prop("checked", true);
			})
		},
		//给搜索弹出框添加	删除
		/*searchBox: function () {
			var that = this;
			//搜索框的图层
			$("#searchLayer ul li").click(function () {
				that.searchName = $(this).text();
				$(this).addClass("active").siblings().removeClass("active");
				var id = $(this).attr("getId");
				$("#" + id).css("display", "block").siblings("div").css("display", "none");
			});
		},*/
		searchName: "图层选择",
		jqueryExtend: jqueryExtend,
		//* 提交form表单数据传往后台 @param {String} id form表单的id
		compannySubmit: function (id, closeId) {
			$('#' + id).form('submit', {
				url: mapConfig.insertUrl,
				onSubmit: function () {
					return $(this).form('enableValidation').form('validate');
				},
				success: function (data) {
					if (data === "true" || data === "") {
						$.messager.alert('', '录入成功！', 'info');
					} else {
						$.messager.alert('', '录入失败！', 'info');
					}
					$("#" + closeId).dialog("close");
				}
			});
		},
		//* 清空弹出框中企业信息 @param {String} id form表单的id
		clearForm: function (id) {
			$('#' + id).form('clear');
		},
		//浏览器全屏控制
		fullScreen: function () {
			var el = document.documentElement,
				rfs = el.requestFullScreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen,
				wscript;

			if (typeof rfs != "undefined" && rfs) {
				rfs.call(el);
				return;
			}

			if (typeof window.ActiveXObject != "undefined") {
				wscript = new ActiveXObject("WScript.Shell");
				if (wscript) {
					wscript.SendKeys("{F11}");
				}
			}
		},
		//初始化菜单列表
		initSearchList: function (ly) {
			var that = this;
			$.post("/main/onemap/getLayerList", function (data) {
				var datas = JSON.parse(data);
				var i = 0, z;
				for (i = 0, z = datas[0].qy.length; i < z; i++) {
					$("#qy").append("<label title='" + datas[0].qy[i].codename + "'><input type='checkbox' checked=true code='" + datas[0].qy[i].code + "'/>" + datas[0].qy[i].codename + "</label>");
				}
				for (i = 0, z = datas[0].qy_jglx.length; i < z; i++) {
					$("#qy_jglx").append("<label title='" + datas[0].qy_jglx[i].codename + "'><input type='checkbox' checked=true code='" + datas[0].qy_jglx[i].code + "'/>" + datas[0].qy_jglx[i].codename + "</label>");
				}
				//				for (i = 0, z = datas[0].wz.length; i < z; i++) {
				//					$("#wz").append("<p>" + datas[0].wz[i].codename + "</p>");
				//					for (var m = 0, n = datas[0].wz[i].son.length; m < n; m++) {
				//						$("#wz").append("<label title='" + datas[0].wz[i].son[m].codename + "'><input type='checkbox' checked=true code='" + datas[0].wz[i].son[m].code + "'/>" + datas[0].wz[i].son[m].codename + "</label>");
				//					}
				//                }
				//				for (i = 0, z = datas[0].zb.length; i < z; i++) {
				//					$("#zb").append("<p>" + datas[0].zb[i].codename + "</p>");
				//					for (var m = 0, n = datas[0].zb[i].son.length; m < n; m++) {
				//						$("#zb").append("<label title='" + datas[0].zb[i].son[m].codename + "'><input type='checkbox' checked=true code='" + datas[0].zb[i].son[m].code + "'/>" + datas[0].zb[i].son[m].codename + "</label>");
				//					}
				//				}
				for (i = 0, z = datas[0].sg.length; i < z; i++) {
					$("#sg").append("<label title='" + datas[0].sg[i].codename + "'><input type='checkbox' checked=true code='" + datas[0].sg[i].code + "'/>" + datas[0].sg[i].codename + "</label>");
				}
				//				for (i = 0, z = datas[0].wxy.length; i < z; i++) {
				//					$("#wxy").append("<label title='" + datas[0].wxy[i].codename + "'><input type='checkbox' checked=true code='" + datas[0].wxy[i].code + "'/>" + datas[0].wxy[i].codename + "</label>");
				//				}

				//				for (i = 0, z = datas[0].wxylb.length; i < z; i++) {
				//					$("#wxylb").append("<label title='" + datas[0].wxylb[i].codename + "'><input type='checkbox' checked=true code='" + datas[0].wxylb[i].code + "'/>" + datas[0].wxylb[i].codename + "</label>");
				//				}
				/*for (i = 0, z = datas[0].dw.length; i < z; i++) {
					$("#dw").append("<label title='" + datas[0].dw[i].codename + "'><input type='checkbox' checked=true code='" + datas[0].dw[i].code + "'/>" + datas[0].dw[i].codename + "</label>");
				}*/

				that.checkLayer(ly);

			});
		},
		//隐藏列表
		hideList:function(){
			$("#list").slideUp();
			$("#list3").slideUp();
		},
		//搜索框功能
		search:function(currentLayer){
			var val = $("#searchval").val();
			var $div = $("#list");
			$div.css("display", "none");
			$("#list3").slideUp();
			//var queryLayer = "HBAJ:" + currentLayer;
			
			if (currentLayer!=="") {
				mapTools.attributeQuery(currentLayer, val);
			} else {
				var code = $("#searchLayer input[type='radio']:checked").attr("code");
				mapTools.poiSearch(val, code, map);
			}
		},
		//退出浏览器全屏 删除
		/*exitFullScreen: function () {
			var el = document,
				cfs = el.cancelFullScreen || el.webkitCancelFullScreen || el.mozCancelFullScreen || el.exitFullScreen,
				wscript;

			if (typeof cfs != "undefined" && cfs) {
				cfs.call(el);
				return;
			}

			if (typeof window.ActiveXObject != "undefined") {
				wscript = new ActiveXObject("WScript.Shell");
				if (wscript != null) {
					wscript.SendKeys("{F11}");
				}
			}
		},*/
		//当得到应急响应点时定位到该点
		/**
		 * @api {类型 function} 当得到应急响应点时定位到该点 flyToLocation
		 * @apiParam {Array} coordinates 定位到的点的坐标
		 * @apiName flyToLocation 
		 * @apiGroup mapTools
		 */
		flyToLocation: flyToLocation,
		//清除专题图快捷入口的按下状态
		clearShortEnter:function(lengendLayer){
			var that=this;
			//检测其他图层的快捷按钮是否处于按下状态,并清除
			$("a.funcon").each(function(){
				var mSrc=this.firstChild.src;
				if(mSrc.search("_a")>-1){
					this.firstChild.src = mSrc.replace(mSrc.split("/")[7], mSrc.split("/")[7].replace("_a", ""));
					initMap.map.removeLayer(that.flayer);
					that.flayer=null;
					$(".celist").slideUp();
					!lengendLayer?"":lengendLayer.length=0;
					return false;
				}
			})
		},
		//专题图的快捷入口，选中的图层
		flayer:null,
		//图层快捷进入的方法
		layerClassification: function (operation,getList) {
			var map = initMap.map,dom=operation.dom,statLayers=operation.statLayers;
			var layerName=operation.layerName,searchLayer=operation.searchLayer,that=this;
			var src = dom.firstChild.src;
			if (src.search("_a") > -1) {
				dom.firstChild.src = src.replace(src.split("/")[7], src.split("/")[7].replace("_a", ""));
				searchLayer.length=0;
				initMap.statisticalLayer.getSource().clear();
				map.removeLayer(this.flayer);
				this.flayer=null;
			} else {
				
				//清除专题地图的所有选中状态
				$("#mm9 [ly]").each(function(){
					if(this.innerHTML.search("checked")>-1){
						this.querySelector("input").removeAttribute("checked");
					}
				})
				
				that.clearShortEnter();
				//清除所有专题图层
				for (var m = 0, n = statLayers.length; m < n; m++) {
					map.removeLayer(statLayers[m]);
				}
				//专题地图数组清空
				statLayers.length = 0;
				//i查询可查询图层数组清空
				searchLayer.length=0;
				//对专题图的统计清空
				initMap.statisticalLayer.getSource().clear();
				//mapTools.showData(layerName);
				
				//不同缩放等级进行不同的统计数据
				mapTools.zoomStatistics(layerName);
				
				
				this.flayer=mapTools.createLayer(layerName, map);
				searchLayer.push(layerName);
				dom.firstChild.src = src.replace(src.split("/")[7], src.split("/")[7].split(".")[0] + "_a.png");
				getList();
			}
		}
	}
});