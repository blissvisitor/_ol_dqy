define(function(){
    
    //各个图层的前缀地址
    var idLayer="http://211.90.37.80:8081/";//geoserver网址
    //var idLayer="http://211.90.37.80:8081/";//geoserver网址
  //var idLayer="http://124.239.190.119:5210/";//geoserver网址
    
    var userFilters="?";
    
    var geoserver="geoserver/HBAJ/ows?service=WFS&version=1.0.0&request=GetFeature&outputFormat=application%2Fjson"+userFilters+"&typeName=";
    return{
        userFilter:userFilters,
        //根据年份的专题图统计
        tongji:"/main/onemap/statisticThematic2",
        //缓冲区分析范围内查询
        bufferUrl:idLayer+"geoserver/wfs?",
        //通用wms服务地址
        hebeiBordr:idLayer+"geoserver/HBAJ/wms",
        // 搜索工具需要的图层地址
        queryUrl : idLayer+"geoserver/wfs?",
        // 搜索工具需要的图层名称,此处为企业基础信息表
        queryLayer : 'HBAJ:GEOM_QYJCXX',
        //标绘图片地址
        imagePoint:"../resources/image/map/Point.png",
        //兴趣点搜索地址
        poiUrl:"http://211.90.37.80/tdt/dmdz/geocoding?",
        //政务云正常访问天地图http://211.90.37.80/tdt/dmdz/geocoding?
        //电信访问天地图http://61.182.226.190:8082/tdt/dmdz/geocoding?
        //天地图瓦片地图网址
        tiandituUrl:"http://211.90.37.80/tdt/",
        //对十个图层的统计statistic
        statistical:"/main/onemap/statistic",
        //页面初始化的时候按照地级市统计企业个数
        qyTbName:"GEOM_QYJCXX",
        //当点击测量时，图标改为尺子的样式，暂时用的百度的图标
        meatureIcon:"../resources/image/map/ruler.cur",
        //风险指数模块，获取河北省所有市面geojson
        riskCityUrl:idLayer+"geoserver/HBAJ/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=HBAJ:GEOM_HB_CITY&outputFormat=application%2Fjson",
      //风险指数模块，获取河北省所有县面geojson
        riskCountyUrl:idLayer+"geoserver/HBAJ/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=HBAJ:hbcounty&outputFormat=application%2Fjson"

    }
});