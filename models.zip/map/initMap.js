define(["mapConfig", "ol", "chartsShow"], function (mapConfig, ol, chartsShow) {
    //获取渐变色
    function getGradientColor(color,num,feature,resolution){
        var canvas = document.createElement('canvas');
        var context = canvas.getContext('2d');
        var pixelRatio = ol.has.DEVICE_PIXEL_RATIO;
        var extent = feature.getGeometry().getExtent();
        // Gradient starts on the left edge of each feature, and ends on the right.
        // Coordinate origin is the top-left corner of the extent of the geometry, so
        // we just divide the geometry's extent width by resolution and multiply with
        // pixelRatio to match the renderer's pixel coordinate system.
        var grad = context.createLinearGradient(0, 0,
                ol.extent.getWidth(extent) / resolution * pixelRatio, 0);
        grad.addColorStop(0, 'white'); 
        grad.addColorStop(0.2, 'yellow'); 
        grad.addColorStop(0.5, 'orange'); 
        grad.addColorStop(1, 'red');
            return grad;
        }
	return {
		/**
		 * @api {类型 ol.interaction.Select} 专题图的选择交互工具，只能选择空间统计图层 themeSelect
		 * @apiName themeSelect 
		 * @apiGroup initMap
		 */
		themeSelect: new ol.interaction.Select({
			condition: ol.events.condition.singleClik,
			style: function (f) {
				return chartsShow.chartTypeStyle(f, false);
			},
			filter: function (feature, layers) {
				if (layers === null) {
					return false;
				}
				if (layers.get("id") === "themeMap") {
					return true;
				}
				return false;
			}
		}),
		//是否启用增加资源功能
		addResources:false,
		//清除当前位置点
		stopAnim: "",
		that:this,
		companysLayer: new ol.layer.Image({
			source: new ol.source.ImageWMS({
				crossOrigin: "anonymous",
				ratio: 1,
				url: mapConfig.hebeiBordr,
				params: {
					'FORMAT': "image/png",
					'VERSION': '1.1.1',
					STYLES: '',
					LAYERS: mapConfig.queryLayer
				}
			})
		}),
		riskLayer:new ol.layer.Vector({
			source:new ol.source.Vector(),
			isRisk:0,//风险指数模块是否激活，0否，1是,
			riskStatus:0,//status风险指数模块图层数据状态，0无，1县，2市
			zIndex:2
		}),
		// ol.Map()的地图对象
		map: null,
		// JSON数据的矢量地图图层
		layerJson: null,
		/**
		 * @api {类型 ol.layer.Vector} 空间统计图层 themeMap
		 * @apiName themeMap 
		 * @apiGroup initMap
		 */
		themeMap: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "themeMap"
		}),
		/**
		 * @api {类型 ol.layer.Vector} 应急响应显示事故点的图层 yjxyLayer
		 * @apiName yjxyLayer 
		 * @apiGroup initMap
		 */
		yjxyLayer: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "yjxyLayer"
		}),
		/**
		 * @api {类型 ol.layer.Vector} 空间定位时，显示的点 locationLayer
		 * @apiName locationLayer 
		 * @apiGroup initMap
		 */
		locationLayer: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "locationLayer",
			style:new ol.style.Style({
				image:new ol.style.RegularShape({
		            fill: new ol.style.Fill({color:"#ff0000"}),
		            stroke: new ol.style.Stroke({
		            	width:2,
		            	color:"#ff0000"
		            }),
		            points: 4,
		            radius: 10,
		            radius2: 0,
		            angle: 0
		          })
			})
		}),
		//四色图
		sisetu: null,
		//监管图层
		supervise: null,
		//取消动画的key值
		requestAnimationKey: "",
		/**
		 * @api {类型 ol.layer.Vector} 最短路径图层 routeLayer
		 * @apiName routeLayer 
		 * @apiGroup initMap
		 */
		routeLayer: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "routeLayer",
			style: new ol.style.Style({
				stroke: new ol.style.Stroke({
					color: [255, 0, 0],
					width: 4
				})
			}),
			zIndex: 100
		}),
		//当登录用户为地级市时，显示地级市的边界
		/**
		 * @api {类型 ol.layer.Vector} 当登录用户为地级市时，显示地级市的边界 dijishiLayer
		 * @apiName dijishiLayer 
		 * @apiGroup initMap
		 */
		dijishiLayer: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "dijishiLayer",
			zIndex: 1,
			style:new ol.style.Style({
				stroke:new ol.style.Stroke({
					color:"#ff0000",
					width:3
				})
			})
		}),
		//事故图层
		/**
		 * @api {类型 ol.layer.Vector} 事故图层 sgbsLayer
		 * @apiName sgbsLayer 
		 * @apiGroup initMap
		 */
		sgbsLayer: new ol.layer.Image({
			source: new ol.source.ImageWMS({
				crossOrigin: "anonymous",
				url: mapConfig.hebeiBordr,
				params: {
					'FORMAT': "image/png",
					'VERSION': '1.1.1',
					STYLES: '',
					LAYERS: "HBAJ:GEOM_SGBS"
				}
			})
		}),
		//应急救援点图层
		/**
		 * @api {类型 ol.layer.Vector} 应急救援点图层 rescueLayer
		 * @apiName rescueLayer 
		 * @apiGroup initMap
		 */
		rescueLayer: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "rescueLayer",
			style: new ol.style.Style({
				image: new ol.style.Icon({
					src: "../resources/image/map/huo.png",
					anchor: [0.5, 1]
				})
			})
		}),
		// 轨迹动画和实时位置图层
		/**
		 * @api {类型 ol.layer.Vector} 用来展示轨迹动画和实时位置图层 animationLay
		 * @apiName animationLay 
		 * @apiGroup initMap
		 */
		animationLay: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "animationLay"
		}),
		// 摄像头图层
		/**
		 * @api {类型 ol.layer.Image} 摄像头图层 cameraLayer
		 * @apiName cameraLayer 
		 * @apiGroup initMap
		 */
		cameraLayer: new ol.layer.Image({
			visible: false,
			source: new ol.source.ImageWMS({
				crossOrigin: "anonymous",
				ratio: 1,
				url: mapConfig.hebeiBordr,
				params: {
					'FORMAT': "image/png",
					'VERSION': '1.1.1',
					LAYERS: 'HBAJ:TBCAMERA',
					cql_filter:"ISENABLE in(0)"
				}
			}),
			id: "cameraLayer"
		}),
		//统计图图层
		statisticalLayer: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "statisticalLayer2",
			minResolution:0.0006866455078125,
			isStic:true,
			zIndex:1
		}),
		// 用来存放根据属性查询出来的结果
		searchLayer: new ol.layer.Vector({
			source: new ol.source.Vector(),
			id: "searchLayer",
			zIndex:101,
			style: new ol.style.Style({
				image: new ol.style.Circle({
					radius: 4,
					fill: new ol.style.Fill({
						color: "#FFCC99"
					}),
					stroke: new ol.style.Stroke({
						color: "#FFFFFF",
						width: 1
					})
				})
			})
		}),
		
		//标绘适量图层
		plotLayer:new ol.layer.Vector({
			source: new ol.source.Vector(),
			style:function(feature,resolution){
				var strokeColor='#00ff00';
				var fillColor='#ff0000';
				var type=feature.getGeometry().getType();
				var text=feature.getProperties().name;
				var labeltype=feature.getProperties().labeltype;
				switch(type){
				case 'Polygon':
				    var plFillColor='rgba(255,0,0,0)';
				    var plStrokeColor='#ff0000';
				    switch (labeltype){
				        case '聚集地':
				            plFillColor='rgba(255,0,0,0)';
				            break;
				        case '长箭头':
				        case '直箭头':    
				            //plFillColor=getGradientColor('','',feature,resolution);//todo 填充渐变色
				        	plFillColor="#ff0000";
				            plStrokeColor='#ff0000';//改为透明
				            break;
			            default:
			                break;        
				    }
					return new ol.style.Style({
						fill:new ol.style.Fill({
							color:plFillColor
						}),
						stroke:new ol.style.Stroke({
							color:plStrokeColor,
							width:2
						}),
						zIndex: 80,
						text: new ol.style.Text({
							text: text || "",
							font:'16px 微软雅黑'
						})
					})
					break;
				case 'Point':
				    var pFillColor='rgba(255,0,0,0)';
                    var pStrokeColor='rgba(255,0,0,0)';
                    switch (labeltype){
                        case '关注点':
                            return new ol.style.Style({
                                image:new ol.style.Circle({
                                    fill: new ol.style.Fill({
                                        color: fillColor
                                    }),
                                    stroke: new ol.style.Stroke({
                                        color: strokeColor,
                                        width: 2
                                    }),
                                    radius: 6
                                }),
                                zIndex: 100,
                                text: new ol.style.Text({
                                    text: text || "",
                                    font:'16px 微软雅黑'
                                })
                            })
                            break;
                        case '文字标绘': 
                        	var canvas=document.createElement("canvas");
                        	var width=text.length*17;
                        	canvas.width=width;
                        	canvas.height=20;
                        	var ctx=canvas.getContext("2d");
                        	ctx.strokeStyle="#00BCD4";
                        	ctx.fillStyle="#FFFFFF";
                        	ctx.lineWidth=6;
                        	ctx.beginPath();
                        	ctx.moveTo(0,0);
                        	ctx.lineTo(width,0);
                        	ctx.lineTo(width,20);
                        	ctx.lineTo(0,20);
                        	ctx.lineTo(0,0);
                        	ctx.closePath();
                        	ctx.fill();
                        	ctx.stroke();
                        	
                            return new ol.style.Style({
                                image:new ol.style.Icon({
                                	img: canvas,
                					imgSize: [canvas.width, canvas.height]
                                }),
                                zIndex: 100,
                                text: new ol.style.Text({
                                    text: text || "",
                                    font:'12px 微软雅黑',
                                    fill:new ol.style.Fill({
                                        color: '#2b6394'
                                    })
                                })
                            })
                            break;
                        default:
                            break;        
                    }
//					return new ol.style.Style({
//						image:new ol.style.Circle({
//							fill: new ol.style.Fill({
//								color: fillColor
//							}),
//							stroke: new ol.style.Stroke({
//								color: strokeColor,
//								width: 2
//							}),
//							radius: 6
//						}),
//						zIndex: 100,
//						text: new ol.style.Text({
//							text: text || "",
//							font:'16px 微软雅黑'
//						})
//					})
					break;
				case 'LineString':	
				    var lineStrokeColor='#ff0000';//红色
				    switch (labeltype){
                    case '简单箭头':
                        lineStrokeColor='#ff0000';//红色
                        break;
                    case '撤离路线':   
                        lineStrokeColor='#4D93D7';//蓝色
                        break;
                    default:
                        break;        
                }
					return new ol.style.Style({						
						stroke:new ol.style.Stroke({
							color:lineStrokeColor,
							width:6
						}),
						zIndex: 90,
						text: new ol.style.Text({
							text: text || "",
							font:'16px 微软雅黑'
						})
					})
					break;
				}
			}
		}),
		//用来存放五个专题图图层
		thematicLayers: [],
		//天地图街道地图
		tiandituVector: null,
		//天地图卫星地图
		tiandituSatellite: null,
		// 初始化地图函数
		/**
		 * @api {类型 ol.Map} 初始化地图并返回地图对象 init
		 * @apiName init 
		 * @apiGroup initMap
		 */
		init: function () {

			var tianditu = new ol.layer.Tile({
				source: new ol.source.XYZ({
					url: "http://t0.tianditu.com/DataServer?T=vec_c&x={x}&y={y}&l={z}",
					projection: "EPSG:4326"
                    })
			});

			var tianditu2 = new ol.layer.Tile({
				source: new ol.source.XYZ({
					url: "http://t5.tianditu.com/DataServer?T=cva_c&x={x}&y={y}&l={z}",
					projection: "EPSG:4326"
                    })
			});


			//天地图街道地图
			var streetLayer = new ol.layer.Tile({
				source: new ol.source.XYZ({
					projection: "EPSG:4326",
					url: mapConfig.tiandituUrl + "sl_dt/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_dt&STYLE=sl_dt&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
				})
			});
			//天地图注记图层
			var streetAnnotationLayer = new ol.layer.Tile({
				//visible:false,
				preload: 0,
				useInterimTilesOnError: false,
				source: new ol.source.XYZ({
					projection: "EPSG:4326",
					url: mapConfig.tiandituUrl + 'sl_zj/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_zj&STYLE=sl_zj&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
				})
			});


			//天地图河北省界
			var boundaryLayer = new ol.layer.Tile({
				minResolution: 0.001373291015625,
				source: new ol.source.XYZ({
					projection: "EPSG:4326",
					url: mapConfig.tiandituUrl + 'HBSJ/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=HBSJ&STYLE=HBSJ&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
				})
			});


			//天地图卫星影像图
			var satelliteLayer = new ol.layer.Tile({
				preload: 0,
				useInterimTilesOnError: false,
				source: new ol.source.XYZ({
					projection: "EPSG:4326",
					url: mapConfig.tiandituUrl + 'yx_dt/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=yx_dt&STYLE=yx_dt&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
				})
			});

			//天地图注记图层
			var satelliteAnnotationLayer = new ol.layer.Tile({
				preload: 0,
				useInterimTilesOnError: false,
				source: new ol.source.XYZ({
					projection: "EPSG:4326",
					url: mapConfig.tiandituUrl + 'yx_zj/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=yx_zj&STYLE=yx_zj&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
				})
			});

			this.tiandituVector = new ol.layer.Group({
				visible: true,
				layers: [streetLayer, streetAnnotationLayer]
			});

			this.tiandituSatellite = new ol.layer.Group({
				visible: false,
				layers: [satelliteLayer, satelliteAnnotationLayer]
			});



			var that = this;


			//县的边界
			var countyLine = new ol.layer.Image({
				source: new ol.source.ImageWMS({
					crossOrigin: "anonymous",
					ratio: 1,
					url: mapConfig.hebeiBordr,
					params: {
						'FORMAT': "image/png",
						'VERSION': '1.1.1',
						STYLES: '',
						LAYERS: 'HBAJ:countyLine',
					}
				})
			});

			//辛集市和定州市边界图层
			var sisetu = new ol.layer.Image({
				visible: true,
				source: new ol.source.ImageWMS({
					crossOrigin: "anonymous",
					ratio: 1,
					url: mapConfig.hebeiBordr,
					params: {
						'FORMAT': "image/png",
						'VERSION': '1.1.1',
						STYLES: '',
						LAYERS: 'HBAJ:XINJI',
					}
				})
			});
			this.sisetu = sisetu;

			//监管图层
			var supervise = new ol.layer.Image({
				visible: false,
				source: new ol.source.ImageWMS({
					crossOrigin: "anonymous",
					ratio: 1,
					url: mapConfig.hebeiBordr,
					params: {
						'FORMAT': "image/png",
						'VERSION': '1.1.1',
						STYLES: '',
						LAYERS: 'HBAJ:GEOM_QYJCXX',
					}
				})
			});
			this.supervise = supervise;

			var map = new ol.Map({
				target: "map",
				interactions: ol.interaction.defaults({
					doubleClickZoom:false
				}),
				layers: [this.tiandituVector, this.tiandituSatellite, boundaryLayer, countyLine, sisetu, supervise,this.plotLayer],
				//layers : [this.tiandituVector,countyLine,sisetu],
				view: new ol.View({
					zoom: 7,
					maxZoom: 18,
					minZoom: 6,
					center: [116.112212109375, 38.566251171875],
					projection: "EPSG:4326"
				}),
				logo: false
			});



			/*var map = new ol.Map({
				target : "map",
				layers : [this.tiandituVector,this.tiandituSatellite,boundaryLayer],
				view : new ol.View({
					zoom : 7,
					maxZoom:18,
					center : [116.112212109375,38.566251171875],
					projection:"EPSG:4326"
				}),
				//loadTilesWhileInteracting:false,
				logo : false
			});*/
			map.addLayer(that.statisticalLayer);
			map.addLayer(that.animationLay);
			map.addLayer(that.cameraLayer);
			map.addLayer(that.routeLayer);
			map.addLayer(that.rescueLayer);
			map.addLayer(that.dijishiLayer);
			map.addLayer(that.yjxyLayer);
			map.addLayer(that.locationLayer);
			map.addLayer(that.riskLayer);//增加风险地图图层

			
			//雄安新区的边界
			var XIONGAN = new ol.layer.Image({
				minResolution: 0.001373291015625,
		        source: new ol.source.ImageWMS({
		        	crossOrigin: "anonymous",
		        	ratio: 1,
		          url: mapConfig.hebeiBordr,
		          params: {'FORMAT': "image/png",
		                   'VERSION': '1.1.1',  
		                STYLES: '',
		                LAYERS: 'HBAJ:XIONGAN',
		          }
		        }),
		        zIndex:0
		      });
			map.addLayer(XIONGAN);

			
			 var XIONGANPOINT = new ol.layer.Image({
				 minResolution: 0.001373291015625,
			        source: new ol.source.ImageWMS({
			        	crossOrigin: "anonymous",
			        	ratio: 1,
			          url: mapConfig.hebeiBordr,
			          params: {'FORMAT': "image/png",
			                   'VERSION': '1.1.1',  
			                STYLES: '',
			                LAYERS: 'HBAJ:xionganPoint',
			          }
			        }),
			        zIndex:0
			      });
			 map.addLayer(XIONGANPOINT);



			/*var untiled = new ol.layer.Image({
			        source: new ol.source.ImageWMS({
			          ratio: 1,
			          url: 'http://172.16.5.95:8080/geoserver/HBAJ/wms',
			          params: {'FORMAT': "image/png",
			                   'VERSION': '1.1.1',  
			                STYLES: '',
			                LAYERS: 'HBAJ:hebei_county',
			          }
			        }),
			        map:map
			      });*/




			this.map = map;




			map.addLayer(this.searchLayer);

			//显示鼠标所在位置的经纬度
			var mousePosition = new ol.control.MousePosition({
				coordinateFormat: ol.coordinate.createStringXY(5),
				projection: 'EPSG:4326',
				className: "ol-mouse-position2",
				target: document.getElementById("mousePosition")
			});
			map.addControl(mousePosition);

			//比例尺控件
			var scaleLine = new ol.control.ScaleLine({
				units: "metric"
				//className:"ol-scale-line2"
			});
			map.addControl(scaleLine);

			return map;
		},
		/**
	     * 创建绘图交互工具
	     * @param {} drawType 绘制类型包括点线面
	     * @param {} source 绘制图形要添加到的图层
	     * @returns {ol.interaction.Draw()} 
	     */
		/**
		 * @api {类型 function} 创建绘图交互工具 createDraw
		 * @apiSuccess (返回类型) {ol.interaction.Draw} return 创建好的样式类型
		 * @apiParam {String} drawType 需要绘制的类型
		 * @apiParam {ol.source.Vector} source 把图形要绘制到的图层
		 * @apiParam {ol.style.Style} style 将要绘制图形的样式
		 * @apiName createDraw 
		 * @apiGroup initMap
		 */
		createDraw: function (drawType, source, style) {
			var draw = new ol.interaction.Draw({
				type: drawType,
				source: source,
				style: style
			});
			return draw;
		},
		/**
		 * 创建样式
		 * @param {String} fillColor 面的填充颜色
		 * @param {String} strokeColor 线的颜色
		 * @param {String} strokeWidth 线的宽度
		 * @param {String} radius 点的半径
		 * @param {String} [text] 图形标注名称
		 * return ol.style.Style()
		 */
		/**
		 * @api {类型 function} 创建样式 createStyle
		 * @apiSuccess (返回类型) {ol.style.Style} return 返回创建好的样式类型
		 * @apiParam {String} fillColor 面的填充颜色可以是rgba或者十六进制的颜色
		 * @apiParam {String} strokeColor 面的边界或者线的填充颜色
		 * @apiParam {Number} strokeWidth 面的边界或者线的线条宽度
		 * @apiParam {Number} radius 点的大小半径
		 * @apiParam {String} text 图形内要显示的文本内容
		 * @apiName createStyle 
		 * @apiGroup initMap
		 */
		createStyle: function (fillColor, strokeColor, strokeWidth, radius, text) {
			var style = new ol.style.Style({
				fill: new ol.style.Fill({
					color: fillColor
				}),
				image: new ol.style.Circle({
					fill: new ol.style.Fill({
						color: fillColor
					}),
					stroke: new ol.style.Stroke({
						color: strokeColor,
						width: strokeWidth || 1
					}),
					radius: radius || 5
				}),
				stroke: new ol.style.Stroke({
					color: strokeColor,
					width: strokeWidth
				}),
				zIndex: 100,
				text: new ol.style.Text({
					text: text || "",
					font:'18px 微软雅黑'
				})
			});
			return style;
		},
	    /*
	     * 根据手机浏览器定位*/
		browserPositioning: function () {
			var that = this;
			if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(that.getBrowserPosition, that.positionError, {
					enableHighAccuracy: true,
					// 指定获取地理位置的超时时间，默认不限时，单位为毫秒
					timeout: 5000
				});
			}
		},
	    /*
	     * 获得浏览器的位置*/
		getBrowserPosition: function (position) {
			var lon = position.coords.longitude;
			var lat = position.coords.latitude;
			//alert(position.coords.longitude);
			//alert(position.coords.latitude);
			layer.msg("开始定位");
			this.panToPoint([lon, lat]);
		},
		/**
		 * @api {类型 function} 平滑过渡到该点 panToPoint
		 * @apiParam {Array} point 即将要移动到的点的坐标[经度,纬度]
		 * @apiName panToPoint 
		 * @apiGroup initMap
		 */
		panToPoint: function (point,level) {
			var that = this;
			var pan = new ol.animation.pan({
				source: that.map.getView().getCenter(),
				easing:function(){
					return 1;
				}
			});
			var zoom=new ol.animation.zoom({
				resolution:that.map.getView().getResolution()
			});
			//if(that.map.getView().getZoom()!=12){
				that.map.beforeRender(zoom);
				that.map.getView().setZoom(level?level:12);
			//}
			that.map.beforeRender(pan);
			that.map.getView().setCenter(point);
		},
		/*平滑过渡到该点
	     * @params {Array} point [lon,lat]
	     */
		/**
		 * @api {类型 function} 平滑过渡到该点 panToPoint3
		 * @apiParam {Array} point 即将要移动到的点的坐标[经度,纬度]
		 * @apiParam {Number} zoom 地图缩放等级，缩放数值越大比例尺越大
		 * @apiName panToPoint3 
		 * @apiGroup initMap
		 */
		panToPoint3: function (point,zoom) {
			var that = this;
			var pan = new ol.animation.pan({
				duration: 2000,
				source: that.map.getView().getCenter()
			});
			var azoom = new ol.animation.zoom({
				resolution:that.map.getView().getResolution(),
				duration: 2000
			});
			that.map.beforeRender(pan);
			that.map.getView().setCenter(point);
			that.map.beforeRender(azoom);
			that.map.getView().setZoom(zoom);
		},
	    /*跳转到该点
	     * @params {Array} point [lon,lat]
	     */
		panToPoint2: function (point) {
			var that = this;
			that.map.getView().setCenter(point);
			that.map.getView().setZoom(12);
		}
		,
	    /*
	     * 当不能获得浏览器位置的错误提示信息*/
		positionError: function (error) {
			//return;
			switch (error.code) {
				case error.PERMISSION_DENIED:
					layer.msg("", "您拒绝了地理定位");
					break;
				case error.POSITION_UNAVAILABLE:
					layer.msg("浏览器定位错误提示", "无法获取地理位置！");
					break;
				case error.TIMEOUT:
					layer.msg("浏览器定位错误提示", "位置请求超时!");
					break;
				case error.UNKNOWN_ERROR:
					layer.msg("错误提示", "错误！");
					break;
			}
		},
	    /*
		 * 根据不同类型显示不同汽车样式
		 * @param type 汽车样式
		 * @param angle 汽车行驶角度
		 * */
		/**
		 * @api {类型 function} 根据不同类型显示不同汽车样式 setCarStyle
		 * @apiParam {String} type 汽车类型1121为卡车，1122为轿车，1123为救护车
		 * @apiParam {Number} angle 汽车图标旋转角度，单位为弧度
		 * @apiSuccess (返回类型) {ol.style.Style} return 返回不同图标的汽车样式类型
		 * @apiName setCarStyle 
		 * @apiGroup initMap
		 */
		setCarStyle: function (type, angle) {
			var car = ""
			switch (type) {
				case "1121":
					car = "cache";
					break;
				case "1122":
					car = "jiaoche";
					break;
				case "1123":
					car = "jiuhu";
					break;
			}
			var style = new ol.style.Style({
				image: new ol.style.Icon({
					src: "/main/resources/image/map/" + car + ".png",
					rotation: angle ? angle : 0
				})
			});
			return style;
		},
	    /*
	     * 创建聚合图层
	     * */
		createClusterLayer: function (url, id) {
			var layer = new ol.layer.Vector({
				visible: false,
				id: id,
				source: new ol.source.Cluster({
					source: new ol.source.Vector({
						url: url,
						format: new ol.format.GeoJSON()
					})
				}),
				style: function (feature) {
					var radius = feature.get("features").length;
					var style;
					if (radius != 1) {
						style = new ol.style.Style({
							image: new ol.style.Circle({
								radius: 8,
								fill: new ol.style.Fill({
									color: "#ff0000"
								}),
								stroke: new ol.style.Stroke({
									width: 2,
									color: "#00ff00"
								})
							}),
							text: new ol.style.Text({
								text: radius.toString(),
								fill: new ol.style.Fill({
									color: '#fff'
								})
							})
						})
					} else {

						var grade = parseInt(feature.get("features")[0].get("GRADE"));
						var color, text;
						if (id == "majarHazard") {//重大危险源
							switch (grade) {
								case 802:
									grade = 4;
									break;
								case 809:
									grade = 4;
									break;
								case 808:
									grade = 3;
									break;
								case 807:
									grade = 2;
									break;
								case 806:
									grade = 1;
									break;
							}
						} else if (id == "accident") {//事故
							switch (grade) {
								case 751:
									grade = 4;
									break;
								case 750:
									grade = 3;
									break;
								case 749:
									grade = 2;
									break;
								case 748:
									grade = 1;
									break;
							}
						} else if (id == "hiddenPerils") {//隐患排查
							switch (grade) {
								case 1067:
									grade = 4;
									break;
								case 1068:
									grade = 3;
									break;
							}
						} else if (id == "contingency_plan") {//应急预案
							switch (grade) {
								case 702:
									grade = 5;
									break;
								case 703:
									grade = 5;
									break;
								case 704:
									grade = 4;
									break;
								case 705:
									grade = 4;
									break;
								case 706:
									grade = 3;
									break;
								case 707:
									grade = 3;
									break;
								case 708:
									grade = 2;
									break;
								case 709:
									grade = 2;
									break;
								case 710:
									grade = 1;
									break;
							}
						} else if (id == "standardized") {//标准化
							switch (grade) {

								case 702:
									grade = 1;
									break;
								case 540:
									grade = 1;
									break;
								case 541:
									grade = 2;
									break;
								case 542:
									grade = 3;
									break;
								case 543:
									grade = 4;
									break;
								case 544:
									grade = 5;
									break;
							}
						}
						switch (grade) {
							case 1:
								color = "#00C90D";
								text = "一级";
								break;
							case 2:
								color = "#7EEA17";
								text = "二级";
								break;
							case 3:
								color = "#FF7C00";
								text = "三级";
								break;
							case 4:
								color = "#fF4100";
								text = "四级";
								break;
							case 5:
								color = "#FF0000";
								text = "五级";
								break;
						}
						var style = new ol.style.Style({
							image: new ol.style.Circle({
								radius: 8,
								fill: new ol.style.Fill({
									color: color
								}),
								stroke: new ol.style.Stroke({
									width: 1,
									color: "rgba(255,0,0,0.3)"
								})
							}),

							text: new ol.style.Text({
								text: radius.toString(),
								fill: new ol.style.Fill({
									color: '#fff'
								})
							})
						});
					}
					return style;
				}
			})
			this.map.addLayer(layer);
			return layer;
		}
	}
});