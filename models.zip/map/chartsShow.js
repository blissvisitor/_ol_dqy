define(["ol", "chartstyle", "echarts.min"], function (ol, chartStyle, echarts) {
	var animation = 0;
	var that = this;
	return {
		/**
	     * 矢量图层的监听事件返回的key值，用来取消该事件
	     */
		listenerKey: null,
	    /**
	     * 用来展示图标动画
	     * @param {ol.layer.Vector} vector 
	     * @returns {void} 
	     */
		 /**
		 * @api {类型 function} 用来展示空间统计图的动画 doAnimate
		 * @apiParam {Array} vector 空间统计图层
		 * @apiName doAnimate 
		 * @apiGroup chartsShow
		 */
		doAnimate: function (vector) {
			var that = this;
			if (this.listenerKey) return;
			var start = new Date().getTime();
			var duration = 1000;
			this.animation = 0;
			this.listenerKey = vector.on('precompose', function (event) {
				var frameState = event.frameState;
				var elapsed = frameState.time - start;
				if (elapsed > duration) {
					ol.Observable.unByKey(that.listenerKey);
					that.listenerKey = null;
					animation = false;
				} else {
					animation = ol.easing.easeOut(elapsed / duration);
					frameState.animate = true;
				}
				vector.changed();
			});
			vector.changed();
		},
	    /**
	     * 创建图标样式
	     * @param {ol.Feature()} feature 要素
	     * @param {} sel 分辨率
	     * @param {String} chartType 图表类型
	     * @param {String} chartColor 图标样式类型
	     * @returns {void} 
	     */
		/**
		 * @api {类型 function} 图层的样式函数 chartTypeStyle
		 * @apiParam {ol.Feature} feature 空间统计要素feature
		 * @apiSuccess (返回类型) {ol.style.Style} return 返回创建好的样式类型
		 * @apiName chartTypeStyle 
		 * @apiGroup chartsShow
		 */
		chartTypeStyle: function (feature, sel, chartColor) {
			if(feature.get("grades").indexOf("null")>-1){
				feature.get("grades").splice(feature.get("grades").indexOf("null"),1);
			}
			var grades = feature.get("grades");
			var colors = ['#ff0000', '#FFA500', '#ffff00', '#00ff00', '#00ffff', '#0000ff', '#800080', '#CD853F', '#FFE4E1'];
			var layColors = [];
			grades.sort(function(a,b){
				return a-b;
			});
			var layers = grades.map(function (val, index) {
				var grade = "";
				switch (val) {
					case "748":
						layColors.push(colors[0]);
						grade = "特别重大";
						break;
					case "749":
						layColors.push(colors[1]);
						grade = "重大";
						break;
					case "750":
						layColors.push(colors[2]);
						grade = "较大";
						break;
					case "751":
						layColors.push(colors[3]);
						grade = "一般";
						break;

					case "806":
						layColors.push(colors[0]);
						grade = "一级";
						break;
					case "807":
						layColors.push(colors[1]);
						grade = "二级";
						break;
					case "808":
						layColors.push(colors[2]);
						grade = "三级";
						break;
					case "809":
						layColors.push(colors[3]);
						grade = "四级";
						break;

					case "1067":
						layColors.push(colors[0]);
						grade = "重大隐患";
						break;
					case "1068":
						layColors.push(colors[1]);
						grade = "一般隐患";
						break;

					case "702":
						layColors.push(colors[0]);
						grade = "国家级";
						break;
					case "703":
						layColors.push(colors[1]);
						grade = "省部级";
						break;
					case "704":
						layColors.push(colors[2]);
						grade = "地市级";
						break;
					case "705":
						layColors.push(colors[3]);
						grade = "县级";
						break;
					case "706":
						layColors.push(colors[4]);
						grade = "基层";
						break;
					case "707":
						layColors.push(colors[5]);
						grade = "集团级";
						break;
					case "708":
						layColors.push(colors[6]);
						grade = "公司级";
						break;
					case "709":
						layColors.push(colors[7]);
						grade = "厂级";
						break;
					case "710":
						layColors.push(colors[8]);
						grade = "车间级";
						break;
						
					case "73":   //诚信企业
						layColors.push(colors[0]);
						grade = "A级";
						break;
					case "74":
						layColors.push(colors[1]);
						grade = "B级";
						break;
					case "75":
						layColors.push(colors[2]);
						grade = "C级";
						break;
					case "76":
						layColors.push(colors[3]);
						grade = "D级";
						break;
						
						
					case "0":   //职业病危害等级
						layColors.push(colors[0]);
						grade = "严重";
						break;
					case "1":
						layColors.push(colors[1]);
						grade = "较重";
						break;
					case "2":
						layColors.push(colors[2]);
						grade = "一般";
						break;
					case "3":
						layColors.push(colors[3]);
						grade = "未知";
						break;


					case "540":
						layColors.push(colors[0]);
						grade = "一级";
						break;
					case "541":
						layColors.push(colors[1]);
						grade = "二级";
						break;
					case "542":
						layColors.push(colors[2]);
						grade = "二级";
						break;
					case "543":
						layColors.push(colors[3]);
						grade = "已达标";
						break;
					case "544":
						layColors.push(colors[4]);
						grade = "未定级";
						break;
				}
				return grade;
			});
			var chartType;
			if ($("#themeticSelect option").length == 0) {
				chartType = "pie";
			} else {
				chartType = $("#themeticSelect option").filter(':selected')[2].value;
			}

			
			var total = parseFloat(feature.get("size")), basic;
			switch (true) {
				case total < 10:
					basic = 5;
					break;
				case total >= 10 && total < 100:
					basic = 8;
					break;
				case total >= 100 && total < 1000:
					basic = 11;
					break;
				case total >= 1000 && total < 10000:
					basic = 14;
					break;
				case total >= 10000 && total < 100000:
					basic = 17;
					break;
					case total >= 100000 && total < 1000000:
					basic = 21;
					break;
			}

			var style = null;
			if (!this.style) {
				//图标半径
				var radius = 15;
				if (chartType !== "bar1") {
					radius = basic + 0.07 * Math.sqrt(feature.get("size") / Math.PI);
				}
				style = new ol.style.Style(
					{
						image: new ol.style.Chart(
							{
								type: chartType,
								radius: (sel ? 1.2 : 1.4) * radius,
								offsetY: chartType == 'pie' ? 0 : (sel ? -1.2 : -1) * feature.get("radius"),
								data: feature.get("data") || [10, 30, 20],
								colors: layColors.length > 0 ? layColors : colors,
								rotateWithView: true,
								animation: animation,
								stroke: new ol.style.Stroke(
									{
										color: "#fff",
										width: 1
									})
							})
					});
			}
			style.getImage().setAnimation(animation);
			return style;
		},
		//用来返回各个图层等级对应的等级说明
		/**
		 * @api {类型 function} 图层的样式函数 getLayerNames
		 * @apiParam {Array} arr 图层的数组
		 * @apiSuccess (返回类型) {Object} return 图层等级和对应等级的颜色值
		 * @apiName getLayerNames 
		 * @apiGroup chartsShow
		 */
		getLayerNames: function (arr,layerName) {
			var colors = ['#ff0000', '#FFA500', '#ffff00', '#00ff00', '#00ffff', '#0000ff', '#800080', '#CD853F', '#FFE4E1'];
			var layColors = [],layers;
			if(layerName==="GEOM_RISK_POINT"){
				layers = arr.map(function (val, index) {
					var grade = "";
					switch (val) {
					case "0":
						layColors.push(colors[0]);
						grade = "低风险";
						break;
					case "1":
						layColors.push(colors[1]);
						grade = "一般风险";
						break;
					case "2":
						layColors.push(colors[2]);
						grade = "较大风险";
						break;
					case "3":
						layColors.push(colors[3]);
						grade = "重大风险";
						break;
					}
					return grade;
				});
			}else{
				layers = arr.map(function (val, index) {
					var grade = "";
					switch (val) {
					case "748":
							layColors.push(colors[0]);
							grade = "特别重大";
							break;
						case "749":
							layColors.push(colors[1]);
							grade = "重大";
							break;
						case "750":
							layColors.push(colors[2]);
							grade = "较大";
							break;
						case "751":
							layColors.push(colors[3]);
							grade = "一般";
							break;

						case "806":
							layColors.push(colors[0]);
							grade = "一级";
							break;
						case "807":
							layColors.push(colors[1]);
							grade = "二级";
							break;
						case "808":
							layColors.push(colors[2]);
							grade = "三级";
							break;
						case "809":
							layColors.push(colors[3]);
							grade = "四级";
							break;
							
						case "0":   //职业病危害等级
							layColors.push(colors[0]);
							grade = "严重";
							break;
						case "1":
							layColors.push(colors[1]);
							grade = "较重";
							break;
						case "2":
							layColors.push(colors[2]);
							grade = "一般";
							break;
						case "3":
							layColors.push(colors[3]);
							grade = "未知";
							break;

						case "1067":
							layColors.push(colors[0]);
							grade = "重大隐患";
							break;
						case "1068":
							layColors.push(colors[1]);
							grade = "一般隐患";
							break;

						case "702":
							layColors.push(colors[0]);
							grade = "国家级";
							break;
						case "703":
							layColors.push(colors[1]);
							grade = "省部级";
							break;
						case "704":
							layColors.push(colors[2]);
							grade = "地市级";
							break;
						case "705":
							layColors.push(colors[3]);
							grade = "县级";
							break;
						case "706":
							layColors.push(colors[4]);
							grade = "基层";
							break;
						case "707":
							layColors.push(colors[5]);
							grade = "集团级";
							break;
						case "708":
							layColors.push(colors[6]);
							grade = "公司级";
							break;
						case "709":
							layColors.push(colors[7]);
							grade = "厂级";
							break;
						case "710":
							layColors.push(colors[8]);
							grade = "车间级";
							break;

						case "73":   //诚信企业
							layColors.push(colors[0]);
							grade = "A级";
							break;
						case "74":
							layColors.push(colors[1]);
							grade = "B级";
							break;
						case "75":
							layColors.push(colors[2]);
							grade = "C级";
							break;
						case "76":
							layColors.push(colors[3]);
							grade = "D级";
							break;
							
							
						case "540":
							layColors.push(colors[0]);
							grade = "一级";
							break;
						case "541":
							layColors.push(colors[1]);
							grade = "二级";
							break;
						case "542":
							layColors.push(colors[2]);
							grade = "三级";
							break;
						case "543":
							layColors.push(colors[3]);
							grade = "已达标";
							break;
						case "544":
							layColors.push(colors[4]);
							grade = "未达标";
							break;
						default: layColors.push(colors[0]);
						//grade="统计个数";
					}
					return grade;
				});
			}
			
			return { layers: layers, layColors: layColors };
		},
		//点击地图的统计点，用echart显示出数据
		/**
		 * @api {类型 function} 图层的样式函数 echartsShow
		 * @apiParam {Array} data 图层的数组
		 * @apiParam {String} title echarts
		 * @apiParam {ol.Overlay} overlay 弹出对话框
		 * @apiParam {Array} grades 展示数据的等级数组
		 * @apiParam {Number} years 展示的年份
		 * @apiParam {String} layers 展示的图层名称
		 * @apiParam {String} city 城市名称
		 * @apiName echartsShow 
		 * @apiGroup chartsShow
		 */
		echartsShow: function (data, title, overlay, grades, years, layers, city) {
			var that = this;
			if(data.indexOf(0)>-1){
				data.splice(data.indexOf(0),1);
			}
			//var color=that.getLayerNames(grades).layColors;
			option = {

				title: {
					text: title,
					//subtext: '地级市企业个数统计'
				},
				tooltip: {
					trigger: 'axis'
				},
				legend: {
					data: ['数量']
				},
				toolbox: {
					show: true,
					feature: {
						mark: { show: true },
						magicType: { show: true, type: ['line', 'bar'] },
						saveAsImage: { show: true }
					}
				},
				calculable: true,
				xAxis: [
					{
						type: 'category',
						data: that.getLayerNames(grades,layers).layers
					}
				],
				yAxis: [
					{
						type: 'value'
					}
				],
				series: [
					{
						name: '统计数量',
						type: 'bar',
						itemStyle: {
							normal: {
								color: function (params) {
									// build a color map as your need.
									var colorList = that.getLayerNames(grades,layers).layColors;
									return colorList[params.dataIndex]
								}
							}
						},
						data: data,
						/* markPoint : {
							 data : [
								 {type : 'max', name: '最大值'},
								 {type : 'min', name: '最小值'}
							 ]
						 },*/
						markLine: {
							data: [
								{ type: 'average', name: '平均值' }
							]
						}
					}

				]
			};


			overlay.getElement().style.height = "250px";
			overlay.getElement().style.width = "350px";
			overlay.getElement().lastChild.style.height = "200px"
			overlay.getElement().lastChild.style.width = "330px";
			overlay.getElement().lastChild.style.bottom = "-18px";
			//echarts在初始化的时候需要已经创建好大小的DOM元素，如果没有初始化好dom对象，图表将不能正常显示
			var myChart = echarts.init(overlay.getElement().lastChild);
			//使用echart显示统计图表
			myChart.setOption(option);
			myChart.on('click', function (params) {
				if (params.name === "平均值") return;
				var names = that.getLayerNames(grades,layers).layers;
				var inx;
				names.map(function (val, index) {
					if (val === params.name) {
						inx = index;
					}
				});
				var url = "/main/mapStatisticsDetail/detailPage?xzqh=" + city + "&dj=" + grades[inx] + "&year=" + years + "&layer=" + layers;
				var murl = encodeURI(encodeURI(url));
				layer.open({
					type: 2,
					skin: "dome-layer",
					title: "详情列表",
					area: ["1300px", "530px"],
					fix: false, //不固定
					content: murl,
					btn: false,
					closeBtn: 1
				});
			});
		}
	}
});