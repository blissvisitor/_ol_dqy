/**
 * dqy 模拟分析 毒气泄漏 2017-11-30 10:48
 */
define(["ol","turf", "initMap", "mapTools", "text!fire.html"], function(ol,turf, mapContent, mapTools, poisonHtm) {
    var that = this;
    var Py, // 水平扩散系数
        Pz, // 垂直扩散系数
        x0,
        y0,
        Q, // 泄漏源连续泄漏速率kg/s
        Pi = Math.PI, //
        V1, // 平均风速，m/s
        V2, // 扩散速度，m/s
        result = [], // 结果
        A, // 与正东方向夹角
        T = 0; // 扩散时间
    var dis = 8;
    var diss = dis / 2;
    var xArr = []; // 最大值x
    var breaks = [100,180,300]
    var colorRamp =[ "#a70000", "#790000","#4e0000"];//轻度、中度、重度
    var cArr = [];
    var fireCoord; // 火灾点坐标
    var distanceArr = [50, 150, 300]; // 关注范围
    var geojson = {
        'type': 'FeatureCollection',
        'crs': {
            'type': 'name',
            'properties': {
                'name': 'EPSG:3857'
            }
        },
        'features': []
    };
    var drawTool;
    var gjFormat = new ol.format.GeoJSON();;
    var vectorLyr, analysisLyr;
    // 角度旋转
    function Rotate(coord, Angle) // Angle为正时逆时针转动, 单位为弧度
    {
        var Source = { X: coord[0], Y: coord[1] };
        var A, R;
        A = Math.atan2(Source.Y, Source.X) // atan2自带坐标系识别, 注意X,Y的顺序
        A += Angle // 旋转
        R = Math.sqrt(Source.X * Source.X + Source.Y * Source.Y) // 半径
        return [Math.cos(A) * R, Math.sin(A) * R];
    }
    // create a grid of points with random z-values in their properties
    // 分析
    function showResult() {
        if (result.length > 0) {
            var xL = 0;
            if (xArr.length > 0) {
                var max = Math.max.apply(Math, xArr);
                var min = Math.min.apply(Math, xArr);
                var P = 0.5;
                if (V1 > V2) {
                    P = P - (Math.random() / 2);
                } else {
                    // P = P + (Math.random() / 2);
                }
                xL = min + (max - min + 1) * P;
            }
            geojson.features = [];
            // 转为经纬度
            var pt = turf.point(fireCoord);
            var converted = turf.toMercator(pt).geometry.coordinates;;
            x0 = converted[0];
            y0 = converted[1];
            result.forEach(function(item, index) {
                var c = item.c;
                var coord = item.coord;
                var x = coord[0];
                var y = coord[1];
                var coord1 = [x - diss, y - diss];
                var newCoord1 = Rotate(coord1, Math.PI * A / 180);
                var coord2 = [x + diss, y - diss];
                var newCoord2 = Rotate(coord2, Math.PI * A / 180);
                var coord3 = [x + diss, y + diss];
                var newCoord3 = Rotate(coord3, Math.PI * A / 180);
                var coord4 = [x - diss, y + diss];
                var newCoord4 = Rotate(coord4, Math.PI * A / 180);

                var point1 = [x0 + newCoord1[0] - xL, y0 + newCoord1[1]];
                var point2 = [x0 + newCoord2[0] - xL, y0 + newCoord2[1]];
                var point3 = [x0 + newCoord3[0] - xL, y0 + newCoord3[1]];
                var point4 = [x0 + newCoord4[0] - xL, y0 + newCoord4[1]];
                geojson.features.push({
                    'type': 'Feature',
                    'geometry': {
                        'type': 'Polygon',
                        'coordinates': [
                            [
                                WgsToWeb(point1),
                                WgsToWeb(point2),
                                WgsToWeb(point3),
                                WgsToWeb(point4)
                            ]
                        ]
                    },
                    'properties': {
                        'nd': c
                    }
                });

            })
            var features = gjFormat.readFeatures(geojson);
            analysisLyr.getSource().clear();
            analysisLyr.getSource().addFeatures(features);
        }
    }

    function getPara() {
        if (!fireCoord) return;
        x0 = fireCoord[0];
        y0 = fireCoord[1];
        Q = $('#Q').val();
        V1 = $('#V1').val();
        V2 = $('#V2').val();
        A = $('#A').val();
        T = $('#T').val();
        if (!Q||Q<=0) {
            layer.msg('请输入火灾烟雾速率并且不能为负值！');
            return;
        }
        if (!T||T<=0) {
            layer.msg('请输入扩散时间并且不能为负值！');
            return;
        }
        if (!V1||V1<=0) {
            layer.msg('请输入平均风速并且不能为负值!');
            return;
        }
        if (!V2||V2<=0) {
            layer.msg('请输入扩散速度并且不能为负值!');
            return;
        }
        if (A > 360 || A < 0) {
            layer.msg('角度为0~360！');
            return;
        }
        Q = parseFloat(Q);
        V1 = parseFloat(V1);
        V2 = parseFloat(V2);
        A = parseFloat(A);
        T = parseFloat(T)*60;
        var Pasquill = $('#pasquill').val();
        var xMax = (V1 + V2) * T;
        var xMin = (V1 - V2) * T;

        geojson.features = [];
        result = [];
        xArr = [];

        for (var i = 1; i <= 800; i += dis) {
            x = i;
            switch (Pasquill) {
                case 'A':
                    Py = 0.22 * x / Math.sqrt(1 + 0.0001 * x);
                    Pz = 0.2 * x;
                    if (x < 0) {
                        Py = 1;
                        Pz = 1;
                    }
                    if (x > 0) {
                        Py = 0.425809 * Math.pow(x, 0.901074);
                    } else
                    if (x > 1000) {
                        Py = 0.602052 * Math.pow(x, 0.850934);
                    }
                    if (x > 0) {
                        Pz = 0.079990 * Math.pow(x, 1.121540);
                    } else

                    if (x > 300 && x <= 500) {
                        Pz = 0.008574 * Math.pow(x, 1.523600);
                    } else if (x > 500) {
                        Pz = 0.000211 * Math.pow(x, 2.108810);
                    }
                    break;
                case 'B':
                    Py = 0.16 * x / Math.sqrt(1 + 0.0001 * x);
                    Pz = 0.12 * x;
                    Py = 0.281846 * Math.pow(x, 0.914370);
                    if (x > 1000) {
                        Py = 0.396353 * Math.pow(x, 0.865014);
                    }
                    Pz = 0.127190 * Math.pow(x, 0.964435);
                    if (x > 500) {
                        Pz = 0.057025* Math.pow(x, 1.093560);
                    }
                    break;
                case 'C':
                    Py = 0.11 * x / Math.sqrt(1 + 0.0001 * x);
                    Pz = 0.08 * x / Math.sqrt(1 + 0.0015 * x);
                    Py = 0.177154 * Math.pow(x, 0.924279);
                    if (x > 1000) {
                        Py = 0.232123 * Math.pow(x, 0.885175);
                    }
                    if (x > 0) {
                        Pz = 0.106803 * Math.pow(x, 0.917595);
                    }
                    break;
                case 'D':
                    Py = 0.08 * x / Math.sqrt(1 + 0.0001 * x);
                    Pz = 0.06 * x / Math.sqrt(1 + 0.0015 * x);
                    Py = 0.110726 * Math.pow(x, 0.924418);
                    if (x > 1000) {
                        Py = 0.146669 * Math.pow(x, 0.888723);
                    }
                    if (x > 0 && x <= 1000) {
                        Pz = 0.104634* Math.pow(x,0.826212);
                    } else if (x > 1000 && x <= 10000) {
                        Pz = 0.400167 * Math.pow(x, 0.632023);
                    } else if (x > 10000) {
                        Pz = 0.810763 * Math.pow(x, 0.555360);
                    }
                    break;
                case 'E':
                    Py = 0.06 * x / Math.sqrt(1 + 0.0001 * x);
                    Pz = 0.03 * x / Math.sqrt(1 + 0.0003 * x);
                    Py = 0.086400* Math.pow(x, 0.920818 );
                    if (x > 1000) {
                        Py = 0.101947* Math.pow(x, 0.896864 );
                    }
                    if (x > 0 && x <= 1000) {
                        Pz = 0.788370 * Math.pow(x, 0.092752);
                    } else if (x > 1000 && x <= 10000) {
                        Pz = 0.433384 * Math.pow(x, 0.565188);
                    } else if (x > 10000) {
                        Pz = 1.732410 * Math.pow(x,0.414743 );
                    }
                    break;
                case 'F':
                    Py = 0.04 * x / Math.sqrt(1 + 0.0001 * x);
                    Pz = 0.016 * x / Math.sqrt(1 + 0.0003 * x);
                    Py = 0.055363* Math.pow(x, 0.929418 );
                    if (x > 1000) {
                        Py = 0.073334* Math.pow(x, 0.888723 );
                    }
                    if (x > 0 && x <= 1000) {
                        Pz = 0.062076 * Math.pow(x,0.784400 );
                    } else if (x > 1000 && x <= 10000) {
                        Pz = 0.370015 * Math.pow(x, 0.525960);
                    } else if (x > 10000) {
                        Pz = 2.406910 * Math.pow(x,0.322659 );
                    }
                    break;
            }
            for (var m = -500; m <= 500; m += dis) {
                y = m;
                var k;
                k = (90 - Math.acos(x / Math.sqrt(x * x + y * y)) * 180 /
                    Math.PI) / 90;
                // k = x / Math.sqrt(x * x + y * y);
                var V = k * V1 + V2;
                var c = 0;
                if (V >= 0) {
                    var t1 = Math.sqrt(x * x + y * y) / V;
                    if (T >= t1) {
                        for (var n = t1; n <= T; n += 0.1) {
                            var c1 = Q * Math.exp(-Math.pow((x - V * T) / (2 * Py * Py), 2)) * Math.exp(-y * y / (2 * Py * Py)) / (Math.pow((2 * Math.PI), 3 / 2) * Py * Py * Pz);
                            c += c1;
                        }
                        c = c * 1000;


                        if (c > 0) {
                            var xL = 0;
                            if (c >= 300) {
                                xArr.push(x);
                            }
                            result.push({ 'c': c, 'coord': [x, y] });
                        }

                    } else {}
                }

            }

            showResult();
        }
    }
    // 转换
    function WgsToWeb(coord) {
        return turf.toWgs84(turf.point(coord)).geometry.coordinates;
    }
    // 绘制火灾点
    function drawPosition() {
        // body...
        fireCoord = null;
        // 清空图层
        analysisLyr.getSource().clear();
        vectorLyr.getSource().clear();
        if (drawTool) return;
        drawTool = new ol.interaction.Draw({
            source: vectorLyr.getSource(),
            type: 'Point',
            style:new ol.style.Style({
            	image:new ol.style.Icon({
            		src:"/main/resources/image/map/fire.png",
            		anchor:[0.5,1]
            	})
            })
        });
        mapContent.map.addInteraction(drawTool);
        drawTool.on('drawend', function(e) {
            // body...
            mapContent.map.removeInteraction(drawTool);
            drawTool = null;
            centerPoint = e.feature;
            fireCoord = e.feature.getGeometry().getCoordinates();
            var overlayEle=document.createElement("img");
            overlayEle.src="/main/resources/image/map/1.gif";
            var overlay=new ol.Overlay({
            	element:overlayEle,
            	position:fireCoord,
            	offset:[-20,-20]
            })
            mapContent.map.addOverlay(overlay);
            // 添加关注范围
            var distanceF = [];
            for (var i = 0; i < distanceArr.length; i++) {
                var r = distanceArr[i] / (2 * Math.PI * 6378137.0) * 360;
                var bufferCircle = new ol.geom.Circle(fireCoord, r, 'XY');
                var polygon = ol.geom.Polygon.fromCircle(bufferCircle);
                bufferCircle = new ol.Feature(bufferCircle);
                bufferCircle.setStyle(new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        color: 'red',
                        width: 1
                    })
                }));
                var label = new ol.Feature({
                    geometry: new ol.geom.Point(polygon.getFirstCoordinate()),
                    zIndex: 100
                })
                label.setStyle(new ol.style.Style({
                    text: new ol.style.Text({
                        font: '14px 微软雅黑',
                        fill: new ol.style.Fill({ color: 'black' }),
                        fill: new ol.style.Fill({ color: '#075db3' }),
                        // text: tempR+'米，浓度范围'+S*Per[i],
                        text: distanceArr[i] + 'm',
                        rotation: 0,
                        offsetY: 15,
                        // textAlign: 'line'
                        textBaseline: 'bottom'
                    })
                }));
                distanceF.push(bufferCircle);
                distanceF.push(label);
            }
            vectorLyr.getSource().addFeatures(distanceF);
            mapContent.map.getView().fit(distanceF[distanceF.length - 2].getGeometry(), mapContent.map.getSize());
        });
    }

    // 初始化本模块
    var init = function() {
        vectorLyr = new ol.layer.Vector({
            source: new ol.source.Vector(),
            /*style: function(feature, res) {
                return new ol.style.Style({
                    image: new ol.style.Icon({
                        anchor: [0.5, 0.5],
                        size: [32, 32],
                        src: document.getElementById('fire').src
                    })
                })
            },*/
            style:new ol.style.Style({
            	image:new ol.style.Circle({
            		radius:2,
            		fill:new ol.style.Fill({
            			color:"rgba(0,0,0,0)"
            		})
            	})
            }),
            zIndex: 90
        });
        analysisLyr = new ol.layer.Vector({
            source: new ol.source.Vector(),
            style: function(feature, res) {
                var fillColor = '';
                var nd = feature.getProperties().nd;
                fillColor = 'rgba(255,0,0,0)';
                for (var i = 0; i < breaks.length; i++) { 
                    
                    if (i == 0) {
                        if (nd < breaks[i+1] && nd >= breaks[i]) {
                            fillColor = colorRamp[i];
                        }
                    } else if (i == breaks.length - 1) {
                        if (nd >= breaks[i]) {
                            fillColor = colorRamp[i];
                        } 
                    } else {
                        if (nd < breaks[i+1] && nd >= breaks[i]) {
                            fillColor = colorRamp[i];
                        }
                    }
                }
                // fillColor = '#F6C171';
                return new ol.style.Style({
                    fill: new ol.style.Fill({ color: fillColor }),
                    stroke: new ol.style.Stroke({ color: 'rgba(255,0,0,0)', width: 1 })
                    // image: new ol.style.RegularShape({
                    // fill: new ol.style.Fill({ color: fillColor }),
                    // stroke: new ol.style.Stroke({ color: 'black', width: 1
                    // }),
                    // points: 4,
                    // radius: 5,
                    // angle: Math.PI / 4
                    // })
                });
            },
            zIndex: 80

        });
        mapContent.map.addLayer(analysisLyr);
        mapContent.map.addLayer(vectorLyr);
        // 展开面板
        // todo
        $('.fundo').show();
        $('.fundo').html(poisonHtm);
        $('#drawPosition').click(function() {
            drawPosition();
        });
        $('#fireAnalysis').click(function() {
        	
        	layer.msg("正在分析请您稍等！");
            setTimeout(getPara,1000);
        });
    };
    // 销毁本模块
    var destroy = function() {
        if (vectorLyr) {
            mapContent.map.removeLayer(vectorLyr);
            vectorLyr = null;
        }
        if (analysisLyr) {
            mapContent.map.removeLayer(analysisLyr);
            analysisLyr = null;
        }
        if (drawTool) {
            mapContent.map.removeInteraction(drawTool);
            drawTool = null;
        }
        $('.fundo').hide();
        $('.fundo').html('');
    };
    var content = {
        init: init,
        destroy: destroy
    };
    return content;
})