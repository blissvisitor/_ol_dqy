define(function(){

	//图层搜索对应接口
	var searchLy={
			//GEOM_QYJCXX:"service=WFS&version=1.1.0&REQUEST=GetFeature&maxFeatures=30&outputFormat=GML3&typename=",//企业
			GEOM_WXYHZB:"/main/zdwxySqManage/searchGeomWxyhzbForMap",//重大危险源
			GEOM_SGBS:"/main/accidentreprot/iSearchSg",//事故
			GEOM_Danger_Report:"/main/danger/searchDanger",//隐患排查
			GEOM_DYJYA_BASQB:"/main/yjyabasqbManager/searchGeomDyjyaBasqbForMap",//应急预案
			GEOM_STANDARD:"/main/unifyStandard/searchGeomQyjcxxOfStandardForMap",//标准化
			GEOM_YJYA_YJWZ:"/main/yjzyManager/keyjywzDataMapOpen",//应急物资
			GEOM_YJZY_YJJYDW:"/main/yjzyManager/keyjydwDataMapOpen",//应急队伍
			GEOM_YJZY_YJJYZB:"/main/yjzyManager/keyjyzbDataMapOpen",//救援装备
			GEOM_LAWINFO_PLAN:"/main/zfjc/iSearchLiAnLike",//执法监察
			GEOM_HON_CHMAIN:"/main/appli/getChengxinCompanySearchData",//诚信企业
			GEOM_ZYBWH:"/main/zyjkManager/getZybwhCompanySearchData",//职业病危害
			GEOM_FIREWORKS:"/main/firework/iSearchFire",//烟花爆竹
			GEOM_SUPERVISION:"/main/superVisionPlan/getJgjcSearchDataGeom",//监管监察
			GEOM_EMERG_RESPONSE:"/main/yjxy/searchGeomEmergResponseForMap",//应急响应
			GEOM_ZJJG:"/main/zjjgManager/keyZjjgMapOpen",//中介机构
			GEOM_REGULATION_SUBJECT:"",//监管主题
			GEOM_SPECIAL:"/main/superVisionPlan/getZxjcSearchDataGeom",//专项检查
			GEOM_WKK:"/main/wkk/iSearchWkk",//尾矿库
			GEOM_RISK_POINT:"/main/riskPoint/iSearchFxdLike",//风险点
			GEOM_VB_TARGET:"/main/vulnerbilityTarget/iSearchVbTargetLike",//脆弱性目标
			GEOM_WXYQY:"/main/zdwxySqManage/searchQyJcxxFromGeomWxyhzbForMap"//危险源企业
			//GEOM_KSK:""//矿山库
	}


	//搜索不同图层时，提示搜索什么信息
	var placeholderLy={
		GEOM_QYJCXX:"请输入企业名称",//企业
		GEOM_WXYHZB:"请输入重大危险源名称",//重大危险源
		GEOM_SGBS:"请输入事故标题",//事故
		GEOM_Danger_Report:"请输入隐患名称",//隐患排查
		GEOM_DYJYA_BASQB:"请输入企业名称",//应急预案
		GEOM_STANDARD:"请输入企业名称",//标准化
		GEOM_YJYA_YJWZ:"请输入物资名称",//应急物资
		GEOM_YJZY_YJJYDW:"请输入救护队名称",//应急队伍
		GEOM_YJZY_YJJYZB:"请输入装备名称",//救援装备
		GEOM_LAWINFO_PLAN:"请输入立案名称",//执法监察
		GEOM_HON_CHMAIN:"请输入企业名称",//诚信企业
		GEOM_ZYBWH:"请输入企业名称",//职业病危害
		GEOM_FIREWORKS:"请输入销售点名称",//烟花爆竹
		GEOM_SUPERVISION:"监管监察",//监管监察
		GEOM_EMERG_RESPONSE:"请输入事故标题",//应急响应
		GEOM_ZJJG:"请输入机构名称",//中介机构
		GEOM_WKK:"请输入尾矿库名称",//尾矿库
		GEOM_RISK_POINT:"请输入风险点名称",//风险点
		GEOM_VB_TARGET:"请输入脆弱性目标名称",//脆弱性目标
			GEOM_WXYQY:"请输入企业名称"//危险源企业
		//GEOM_KSK:""//矿山库
}


	//概要信息接口
	var infoLy={
		//GEOM_QYJCXX:"",//企业
		GEOM_WXYHZB:"/main/zdwxySqManage/searchWxyAbstractForMap",//重大危险源
		GEOM_SGBS:"/main/accidentreprot/iSearchSgMsg",//事故
		GEOM_Danger_Report:"/main/danger/searchDangerGeneral",//隐患排查
		GEOM_DYJYA_BASQB:"/main/yjyabasqbManager/searchGeomDyjyaBasqbAbstractForMap",//应急预案
		GEOM_STANDARD:"/main/unifyStandard/searchStandardAbstractForMap",//标准化
		GEOM_YJYA_YJWZ:"/main/yjzyManager/gyxxjywzDataMapOpen",//应急物资
		GEOM_YJZY_YJJYDW:"/main/yjzyManager/gyxxjydwDataMapOpen",//应急队伍
		GEOM_YJZY_YJJYZB:"/main/yjzyManager/gyxxjyzbDataMapOpen",//救援装备
		GEOM_LAWINFO_PLAN:"/main/zfjc/iSearchLiAn",//执法监察
		GEOM_HON_CHMAIN:"/main/appli/getChengxinCompanyDetailData",//诚信企业
		GEOM_ZYBWH:"/main/zyjkManager/getZybwhCompanyDetailData",//职业病危害
		GEOM_FIREWORKS:"/main/firework/iSearchGyMsg",//烟花爆竹
		GEOM_SUPERVISION:"/main/superVisionPlan/getJgjcDataByIdGeom",//监管监察
		GEOM_EMERG_RESPONSE:"/main/yjxy/searchEmergResponseAbstractForMap",//应急响应
		GEOM_ZJJG:"/main/zjjgManager/gyxxZjjgMapOpen",//中介机构
		GEOM_SPECIAL:"/main/superVisionPlan/getZxjcDataByIdGeom",//专项检查
		GEOM_WKK:"/main/wkk/iSearchGyMsg",//尾矿库
		GEOM_RISK_POINT:"/main/riskPoint/iSearchFxd",//风险点
		GEOM_VB_TARGET:"/main/vulnerbilityTarget/iSearchVbTarget"//脆弱性目标
		//GEOM_KSK:""//矿山库
}

     //不同图层统计颜色配置
	var lyColor={
		GEOM_QYJCXX:"6,106,205",//企业
		GEOM_WXYHZB:"182,12,12",//重大危险源
		GEOM_SGBS:"222,54,54",//事故
		GEOM_Danger_Report:"251,120,24",//隐患排查
		GEOM_DYJYA_BASQB:"46,123,227",//应急预案
		GEOM_STANDARD:"0,172,16",//标准化
		GEOM_YJYA_YJWZ:"63,153,215",//应急物资
		GEOM_YJZY_YJJYDW:"249,164,42",//应急队伍
		GEOM_YJZY_YJJYZB:"233,150,19",//救援装备
		GEOM_LAWINFO_PLAN:"51,104,239",//执法监察
		GEOM_HON_CHMAIN:"56,196,59",//诚信企业
		GEOM_ZYBWH:"25,164,84",//职业病危害
		GEOM_FIREWORKS:"197,47,47",//烟花爆竹
		GEOM_SUPERVISION:"7,190,184",//监管监察
		GEOM_EMERG_RESPONSE:"196,58,194",//应急响应
		GEOM_ZJJG:"158,43,248",//中介机构
		GEOM_REGULATION_SUBJECT:"8,151,204",//监管主题
		GEOM_SPECIAL:"72,173,220",//专项检查
		GEOM_WKK:"107,72,220",//尾矿库
		GEOM_KSK:"143,0,0"//矿山库
}
	
	
	   //不同图层是否具有行业类别的过滤条件
	var lyHylb={
		GEOM_QYJCXX:true,//企业
		GEOM_WXYHZB:true,//重大危险源
		GEOM_SGBS:true,//事故
		GEOM_Danger_Report:true,//隐患排查
		GEOM_DYJYA_BASQB:true,//应急预案
		GEOM_STANDARD:true,//标准化
		GEOM_YJYA_YJWZ:true,//应急物资
		GEOM_YJZY_YJJYDW:true,//应急队伍
		GEOM_YJZY_YJJYZB:true,//救援装备
		GEOM_LAWINFO_PLAN:true,//执法监察
		GEOM_HON_CHMAIN:true,//诚信企业
		GEOM_ZYBWH:true,//职业病危害
		GEOM_FIREWORKS:true,//烟花爆竹
		GEOM_SUPERVISION:true,//监管监察
		GEOM_EMERG_RESPONSE:true,//应急响应
		GEOM_ZJJG:false,//中介机构
		GEOM_REGULATION_SUBJECT:true,//监管主题
		GEOM_SPECIAL:true,//专项检查
		GEOM_WKK:true,//尾矿库
		GEOM_KSK:true,//矿山库
		GEOM_RISK_POINT:true,//风险点
		GEOM_VB_TARGET:true,//脆弱性目标
		GEOM_WXYQY:true
}
	
	//不同图层是否具有监管类型的过滤条件
	var lyJg={
			GEOM_QYJCXX:true,//企业
			GEOM_WXYHZB:false,//重大危险源
			GEOM_SGBS:false,//事故
			GEOM_Danger_Report:false,//隐患排查
			GEOM_DYJYA_BASQB:false,//应急预案
			GEOM_STANDARD:true,//标准化
			GEOM_YJYA_YJWZ:false,//应急物资
			GEOM_YJZY_YJJYDW:false,//应急队伍
			GEOM_YJZY_YJJYZB:false,//救援装备
			GEOM_LAWINFO_PLAN:false,//执法监察
			GEOM_HON_CHMAIN:false,//诚信企业
			GEOM_ZYBWH:true,//职业病危害
			GEOM_FIREWORKS:false,//烟花爆竹
			GEOM_SUPERVISION:false,//监管监察
			GEOM_EMERG_RESPONSE:false,//应急响应
			GEOM_ZJJG:false,//中介机构
			//GEOM_REGULATION_SUBJECT:"8,151,204",//监管主题
			GEOM_SPECIAL:false,//专项检查
			GEOM_WKK:false,//尾矿库
			GEOM_RISK_POINT:false,//风险点
			GEOM_VB_TARGET:false,//脆弱性目标
			GEOM_WXYQY:false//危险源企业
			//GEOM_KSK:"143,0,0"//矿山库
	}
	
	
	
	
	return{
		searchLy:searchLy,
		lyColor:lyColor,
		infoLy:infoLy,
		placeholderLy:placeholderLy,
		lyHylb:lyHylb,
		lyJg:lyJg,
		emergencyId:null
	}
})