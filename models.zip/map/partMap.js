require(["ol", "mapTools", "mapConfig"], function (ol, mapTools, mapConfig) {



	function getCountyData(layerName) {

		var format = new ol.format.WKT();
		themeMap.getSource().clear();
		//$.post("/main/onemap/DiffrentLevel",{xzqhLevel:"2",tb:layerName},function(data){
		$.post("/main/onemap/DiffrentLevel", { xzqhLevel: "2", tb: layerName, isapp: $("#isapp").val(), usernum: $("#usernum").val(), areaId: $("#areaId").val(), industyIds: $("#industyIds").val() }, function (data) {
			var features = [];
			for (var i = 0, z = data.length; i < z; i++) {
				var feature = format.readFeature(data[i].point);
				feature.set("city", data[i].city);
				feature.set("layerName", layerName);
				feature.setStyle(mapTools.setStyle(parseInt(data[i].count), layerName));
				features.push(feature);
			}
			themeMap.getSource().clear();
			themeMap.getSource().addFeatures(features);
		});
	};


	function IsPC() {
		var userAgentInfo = navigator.userAgent;
		var Agents = ["Android", "iPhone",
			"SymbianOS", "Windows Phone",
			"iPad", "iPod"];
		var flag = true;
		for (var v = 0; v < Agents.length; v++) {
			if (userAgentInfo.indexOf(Agents[v]) > 0) {
				flag = false;
				break;
			}
		}
		return flag;
	}
	


	//河北省界图层
	var hbsjLayer = new ol.layer.Tile({
		minResolution: 0.0013766455078125,
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "HBSJ/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=HBSJ&STYLE=HBSJ&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	//矢量地图
	var sl_dtLayer = new ol.layer.Tile({
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "sl_dt/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_dt&STYLE=sl_dt&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	//矢量地图标注
	var sl_zjLayer = new ol.layer.Tile({
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "sl_zj/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_zj&STYLE=sl_zj&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});

	var cameraLayer = new ol.layer.Image({
		visible: false,
		source: new ol.source.ImageWMS({
			crossOrigin: "anonymous",
			ratio: 1,
			url: mapConfig.hebeiBordr,
			params: {
				'FORMAT': "image/png",
				'VERSION': '1.1.1',
				LAYERS: 'HBAJ:TBCAMERA',
				cql_filter:"ISENABLE in(1)"
			}
		}),
		id: "cameraLayer"
	});

	var view = new ol.View({
		zoom: 7,
		center: [115.80688, 39.67163],
		projection: "EPSG:4326"
	});
	var map = new ol.Map({
		target: "map",
		layers: [sl_dtLayer, hbsjLayer, sl_zjLayer, cameraLayer],
		view: view,
		logo: false
	});
	
	
	//雄安新区的边界
	var XIONGAN = new ol.layer.Image({
		minResolution: 0.001373291015625,
        source: new ol.source.ImageWMS({
          ratio: 1,
          url: mapConfig.hebeiBordr,
          params: {'FORMAT': "image/png",
                   'VERSION': '1.1.1',  
                STYLES: '',
                LAYERS: 'HBAJ:XIONGAN',
          }
        })
      });
	map.addLayer(XIONGAN);

	
	 var XIONGANPOINT = new ol.layer.Image({
		 minResolution: 0.001373291015625,
	        source: new ol.source.ImageWMS({
	          ratio: 1,
	          url: mapConfig.hebeiBordr,
	          params: {'FORMAT': "image/png",
	                   'VERSION': '1.1.1',  
	                STYLES: '',
	                LAYERS: 'HBAJ:xionganPoint',
	          }
	        })
	      });
	 map.addLayer(XIONGANPOINT);
	 
	//辛集市和定州市边界图层
	 var citys = new ol.layer.Image({
			visible: true,
			source: new ol.source.ImageWMS({
				crossOrigin: "anonymous",
				ratio: 1,
				url: mapConfig.hebeiBordr,
				params: {
					'FORMAT': "image/png",
					'VERSION': '1.1.1',
					STYLES: '',
					LAYERS: 'HBAJ:XINJI',
				}
			})
		});
	
	 map.addLayer(citys);
	
	$.post("/main/onemap/getCenterPoint", function (data) {
		if (data !== "") {
			var format = new ol.format.WKT();
			var splitData=data.split('#');
			view.setCenter(format.readFeature(splitData[0]).getGeometry().getCoordinates());
			view.setZoom(8);
		}
	});


	view.on("change:resolution", function (evt) {
		var resolution = map.getView().getResolution();
		var ly = "GEOM_QYJCXX";
		$("#mapThemeType :button").each(function () {
			if ($(this).css("backgroundColor").indexOf("rgb(240, 240, 240)") > -1) {
				ly = $(this).attr("ly");
			}
		});
		if (ly === "") {
			return;
		}
		if (view.getZoom() > 8) {
			getCountyData(ly);
		} else {
			showData(ly);
		}

	});
	
	

	$("#cameraBtn").click(function () {
		if ($(this).attr("class").indexOf("icon1_camera") > -1) {
			$(this).removeClass("icon1_camera").addClass("icon2_camera");
			cameraLayer.setVisible(true);
			cameraKey = map.on("singleclick", function (evt) {
				var url = cameraLayer.getSource().getGetFeatureInfoUrl(evt.coordinate, view.getResolution(), view.getProjection(),
					{
						'INFO_FORMAT': 'application/json',
						'FEATURE_COUNT': 1
					});
				$.get(url, function (data) {
					if (data.features.length === 0) {
						return;
					}
					var id = data.features[0].id.split(".")[1];
					if (id == null) {
						layer.msg("无效的id码");
						return;
					}
					if (IsPC()) {
						//initMap.panToPoint2(data.features[0].geometry.coordinates);
						map.getView().setCenter(evt.coordinate);
						map.getView().setZoom(12);
					/*	layer.open({
							type: 2,
							skin: "dome-layer",
							title: "视频",
							area: ["330px", "300px"],
							fix: false, //不固定
							content: "/main/tbcamera/camerainfo?id=" + id,
							btn: false,
							closeBtn: 1
						});*/
						
						if(data.features[0].properties.TYPE==="1"){
							layer.open({
								type: 2,
								skin: "dome-layer",
								title: "视频",
								area: ["500px", "500px"],
								fix: false, //不固定
								content: "/main/tbcamera/camerainfo?id=" + id,
								btn: false,
								closeBtn: 1
							});
						}else{
							layer.open({
								type:2,
								skin:"dome-layer",
								title:"监控列表",
								content:"/main/tbcamera/toCamerasPage?qyid="+ data.features[0].properties.QYOPGUID,
								closeBtn:1,
								area:["500px", "500px"]
							})
						}
						
						
					} else {
						/*if(data.features[0].properties.TYPE==="1"){
							Android.watch("ezopen://open.ys7.com/" + data.features[0].properties.SERIALNUMBER + "/1.hd.live");
						}else{*/
							Android.getCompanyCameras(data.features[0].properties.QYOPGUID);
						//}
						
					}



				});

			});
		} else {
			map.unByKey(cameraKey);
			$(this).removeClass("icon2_camera").addClass("icon1_camera");
			cameraLayer.setVisible(false);

		}
	});




	var mousePosition = new ol.control.MousePosition({
		coordinateFormat: ol.coordinate.createStringXY(5),
		projection: 'EPSG:4326',
		className: "ol-mouse-position2"
	});

	map.addControl(mousePosition);



	var themeMap = new ol.layer.Vector({
		source: new ol.source.Vector(),
		id: "themeMap"
	});



	map.addLayer(themeMap);


	function setStyle(count) {
		var circleStyle = new ol.style.Style({
			image: new ol.style.Circle({
				stroke: new ol.style.Stroke({
					color: "#fff"
				}),
				radius: 16,
				fill: new ol.style.Fill({
					color: "#0066cc"
				})
			}),
			text: new ol.style.Text({
				font: "5px 微软雅黑",
				fill: new ol.style.Fill({
					color: "#fff"
				}),
				text: count.toString()
			})
		});
		return circleStyle;
	}

	var format = new ol.format.WKT();

	//保存被点击图层的名称
	var selectLayer = "";
	//用来显示专题图
	function showData(layerName) {
		selectLayer = layerName;
		themeMap.getSource().clear();
		$.post("/main/onemap/DiffrentLevel", { xzqhLevel: "1", tb: layerName, isapp: $("#isapp").val(), usernum: $("#usernum").val(), areaId: $("#areaId").val(), industyIds: $("#industyIds").val() }, function (data) {
			var features = [];
			for (var i = 0, z = data.length; i < z; i++) {
				var feature = format.readFeature(data[i].point);
				feature.set("city", data[i].city);
				feature.setStyle(mapTools.setStyle(parseInt(data[i].count), layerName));
				features.push(feature);
			}
			themeMap.getSource().clear();
			themeMap.getSource().addFeatures(features);
		});
	}



	//点击图层列表的时候按地级市统计相应企业个数
	var layerText = "";
	$(".zt-con li").click(function () {
		$(this).css("background-color", "#f0f0f0").siblings().css("background-color", "#ffffff");
		var text = $(this).attr("ly");
		if (text === undefined) {
			return;
		}
		if (layerText !== text) {
			showData(text)
		}
		layerText = text;
	});


	//初始化时展示，企业点统计
	$.post("/main/onemap/DiffrentLevel", { xzqhLevel: "1",tb: mapConfig.qyTbName, isapp: $("#isapp").val(), usernum: $("#usernum").val(), areaId: $("#areaId").val(), industyIds: $("#industyIds").val() }, function (data) {
		var features = [];
		for (var i = 0, z = data.length; i < z; i++) {
			var feature = format.readFeature(data[i].point);
			feature.set("city", data[i].city);
			feature.setStyle(mapTools.setStyle(parseInt(data[i].count), mapConfig.qyTbName));
			features.push(feature);
		}
		themeMap.getSource().addFeatures(features);
	});



	$("#showfull").click(function () {
		var url = '/main/onemap/map?layer=' + layerText;
		window.parent.parent.commonAddTabs("一张图", url);
	});

	$(".fuwei").click(function () {
		var animation = new ol.animation.pan({
			source: map.getView().getCenter(),
			duration: 1000
		});
		map.beforeRender(animation);
		map.getView().setCenter([115.80688, 39.67163]);
		map.getView().setZoom(7);
	});
	
	
	$(document).ready(function(){
		var btns=$(".ztphoto ul li").length;
		var height=(btns-9)*28-22;
		if(btns>10){
			var currentPosition=22;
			$("#firstBtn").click(function(){
				if(currentPosition>=0){
					$(this).find("img").attr("src","/main/resources/image/map/2.png");
					return;
				}
				if($("#lastBtn img").attr("src").indexOf("1.png")>-1){
					$("#lastBtn img").attr("src","/main/resources/image/map/3.png");
				}
				currentPosition+=28;
				$(".ztphoto ul").css("top",currentPosition+"px");
		    });
            $("#lastBtn").click(function(){
            	if(currentPosition<=-height){
            		$(this).find("img").attr("src","/main/resources/image/map/1.png");
            		return;
            	}
            	if($("#firstBtn img").attr("src").indexOf("2.png")>-1){
					$("#firstBtn img").attr("src","/main/resources/image/map/4.png");
				}
            	currentPosition-=28;
				$(".ztphoto ul").css("top",currentPosition);
		    });
		}
	});

	//如果天地图在更新维护就进行提示
	$.get("/tdt/dmdz/geocoding?output=json&request=GetCapabilities&service=GeoCoding&version=1.0.0").fail(function(e){
		$(".hint").css("display","block");
		$(".hint").addClass("am-animation-slide-left");
	});
      
	window.goToPoistion=function(id){
		$.post("/main/onemap/getQyPosition",{id:id}).done(function(data){
			var obj = data.split("#");
			map.getView().setCenter(obj);
			map.getView().setZoom(12);
			var ele=document.createElement("div");
			var image=document.createElement("img");
			image.src="/main/resources/image/map/Point.png";
			ele.appendChild(image);
			map.getOverlays().clear();
			var overlay=new ol.Overlay({
				element:ele,
				positioning:"center-center",
				position:obj,
				offset:[0,-17.5]
			});
			
		    
			map.addOverlay(overlay);
			overlay.getElement().className="bounce";
		})
	}
	  
});