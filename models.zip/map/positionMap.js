require(["mapTools", "ol", "mapConfig"], function (mapTools, ol, mapConfig) {
	if (window.location.href.split("userType=")[1] != "1") {
		$("#showfull").css("display", "block");
	}
	
	function IsPC() {
		var userAgentInfo = navigator.userAgent;
		var Agents = ["Android", "iPhone",
			"SymbianOS", "Windows Phone",
			"iPad", "iPod"];
		var flag = true;
		for (var v = 0; v < Agents.length; v++) {
			if (userAgentInfo.indexOf(Agents[v]) > -1) {
				flag = false;
				break;
			}
		}
		return flag;
	}
	if(!IsPC()){
		$("#navigator").css("display","block");
	}
	
	//天地图街道地图
	var streetLayer = new ol.layer.Tile({
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + "sl_dt/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_dt&STYLE=sl_dt&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile"
		})
	});
	//天地图注记图层
	var streetAnnotationLayer = new ol.layer.Tile({
		//visible:false,
		preload: 0,
		useInterimTilesOnError: false,
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + 'sl_zj/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=sl_zj&STYLE=sl_zj&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
		})
	});


	var boundaryLayer = new ol.layer.Tile({
		title: "河北省边界",
		minResolution: 0.001373291015625,
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + 'HBSJ/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=HBSJ&STYLE=HBSJ&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
		})
	});
	
	//天地图卫星影像图
	var satelliteLayer = new ol.layer.Tile({
		preload: 0,
		useInterimTilesOnError: false,
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + 'yx_dt/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=yx_dt&STYLE=yx_dt&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
		})
	});

	//天地图注记图层
	var satelliteAnnotationLayer = new ol.layer.Tile({
		preload: 0,
		useInterimTilesOnError: false,
		source: new ol.source.XYZ({
			projection: "EPSG:4326",
			url: mapConfig.tiandituUrl + 'yx_zj/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=yx_zj&STYLE=yx_zj&TILEMATRIXSET=Matrix_0&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}&FORMAT=image%2Ftile'
		})
	});
	
	var params=document.location.search.slice(1);
	console.log(params);
	var wkk=params.split("&")[3];
    var map=null;
    if(!wkk){
    	map = new ol.Map({
    		target: "map",
    		interactions: ol.interaction.defaults({
    			doubleClickZoom:false
    		}),
    		layers: [streetLayer, boundaryLayer, streetAnnotationLayer],
    		view: new ol.View({
    			zoom: 7,
    			maxZoom: 18,
    			minZoom: 6,
    			center: [116.112212109375, 38.566251171875],
    			projection: "EPSG:4326"
    		}),
    		logo: false
    	});
    }else{
    	map = new ol.Map({
    		target: "map",
    		interactions: ol.interaction.defaults({
    			doubleClickZoom:false
    		}),
    		layers: [satelliteLayer, boundaryLayer, satelliteAnnotationLayer],
    		view: new ol.View({
    			zoom: 7,
    			maxZoom: 18,
    			minZoom: 6,
    			center: [116.112212109375, 38.566251171875],
    			projection: "EPSG:4326"
    		}),
    		logo: false
    	});
    }
	
	
	var mousePosition = new ol.control.MousePosition({
		coordinateFormat: ol.coordinate.createStringXY(5),
		projection: 'EPSG:4326',
		className: "ol-mouse-position2"
	});
	map.addControl(mousePosition);

	
	
	var vector1 = new ol.layer.Vector({
		source: new ol.source.Vector()
	});
	map.addLayer(vector1);
	var style1 = new ol.style.Style({
		image: new ol.style.Icon({
			src: mapConfig.imagePoint,
			anchor: [0.5, 1]
		})
	});
	vector1.setStyle(style1);
	$("#fullScreen").bind("click", function () { locationPoint() });
	//定位
	var lon = $("#xCoord").val();
	var lat = $("#yCoord").val();

	if (lon === "" || lon === null || lon === 0 || lon === undefined || lon === 'undefined'||lon === "0") {
	
		var amap=document.createElement("div");
		amap.id="amap";
		document.body.appendChild(amap);
		var mapAMAP, geolocation;
    //加载地图，调用浏览器定位服务
		mapAMAP = new AMap.Map('container', {
        resizeEnable: true
    });
		mapAMAP.plugin('AMap.Geolocation', function() {
        geolocation = new AMap.Geolocation({
            enableHighAccuracy: true,//是否使用高精度定位，默认:true
            timeout: 10000,          //超过10秒后停止定位，默认：无穷大
            buttonOffset: new AMap.Pixel(10, 20),//定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
            zoomToAccuracy: true,      //定位成功后调整地图视野范围使定位位置及精度范围视野内可见，默认：false
            buttonPosition:'RB'
        });
        mapAMAP.addControl(geolocation);
        geolocation.getCurrentPosition();
        AMap.event.addListener(geolocation, 'complete', onComplete);//返回定位信息
        AMap.event.addListener(geolocation, 'error', onError);      //返回定位出错信息
    });
    //解析定位结果
    function onComplete(data) {
        var ctf=new CoordinateTransform();
        var z=ctf.GCJ2WGS(data.position.getLng(),data.position.getLat());
        map.getView().setCenter(z);
		map.getView().setZoom(14);
		var ele=document.createElement("div");
		var image=document.createElement("img");
		image.src="/main/resources/image/map/Point.png";
		ele.appendChild(image);
		
		var overlay=new ol.Overlay({
			element:ele,
			positioning:"center-center",
			position:z,
			offset:[0,-17.5]
		});
		
	    
		map.addOverlay(overlay);
		overlay.getElement().className="bounce";
    }
    //解析定位错误信息
    function onError(data) {
        console.log("定位失败");
    }
		
		
		
		
		
		
		
		
		
		
		map.getView().setCenter([116.112212109375, 38.566251171875]);
		map.getView().setZoom(7);
		return;
	} else {
		mapTools.iniLocation(map, lon, lat, vector1);
	}
	$("#fullmap").bind("click", function () {
		var url = '/main/onemap/map?layer=&xCoord=' + lon + '&yCoord=' + lat;
		window.parent.parent.commonAddTabs("一张图", url);
	});
	
		
		
		

			



		
		function locationPoint() {
			var obj = "";
			var style1 = new ol.style.Style({
				image: new ol.style.Icon({
					src: mapConfig.imagePoint,
					anchor: [0.5, 1]
				})
			});

			drawLocation1 = new ol.interaction.Draw({
				style: style1,
				source: vector1.getSource(),
				type: "Point"
			});
			map.addInteraction(drawLocation1);
			map.getOverlays().clear();
			vector1.getSource().clear();
			var key = drawLocation1.on("drawend", function (evt) {
				//赋值要素
				feature1 = evt.feature;
				var coordinate =evt.feature.getGeometry().getCoordinates();
				
				var x = coordinate[0].toFixed(5);
				var y = coordinate[1].toFixed(5);
				if(!IsPC()){
					Android.position(""+x,""+y);
				}
				$("#labelXY").text(x + "," + y);
				$("#xCoord").val(x);
				$("#yCoord").val(y);
				drawLocation1.unByKey(key);
				map.removeInteraction(drawLocation1);
			});
			$("#fullScreen").text("确认");
			$("#fullScreen").unbind("click").click(confirmDrawLocation);
		};


		function confirmDrawLocation() {
			mapTools.confirmDrawLocation(map);
			var x = $("#xCoord").val();
			var y = $("#yCoord").val();
			var obj = "";
			obj = { 'x': x, 'y': y };
			mapTools.XCoord = x;
			mapTools.YCoord = y;
			callback && callback(obj);
		};

	     $("#navigator").click(function(){
	    	 if($(this).find("img").attr("src").indexOf("normal")>-1){
	    		 $(this).find("img").attr("src","/main/resources/image/map/navigator_click.png");
	    		 Android.navigation(lon,lat);
	    	 }else{
	    		 $(this).find("img").attr("src","/main/resources/image/map/navigator_normal.png");
	    	 }
	     });
	



	
	

});