
function currentTime() {
	var now = new Date();

	var year = now.getFullYear();
	var month = now.getMonth() + 1;
	var day = now.getDate();

	var hh = now.getHours();
	var mm = now.getMinutes();
	var ss = now.getSeconds();

	var clock = year + "-";

	if (month < 10) clock += "0";
	clock += month + "-";

	if (day < 10) clock += "0";
	clock += day + " ";

	if (hh < 10) clock += "0";
	clock += hh + ":";

	if (mm < 10) clock += '0';
	clock += mm + ":";

	if (ss < 10) clock += '0';
	clock += ss;
	return (clock);
}
function getMaxDate() {
	var clock = currentTime();
	var dt;
	var times = 0;
	dt = $("#starttime").val();
	if (dt != '') {
		times = Date.parse(dt.replace(/-/g, '/')) + 1 * 24 * 60 * 60 * 1000;//时间间隔为1天  
		var d1 = new Date(times);
		var year = d1.getFullYear();
		var month = d1.getMonth() + 1;    //月份以0开头   
		var day = d1.getDate();

		var hh = d1.getHours();
		var mm = d1.getMinutes();
		var ss = d1.getSeconds();

		var clock = year + "-";

		if (month < 10) clock += "0";
		clock += month + "-";

		if (day < 10) clock += "0";
		clock += day + " ";

		if (hh < 10) clock += "0";
		clock += hh + ":";

		if (mm < 10) clock += '0';
		clock += mm + ":";

		if (ss < 10) clock += '0';
		clock += ss;
	}
	return clock;
}

/*function getGroupByAreaOld(pageNum) {
	var tbname = $("#layerName").val();
	var xzqhname = $("#xzqhname").val();
	var code = $("#xzqhname").attr("code");
	$("#list3")[0].innerHTML = "";
	var flag = false;
	$.post('/main/vehicle/getGroupByArea', { xzqhname: xzqhname, page: pageNum, tbname: tbname, code: code }, function (data) {
		var nowpage = $("#pageNum").val();
		var total = $("#count").val();
		var lastpage = Math.ceil(total / 12);
		var obj = JSON.parse(data);
		$.each(obj, function (n, value) {
			var aLabel = document.createElement('a');

			$("#list3")[0].appendChild(aLabel);
			aLabel.innerHTML = "<span>图标</span>"+value.name;
			aLabel.id = value.id;
			aLabel.setAttribute("title", value.title);
			aLabel.setAttribute("x", value.x);
			aLabel.setAttribute("y", value.y);
			aLabel.className = "listLocation";
			flag = true;//判断查询是否有数据,决定是否显示列表容器
		});
		if (flag) {
			if (nowpage == 1 && lastpage != 1) {
				$("#list3").append("<div class='maplistpage'><p class='fl'><a class='fenye'>共<strong>1</strong>页</a><a class='fenye' >当前是第<strong>1</strong>页</a></p><p class='fl'><a href='javascript:void(0)' class='fenye' id='startpage'>首页</a><a href='javascript:void(0)' class='fenye' id='prepage'>上一页</a><a class='fenye-act' id='nextpage' onclick='nextpage()'>下一页</a><a class='fenye-act' id='lastpage' onclick='lastpage()'>尾页</a></p></div>");
			} else if (nowpage != 1 && nowpage != lastpage) {
				$("#list3").append("<div class='maplistpage'><p class='fl'><a class='fenye'>共<strong>1</strong>页</a><a class='fenye' >当前是第<strong>1</strong>页</a></p><p class='fl'><a class='fenye-act' id='startpage' onclick='startpage()'>首页</a><a class='fenye-act' id='prepage' onclick='prepage()'>上一页</a><a class='fenye-act' id='nextpage' onclick='nextpage()'>下一页</a><a class='fenye-act' id='lastpage' onclick='lastpage()'>尾页</a></p></div>");
			} else if (nowpage == lastpage && lastpage != 1) {
				$("#list3").append("<div class='maplistpage'><p class='fl'><a class='fenye'>共<strong>1</strong>页</a><a class='fenye' >当前是第<strong>1</strong>页</a></p><p class='fl'><a class='fenye-act' id='startpage' onclick='startpage()'>首页</a><a class='fenye-act' id='prepage' onclick='prepage()'>上一页</a><a href='javascript:void(0)' class='fenye' id='nextpage'>下一页</a><a href='javascript:void(0)' class='fenye' id='lastpage'>尾页</a></p></div>");
			} else if (nowpage == 1 && total <= 12) {

			}
			$("#list3:first").slideDown("fast");
		} else {
			layer.msg("查询无结果");
			if ($("#list3").css("display") === "block") {
				$("#list3").css("display", "none");
			}
		}
	});
}*/
function getGroupByArea(pageNum,url) {
	//code：行业代码
	//fl：监管行业代码
	//lfj：左侧分级编码
	//lfl：左侧分类编码
	var params = getCode();
	//行业代码
	var hydm = params.code;
	//监管行业
	var jghy = params.fl;
	//左侧分级编码
	var fjbm = params.lfj;
	//左侧分类编码
	var flbm = params.lfl;
	//当前图层名称
	var tbname = $("#layerName").val();
	//行政区划
	var xzqh = $("#xzqhname").val();
	$("#list3")[0].innerHTML = "";
	var flag = false;
	            //当前页、       行业代码、   监管分类代码、分级代码、   分类代码、  行政区划         
	$.post(url, {page:pageNum, hydm:hydm, jghy:jghy, fjbm:fjbm, flbm:flbm, xzqh:xzqh}, function (data) {
		var nowpage = $("#pageNum").val();
		var total = $("#count").val();
		var lastpage = Math.ceil(total / 12);
		var obj = JSON.parse(data);
		$("#list3")[0].innerHTML = "";
		$.each(obj, function (n, value) {
			var aLabel = document.createElement('a');
			$("#list3")[0].appendChild(aLabel);
			aLabel.innerHTML = "<span></span>"+value.title;
			aLabel.id = value.id;
			aLabel.setAttribute("title", value.title);
			aLabel.setAttribute("x", value.x);
			aLabel.setAttribute("y", value.y);
			aLabel.className = "listLocation";
			flag = true;//判断查询是否有数据,决定是否显示列表容器
		});
	
		if (flag) {
			if (nowpage == 1 && lastpage != 1) {
				$("#list3").append("<div style='text-align:center;margin-top:5px;'><a href='javascript:void(0)' class='fenye' id='startpage'>首页</a><a href='javascript:void(0)' class='fenye' id='prepage'>上一页</a><a class='fenye-act' id='nextpage' onclick='nextpage(\""+url+"\")'>下一页</a><a class='fenye-act' id='lastpage' onclick='lastpage(\""+url+"\")'>尾页</a></div><div class='tc'><a class='fenye'>共<strong style='color:#0066cc;'>"+lastpage+"</strong>页</a><a class='fenye' >当前是第<strong style='color:#0066cc;'>"+nowpage+"</strong>页</a></div>");
			} else if (nowpage != 1 && nowpage != lastpage) {
				$("#list3").append("<div style='text-align:center;margin-top:5px;'><a class='fenye-act' id='startpage' onclick='startpage(\""+url+"\")'>首页</a><a class='fenye-act' id='prepage' onclick='prepage(\""+url+"\")'>上一页</a><a class='fenye-act' id='nextpage' onclick='nextpage(\""+url+"\")'>下一页</a><a class='fenye-act' id='lastpage' onclick='lastpage(\""+url+"\")'>尾页</a></div><div class='tc'><a class='fenye'>共<strong style='color:#0066cc;'>"+lastpage+"</strong>页</a><a class='fenye' >当前是第<strong style='color:#0066cc;'>"+nowpage+"</strong>页</a></div>");
			} else if (nowpage == lastpage && lastpage != 1) {
				$("#list3").append("<div style='text-align:center;margin-top:5px;'><a class='fenye-act' id='startpage' onclick='startpage(\""+url+"\")'>首页</a><a class='fenye-act' id='prepage' onclick='prepage(\""+url+"\")'>上一页</a><a href='javascript:void(0)' class='fenye' id='nextpage'>下一页</a><a href='javascript:void(0)' class='fenye' id='lastpage'>尾页</a></div><div class='tc'><a class='fenye'>共<strong style='color:#0066cc;'>"+lastpage+"</strong>页</a><a class='fenye' >当前是第<strong style='color:#0066cc;'>"+nowpage+"</strong>页</a></div>");
			} else if (nowpage == 1 && total <= 12) {

			}
			$("#list3:first").slideDown("fast");
		} else {
			layer.msg("查询无结果");
			if ($("#list3").css("display") === "block") {
				$("#list3").css("display", "none");
			}
		}
	});
}
//首页
function startpage(url) {
	var nowpage = $("#pageNum").val();
	if (nowpage != 1) {
		$("#pageNum").val(1);

		getGroupByArea(1,url);
	}
}
//尾页
function lastpage(url) {
	var nowpage = $("#pageNum").val();
	var total = $("#count").val();
	var lastpage = Math.ceil(total / 12);
	if (nowpage < lastpage) {
		$("#pageNum").val(lastpage);

		getGroupByArea(lastpage,url);
	}
}

// 下一页
function nextpage(url) {
	var nowpage = $("#pageNum").val();
	var total = $("#count").val();
	var lastpage = Math.ceil(total / 12);
	if (nowpage < lastpage) {
		var pageNum = parseInt(nowpage) + 1;
		$("#pageNum").val(pageNum);

		getGroupByArea(pageNum,url);
	}
}
//上一页	
function prepage(url) {
	var nowpage = $("#pageNum").val();
	if (nowpage != 1) {
		var pageNum = parseInt(nowpage) - 1;
		$("#pageNum").val(pageNum);

		getGroupByArea(pageNum,url);
	}
}
/**
 * 根据车牌号，获取行车轨迹
 * @param plateno,type
 * @returns
 */
function openGuiji(id) {
	var starttime = $("#starttime").val();
	var endtime = $("#endtime").val();
	if (starttime == "" && endtime == "") {
		var now = currentTime();
		var times = Date.parse(now.replace(/-/g, '/'));
		var d1 = new Date(times);
		var year = d1.getFullYear();
		var month = d1.getMonth() + 1;    //月份以0开头   
		var day = d1.getDate() - 1;

		var hh = d1.getHours();
		var mm = d1.getMinutes();
		var ss = d1.getSeconds();

		var clock = year + "-";

		if (month < 10) clock += "0";
		clock += month + "-";

		if (day < 10) clock += "0";
		clock += day + " ";

		if (hh < 10) clock += "0";
		clock += hh + ":";

		if (mm < 10) clock += '0';
		clock += mm + ":";;

		if (ss < 10) clock += '0';
		clock += ss;
		$("#endtime").val(now);
		$("#starttime").val(clock);
	}
	$("#select_plateno").val(id);
	$("#select_type").val("cache.png");
	layer.open({
		type: 1,
		title: '时间范围',
		content: $("#guiji_div"),
		area: ["400px", "auto"],
		end: function () {
			$("#guiji_div").css("display", "none");
		}
	});
}



requirejs.config({
    urlArgs:"version="+new Date()
});

require(["mapTools", "initMap", "mapConfig", "domOperation", "ol", "buffer", "chartsShow","bookmark","emergency","layerConfig","judge"],
	function (mapTools, initMap, mapConfig, domOperation, ol, buffer, chartsShow,bookmark,emergency,layerConfig,judge) {

	
		//书签初始化绑定
		bookmark.init();
		//决策应急
		emergency.init();
		
		//获取用户过滤参数
		$.ajax({
			url:"/main/onemap/UserFilter",
			type:"POST",
			async:false,
			cache:true,
			success:function(data){
				mapConfig.userFilters=data;
			}
		});
		
		//获取监管类型列表
		$.get("/main/onemap/GetJgType",function(data){
			 var objs=Object.keys(data);
			 var $supervise2=$("#supervise2 ul");
			 for(var i=0,z=objs.length;i<z;i++){
				 $supervise2.append('<li class="sonson-main"><a codenum="'+objs[i]+'" herf="#2">'+data[objs[i]]+'</a></li>');
			 }
		})
		
		
		
		
		
		
		/**
		 * 根据车牌号获得车最后坐标点，地图展示
		 * type  1121:卡车,1122:小轿车,1123:救援车
		 * @param plateno
		 * @returns
		 */
		var stopAnim;//用来停止动画
		window.chePosition = function chePosition(plateno, type) {
			clearInterval(stopAnim);
			initMap.stopAnim = mapTools.stopAnim = stopAnim = setInterval(mapTools.currentLocation, 1000, plateno, type);
		}






		/**
		 * 搜索车辆gps信息
		 * @returns
		 */
		function searchGPS() {
			var plateno;
			var flag = false;
			plateno = $("#searchval").val();//获取查询条件值
			$.post('/main/vehicle/getVehicle', { plateno: plateno }, function (data) {
				var obj = JSON.parse(data);
				$.each(obj, function (n, value) {
					var li = "";
					li = "<li class='clearfix'><span><img src='/main/resources/image/map/" + value.pic + "'/></span><a href='#2' onclick='chePosition(\"" + value.plateno + "\",\"" + value.type + "\")' title='" + value.plateno + "'>" + value.plateno + "</a><span style='cursor: pointer;' onclick='openGuiji(\"" + value.plateno + "\",\"" + value.type + "\")'><img src='/main/resources/image/map/lishiguiji.png'/></span></li>";
					flag = true;//判断查询是否有数据,决定是否显示列表容器
				});
			});
		}

		/**
		 * 搜索车辆超时信息
		 * @returns
		 */
		function searchTimeout() {
			var plateno;
			var flag = false;
			plateno = $("#searchval").val();//获取查询条件值
			$.post('/main/vehicle/getVehicle', { plateno: plateno }, function (data) {
				var obj = JSON.parse(data);
				$.each(obj, function (n, value) {
					var li = "";
					li = "<li class='clearfix'><span><img src='/main/resources/image/map/" + value.pic + "'/></span><a href='#2' onclick='chePosition(\"" + value.plateno + "\",\"" + value.type + "\")' title='" + value.plateno + "'>" + value.plateno + "</a><span style='cursor: pointer;' onclick='openGuiji(\"" + value.plateno + "\",\"" + value.type + "\")'><img src='/main/resources/image/map/lishiguiji.png'/></span></li>";
					$("#gps_list").append(li);
					flag = true;//判断查询是否有数据,决定是否显示列表容器
				});
			});
		}

		/**
		 * 搜索车辆超速信息
		 * @returns
		 */
		function searchSpeedout() {
			var plateno;
			var flag = false;
			plateno = $("#searchval").val();//获取查询条件值
			$("#gps_list").html("");//清空列表容器
			$.post('/main/vehicle/getVehicle', { plateno: plateno }, function (data) {
				var obj = JSON.parse(data);
				$.each(obj, function (n, value) {
					var li = "";
					li = "<li class='clearfix'><span><img src='/main/resources/image/map/" + value.pic + "'/></span><a href='#2' onclick='chePosition(\"" + value.plateno + "\",\"" + value.type + "\")' title='" + value.plateno + "'>" + value.plateno + "</a><span style='cursor: pointer;' onclick='openGuiji(\"" + value.plateno + "\",\"" + value.type + "\")'><img src='/main/resources/image/map/lishiguiji.png'/></span></li>";
					$("#gps_list").append(li);
					flag = true;//判断查询是否有数据,决定是否显示列表容器
				});
			});
		}


		//因为不同权限，工具条的长度不一样设为auto
		$(".easyui-panel").css("width", "auto");




        //暂时的代码，用来暂时删除缓冲区分析中的一些选项
		$("#mapBufferSet label").each(function(index,ele){
			var $for=$(ele);
			 switch(true){
			 case $for.prop("for").indexOf("HBAJ:GEOM_SGBS")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_DYJYA_BASQB")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_STANDARD")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_LAWINFO_PLAN")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_HON_CHMAIN")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_YJSJ")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_ZYBWH")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_SUPERVISION")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_ZJJG")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_REGULATION_SUBJECT")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_EMERG_RESPONSE")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_SPECIAL")>-1:
				 $for.remove();
				 break;
			 case $for.prop("for").indexOf("HBAJ:GEOM_KSK")>-1:
				 $for.remove();
				 break; 
			 case $for.prop("for").indexOf("HBAJ:GEOM_FIREWORKS")>-1:
				 $for.remove();
				 break; 
			 }
		})
		
		




		// 初始化地图
		var map = initMap.init();
		var view = map.getView();
		
		//新的变量块2017/11/7
		var currentLayer="",selLys=[];//当前图层
		
		
		
		
		
		var lengendLayer = [];//用来保存图例，所有图层名称
		var getSearchLay = [];//进行i查询时候需要的多个图层名称
		var statLayers = [];//专题图层
		domOperation.jqueryExtend();
		//domOperation.initSearchList();
		//domOperation.searchBox();  //删除搜索框的图层选择功能

		$.post("/main/onemap/getCenterPoint", function (data) {
			if (data !== "") {
				var splitData = data.split('#');
				var format = new ol.format.WKT();
				var center = format.readFeature(splitData[0]).getGeometry().getCoordinates();
				view.setCenter(center);
				view.setZoom(8);
				mapTools.getCityPolygon(splitData[1], view, center);
			}
		});






		//添加应急救援点
		$("#rescue").click(function () {
			var style = new ol.style.Style({
				image: new ol.style.Icon({
					src: "../resources/image/map/huo.png",
					anchor: [0.5, 1]
				})
			});

			/*var style2=new ol.style.Style({
				image:new ol.style.Circle({
					  radius:3,
					  stroke:new ol.style.Stroke({
						  width:2,
						  color:"#ff0000"
					  })
				})});*/
			var rescueDraw = initMap.createDraw("Point", initMap.rescueLayer.getSource(), style);
			map.addInteraction(rescueDraw);
			rescueDraw.on("drawend", function (evt) {
				var i = 1, z = true;
				map.removeInteraction(rescueDraw);
				var el = document.createElement("img"); el.src = "../resources/image/map/1.gif";
				var overlay = new ol.Overlay({
					element: el,
					positioning: "center-center"
				});
				map.addOverlay(overlay);

				var lon = evt.feature.getGeometry().getCoordinates()[0];
				var lat = evt.feature.getGeometry().getCoordinates()[1];

				var url = "/main/emer/emertopage?lon=" + lon + "&lat=" + lat;
				overlay.setPosition([lon, lat]);
				var z = layer.open({
					type: 2,
					skin: "dome-layer",
					title: "创建事故",
					area: ["790px", "500px"],
					fix: false, //不固定
					content: url,
					btn: false,
					closeBtn: 1,
					cancel: function () {
						initMap.rescueLayer.getSource().clear();
						overlay.setPosition(undefined);
					}
				});
			});
		});



		//十进制经度改变，改变相应六十进制数值

		$("#mapLon1").bind("input propertychange", function () {
			var degree = parseInt($(this).val()) || 0;
			var minute = (parseFloat($(this).val()) - degree) * 60 || 0;
			var second = (minute - parseInt(minute)) * 60 || 0;
			$("#mapLon2").val(degree).next().val(Math.round(minute)).next().val(Math.round(second));
		});

		$("#mapLat1").bind("input propertychange", function () {
			var degree = parseInt($(this).val()) || 0;
			var minute = (parseFloat($(this).val()) - degree) * 60 || 0;
			var second = (minute - parseInt(minute)) * 60 || 0;
			$("#mapLat2").val(degree).next().val(Math.round(minute)).next().val(Math.round(second));
		});

		//六十进制维度改变，改变相应十进制数值
		var locationLon = 0, locationLat = 0;
		$("#mapLon2").bind("input propertychange", function () {
			locationLon = parseFloat($(this).val()) || 0;
			$("#mapLon1").val(locationLon);
		});

		$("#mapLon2").next().bind("input propertychange", function () {
			locationLon = locationLon + parseFloat($(this).val()) / 60.0 || 0;
			$("#mapLon1").val(locationLon);
		});


		$("#mapLon2").next().next().bind("input propertychange", function () {
			locationLon = locationLon + parseFloat($(this).val()) / (60.0 * 60.0);
			$("#mapLon1").val(locationLon);
		});

		$("#mapLat2").bind("input propertychange", function () {
			locationLon = parseFloat($(this).val()) || 0;
			$("#mapLat1").val(locationLon);
		});

		$("#mapLat2").next().bind("input propertychange", function () {
			locationLon = locationLon + parseFloat($(this).val()) / 60.0 || 0;
			$("#mapLat1").val(locationLon);
		});


		$("#mapLat2").next().next().bind("input propertychange", function () {
			locationLon = locationLon + parseFloat($(this).val()) / (60.0 * 60.0) || 0;
			$("#mapLat1").val(locationLon);
		});




		// 十进制度分秒定位功能
		$("#mapSetLocation").click(function () {
			layer.close(layer.index);
			$("#mapLonLat").css("display", "none");
			var lon = $("#mapLon1").val();
			var lat = $("#mapLat1").val();
			var isRight = $("#mapLon1").verify("lon") && $("#mapLat1").verify("lat") ? true : false;
			if (isRight) {
				initMap.panToPoint([parseFloat(lon), parseFloat(lat)]);
				var feature = new ol.Feature({
					geometry: new ol.geom.Point([parseFloat(lon), parseFloat(lat)])
				});
				initMap.locationLayer.getSource().addFeature(feature);
			}
		});



		// 为i查询创建一个overlay
		var overlay = mapTools.overlayFunction();
		/*// 工具，包括面积和长度量算
		$("#mm2").menu({
			onClick: function (evt) {
				var text = evt.text;
				switch (text) {
					case "长度量算":
						mapTools.measureLength(map);
						break;
					case "面积量算":
						mapTools.measureArea(map);
						break;
					case "开启卷帘":
						mapTools.openSwipe(map);
						break;
					case "关闭卷帘":
						mapTools.closeSwipe(map);
						break;
					case "清除历史轨迹":
						mapTools.closeTrack();
						break;
					case "应急指挥":

						if ($("#plotting").css("display") === "none") {
							$(evt.target).css("backgroundColor", "#9EB6DC")
							$("#plotting").css("display", "block");
						} else {
							$(evt.target).css("backgroundColor", "#FAFAFA")
							plotLayer.getSource().clear();
							$("#plotting").css("display", "none");
						}

						break;
					case "四色图":
						if (initMap.sisetu.getVisible()) {
							initMap.sisetu.setVisible(false);
						} else {
							initMap.sisetu.setVisible(true);
							initMap.panToPoint([114.45337, 38.07544]);
						}
						break;
				}
				return true;
			}
		});*/


		



		// 缓冲区的画点和画线交互工具
		var drawPoint = initMap.createDraw("Point", initMap.searchLayer.getSource());
		var drawLine = initMap.createDraw("LineString", initMap.searchLayer.getSource());
		var drawPolygon = initMap.createDraw("Polygon", initMap.searchLayer.getSource());

		var $map = $("#map"), isearchKey = "";
		
		var bufferType;
		

		$("#mapSetPoint").click(
			function () {
				//清除统计图层
				initMap.statisticalLayer.getSource().clear();
				layer.close(layer.index);
				$("#mapBufferSet").css("display", "none");
				var layerNames = $("#mapBufferSet > div :checked").map(
					function () {
						return $(this).attr("id");
					}).get();
				getSearchLay = layerNames;
				var bufferDistance = parseFloat($("#mapBufferDistance").val());
				if (bufferType === "polygon") bufferDistance = 0.1;
				if (!bufferDistance) {
					layer.msg("请输入缓冲区距离");
					return false;
				} else {
					if (bufferType === "point") {
						buffer.buffer(map, initMap.searchLayer
							.getSource(), drawPoint, layerNames,
							bufferDistance);
					} else if (bufferType === "line") {
						buffer.buffer(map, initMap.searchLayer
							.getSource(), drawLine, layerNames,
							bufferDistance);
					} else {
						buffer.buffer(map, initMap.searchLayer
							.getSource(), drawPolygon, layerNames,
							0.1);
					}

				}
			});

		// 添加标绘工具
		$("#plotPoint").click(function () {
			initMap.browserPositioning();
			mapTools.plotPoint(map, "companyInfo");
		});



		// 为专题图统计创建一个弹出框
		var echartsOverlay = mapTools.overlayFunction();
		// 用来存放select事件的key值，用以需要时取消
		var echartsKey = "";
		$("#statisticThematic").click(function () {
			initMap.routeLayer.getSource().clear();
			$(".cemain").slideUp();
			$("#list").css("display", "none");
			//清除查询出的数据和统计图层
			initMap.statisticalLayer.getSource().clear();
			initMap.searchLayer.getSource().clear();
			// 每点击一次就移除一次，防止给map添加过多select交互事件
			map.removeInteraction(initMap.themeSelect);
			// 移除select事件
			initMap.themeSelect.unByKey(echartsKey);
			layer.close(layer.index);
			$("#themeticSelect").css("display", "none");

			var selectText = [];
			var selectedVal = $("#themeticSelect option").filter(':selected').map(function () {
				var val = $(this).val();
				selectText.push($(this).text());
				return val;
			}).get();
			var legendName = mapTools.getTitles(selectedVal[0]);
			var colors = ['#ff0000', '#FFA500', '#ffff00', '#00ff00', '#00ffff', '#0000ff', '#800080', '#CD853F', '#FFE4E1'];
			$("#statisticsLegend").html("");
			for (var j = 0, k = legendName.length; j < k; j++) {
				$("#statisticsLegend").append('<button type="button" class="am-btn" style="background-color:' + colors[j] + '">' + legendName[j] + '</button>');
			}


			$.post(mapConfig.tongji, {
				layerName: selectedVal[0],
				years: selectedVal[1]
			},
				function (data) {
					mapTools.showTheme(data, map, initMap.themeMap, selectedVal[2]);
					map.addInteraction(initMap.themeSelect);
					echartsKey = initMap.themeSelect.on("select", function (evt) {

						//如何被选中要素不为零
						if (evt.selected.length !== 0) {
							var data = evt.selected[0].get("data");
							var grades = evt.selected[0].get("grades");
							map.getOverlays().clear();
							var overlay = mapTools.overlayFunction();
							// 在弹出框中显示图表信息
							chartsShow.echartsShow(data, selectText[0], overlay, grades, selectedVal[1], selectedVal[0], evt.selected[0].get("city"));

							overlay.setPosition(evt.mapBrowserEvent.coordinate);
							map.addOverlay(overlay);
						}
					});
				});
		});

		// 搜索框
		$("#searchbox").on("click", function () {
			domOperation.search(currentLayer);
		});

		//给搜索框输入，键盘回车事件
		$("#searchval").on("keypress", function (evt) {
			if (evt.keyCode === 13) {
				domOperation.search(currentLayer);
			}
		});
		$(document).find("#list").mouseover(function (evt) {
			var target = evt.target;
			if (target.nodeName === "A") {
				var id = target.id;
				var features = initMap.searchLayer.getSource().getFeatures();
				for (var i = 0, z = features.length; i < z; i++) {
					if (features[i].i === id) {
						var style = new ol.style.Style({
							image: new ol.style.Icon({
								src:mapConfig.imagePoint,
								anchor:[0.5,1]
							}),
							zIndex: 220
						});
						features[i].setStyle(style);
						break;
					}
				}
			}
		}).mouseout(function (evt) {
			var target = evt.target;
			if (target.nodeName === "A") {
				var id = target.id;
				var features = initMap.searchLayer.getSource().getFeatures();
				for (var i = 0, z = features.length; i < z; i++) {
					if (features[i].i === id) {
						var style = new ol.style.Style({
							image: new ol.style.Circle({
								radius: 4,
								fill: new ol.style.Fill({
									color: "#FFCC99"
								}),
								stroke: new ol.style.Stroke({
									color: "#FFFFFF",
									width: 1
								})
							}),
							zIndex: 1
						});
						features[i].setStyle(style);
						break;
					}
				}
			}
		});

		//关闭搜索框中图层选择框
		$("#layerConfig").on("click", function () {
			$("#searchLayer").css("display", "none");
			layer.close(layer.index);
		});

		// 清除专题图层工具
		/*$("#mapClearLayer").click(function () {
			$("#statisticsLegend").html("");
			// 清除专题图select交互控件
			map.removeInteraction(initMap.themeSelect);
			initMap.themeMap.getSource().clear();
		});*/

		// 标绘工具提交按钮
		$("#submitMap").click(function () {
			domOperation.compannySubmit('ff', 'companyInfo');
		});

		// 标绘弹出框中的清除功能
		$("#submit_clear").click(function () {
			domOperation.clearForm('ff');
		});

		// 用来隐藏其他四个专题图层
		function validationLayer(id) {
			var layer = mapTools.getLayer(map, id);
			for (var i = 0, z = initMap.thematicLayers.length; i < z; i++) {
				if (initMap.thematicLayers[i].get("id") != id) {
					initMap.thematicLayers[i].setVisible(false);
				}
			}
			var isShow = layer.getVisible();
			if (isShow) {
				layer.setVisible(false);
			} else {
				layer.setVisible(true);
			}
		}



		
        var viewThrottle=null,imageLoad=null;
		view.on("change:resolution", function (evt) {
			if (currentLayer === "") {
				return;
			}

			var zoom = view.getZoom();
			//如果图层统计图层的isStic为true才进行统计否则不进行统计
			if (currentLayer) {
				var params=domOperation.getCodeFl(null);
				if (zoom >= 9) {
					!viewThrottle?null:clearTimeout(viewThrottle);
					viewThrottle=setTimeout(function(){
						initMap.statisticalLayer.getSource().clear();
						mapTools.getCountyData(currentLayer,params);
					},350);
				}
				if (zoom <= 8) {
					!viewThrottle?null:clearTimeout(viewThrottle);
					viewThrottle=setTimeout(function(){
						initMap.statisticalLayer.getSource().clear();
						mapTools.showData(currentLayer,params);
					},350);
				}
			}
			mapTools.CityOrCountyRisk(imageLoad);
			
		});
		
	
		
		
		


		//右键菜单事件
		$("#mymenu").css("display","block");
		var contextMenu = new ol.Overlay({
			element: $("#mymenu").get(0),
			id: "contextMenu"
		});
		map.addOverlay(contextMenu);
		$("#map").on("contextmenu", function (e) {
			e.preventDefault();
			var hasOverlay = false;
			for (var i = 0, z = map.getOverlays().getArray().length; i < z; i++) {
				if (map.getOverlays().getArray()[i].get("id") === "contextMenu") {
					hasOverlay = true;
				}
			}
			if (hasOverlay === false) {
				map.addOverlay(contextMenu);
			}
			contextMenu.setPosition(map.getEventCoordinate(e));
		});

		$("#map li").on("click", function () {
			var source = initMap.routeLayer.getSource();
			var coordinates = contextMenu.getPosition(), point, style = "";
			var text = $(this).text(), n = source.getFeatures().length;
			switch (text) {
				case "设为起点":

					for (var m = 0; m < n; m++) {
						if (source.getFeatures()[m].get("name") === "start") {
							source.removeFeature(source.getFeatures()[m]);
							break;
						}
					}
					style = new ol.style.Style({
						image: new ol.style.Icon({
							src: "../resources/image/map/start2.png",
							anchor: [0.42, 1]
						})
					});
					point = new ol.Feature({
						geometry: new ol.geom.Point(coordinates),
						name: "start"
					});
					break;
				case "设为终点":
					for (var j = 0; j < n; j++) {
						if (source.getFeatures()[j].get("name") === "end") {
							source.removeFeature(source.getFeatures()[j]);
							break;
						}
					}
					style = new ol.style.Style({
						image: new ol.style.Icon({
							src: "../resources/image/map/end2.png",
							anchor: [0.42, 1]
						})
					});
					point = new ol.Feature({
						geometry: new ol.geom.Point(coordinates),
						name: "end"
					});
					break;
				case "另存为图片":
					var canvas = document.querySelector("canvas.ol-unselectable");
					try{
						var s = canvas.toDataURL("image/png");
						var labelA = document.createElement("a");
						if (navigator.msSaveBlob) {
							navigator.msSaveBlob(canvas.msToBlob(), 'map.png');
						} else {
							canvas.toBlob(function (blob) {
								saveAs(blob, 'map.png');
							});
						}
					}catch(e){
						console.error("另存为图片失败原因:",e.message);
					}
					
					break;
				case "添加书签":
					var zoom=initMap.map.getView().getZoom();
					var center=initMap.map.getView().getCenter();
					var position=Math.floor(center[0] * 10000) / 10000+'-'+Math.floor(center[1] * 10000) / 10000;			
					layer.prompt({title: '请输入书签名称：', formType: 0,btn:['保存','取消']}, function(name, index){
						if(!name){
							layer.msg('请输入书签名称！');
							return;
						}
						layer.close(index);
					    bookmark.updateMark('add','',position,name,zoom);
					    contextMenu.setPosition(undefined);
					    });
					break;
			}
			if (style != "") {
				point.setStyle(style);
				source.addFeature(point);
				if (source.getFeatures().length > 1) {
					//隐藏右击菜单
					contextMenu.setPosition(undefined);
					mapTools.routeFind(source);
				}else{
					contextMenu.setPosition(undefined);
				}
			}
			

		});

		//存放查询列表的jquery对象
		var $myList = $("#list");
		var rescueLayerClear=null;//用来清除点击应急响应时开启的动画
		//用来存放应急响应动画点的图层
		var rescueLayerClearLayer=new ol.layer.Vector({
			source:new ol.source.Vector()
		});
		rescueLayerClearLayer.setZIndex(800)
		map.addLayer(rescueLayerClearLayer);
		
		
		//当点击地图的时候，隐藏查询列表栏
		map.on("singleclick", function (evt) {
			//隐藏右击菜单
			contextMenu.setPosition(undefined);
			if ($myList.css("display") === "block") {
				$myList.slideUp("fast");
			}
			if ($("#list3").css("display") === "block") {
				$("#list3").slideUp("fast");
			}

			var f = initMap.statisticalLayer.getSource().getFeatures();
			if (f.length !== 0) {
				map.forEachFeatureAtPixel(evt.pixel, function (f, l) {
					if(l==initMap.statisticalLayer){
						var layerName = currentLayer;
						//企业、事故、烟花爆竹、尾矿库、装备图层在点击统计的点时显示名称列表；新增应急物资、救援队伍、重大危险源
						//if (layerName == 'GEOM_QYJCXX' || layerName == 'GEOM_SGBS' || layerName == 'GEOM_FIREWORKS'|| layerName == 'GEOM_WXYHZB' || layerName == 'GEOM_WKK' || layerName == 'GEOM_YJZY_YJJYZB'||layerName =='GEOM_YJYA_YJWZ'||layerName=="GEOM_YJZY_YJJYDW") {
						var url="";	
							if(layerName == 'GEOM_QYJCXX'){//企业
								url="/main/zjjgManager/qyFjflMapOpenJson";
							}else if(layerName == 'GEOM_WXYHZB'){//重大危险源
								url="/main/zdwxySqManage/searchZdwxyDetailForMap";
							}else if(layerName == 'GEOM_SGBS'){//事故
								url="/main/accidentreprot/mapSgDiv";
							}else if(layerName == 'GEOM_Danger_Report'){//隐患排查
								url="/main/danger/getDangerMapListData";
							}else if(layerName == 'GEOM_DYJYA_BASQB'){//应急预案
								url="/main/yjyabasqbManager/searchYjyaBasqbForMap";
							}else if(layerName == 'GEOM_STANDARD'){//标准化
								url="/main/unifyStandard/searchStandardAppJsonForMap";
							}else if(layerName == 'GEOM_YJYA_YJWZ'){//应急物资
								url="/main/yjzyManager/jywzFjflMapOpenJson";
							}else if(layerName == 'GEOM_YJZY_YJJYDW'){//救援队伍
								url="/main/yjzyManager/jydwFjflMapOpenJson";
							}else if(layerName == 'GEOM_YJZY_YJJYZB'){//救援装备
								url="/main/yjzyManager/jyzbFjflMapOpenJson";
							}else if(layerName == 'GEOM_LAWINFO_PLAN'){//执法监察
								url="/main/zfjc/getLiAnMapJson";
							}else if(layerName == 'GEOM_HON_CHMAIN'){//诚信企业
								url="/main/appli/getChengxinCompanyListData";
							}else if(layerName == 'GEOM_ZYBWH'){//职业病危害
								url="/main/zyjkManager/getZybwhCompanyMapListData";
							}else if(layerName == 'GEOM_SUPERVISION'){//监管监察
								url="/main/superVisionRecord/toJGJCMapLayerJson";
							}else if(layerName == 'GEOM_EMERG_RESPONSE'){//应急响应
								url="/main/yjxy/searchGeomEmergRespJsonForMap";
							}else if(layerName == 'GEOM_ZJJG'){//中介机构
								url="/main/zjjgManager/jgFjflMapOpenJson";
							}else if(layerName == 'GEOM_SPECIAL'){//专项检查
								url="/main/superVisionRecord/toZXJCMapLayerJson";
							}else if(layerName == 'GEOM_WKK'){//尾矿库
								url="/main/wkk/wkkFjHygl";
							}else if(layerName == 'GEOM_VB_TARGET'){//脆弱性目标
								url="/main/vulnerbilityTarget/getVbMapJson";
							}else if(layerName == 'GEOM_RISK_POINT'){//风险点
								url="/main/riskPoint/getFxdMapJson";
							}
							else if(layerName == 'GEOM_WXYQY'){//危险源企业
								url="/main/zdwxySqManage/searchZdwxyQyjcxxDetailForMap";
							}
							
							$("#layerName").val(layerName);
							var xzqhname = f.get("xzqh");
							$("#xzqhname").val(xzqhname);
							var count = f.get("count");
							$("#count").val(count);
							$("#pageNum").val(1);
							getGroupByArea(1,url);
					}
				});
			}
			
			if(populationData.getSource().getFeatures().length>0){
				map.forEachFeatureAtPixel(evt.pixel, function (f, l) {
					if(l==heatLayer){
						if (f.get("rksl")) {
							map.getOverlays().clear();
							//人口数据的overlay
							var population = mapTools.overlayFunction();
							population.getElement().lastChild.innerHTML = f.get("name") + "人口数为:" + f.get("rksl");
							map.addOverlay(population);
							population.setPosition(evt.coordinate);
						}
					}
				})
			}
			
			
			
			if(consultationLayer.getVisible()){
				
				var url = consultationLayer.getSource().getGetFeatureInfoUrl(evt.coordinate, view.getResolution(), view.getProjection(),
						{
							'INFO_FORMAT': 'application/json',
							'FEATURE_COUNT': 1
						});
					$.get(url, function (data) {
						if (data.features.length === 0) {
							return;
						}
						if(data.features[0].properties.TYPE==="1"){
							if(!domOperation.IsPC()){
								 Android.getCompanyCameras(data.features[0].properties.QYOPGUID);
							}else{
								layer.open({
									type: 2,
									skin: "dome-layer",
									title: "远程会商",
									area: ["100%", "100%"],
									fix: false, //不固定
									content: "/main/tbcamera/camerainfo?id=" + data.features[0].properties.ID,
									btn: false,
									closeBtn: 1
								});
							}
							
						}
						});
				
			}
			
			
			if(initMap.addResources){
				if(currentLayer==="GEOM_YJYA_YJWZ"||currentLayer==="GEOM_YJZY_YJJYDW"||currentLayer==="GEOM_YJZY_YJJYZB"){//当当前图层为救援装备、队伍、物资的时候，询问是否要添加这条记录到应急响应
					var layerSource=null;
					for (var i = 0, z = statLayers.length; i < z; i++) {
						if (statLayers[i].get("layerName") === currentLayer) {
							layerSource=statLayers[i].getSource();
							layerSource.updateParams({ LAYERS: currentLayer })
							break;
						}
					}
					var url = layerSource.getGetFeatureInfoUrl(evt.coordinate, view.getResolution(), view.getProjection(),
							{
								'INFO_FORMAT': 'application/json',
								'FEATURE_COUNT': 100
							});
					$.get(url).done(function(data){
						 var format=new ol.format.GeoJSON(),features=null;
						 
						 console.log(data);
						 var tbLayer="",name="";
     		    		   switch(currentLayer){
     		    		   case "GEOM_YJZY_YJJYZB": //装备
     		    			   tbLayer="EQUIP_DISTRIBUTING";
     		    			   break;
     		    		   case "GEOM_YJZY_YJJYDW":    //队伍
     		    			   tbLayer="AMBULANCE_DISTRIBUTING";
     		    			   break;
     		    		   case "GEOM_YJYA_YJWZ":    //物资
     		    			   tbLayer="MATERIAL_DISTRIBUTING";
     		    			   break;
     		    		   }
						  if(data.features.length!==0){
							  features=format.readFeatures(data);
							  var html="<div><ul class='am-list'>";
							  features.forEach(function(val,index){
								  var name=domOperation.resourceJudge(val,currentLayer);
								  html=html+"<li><a title='"+name+"' href='#' class='resourceList'>"+name+"</a><button gid='"+val.getId().split(".")[1]+"'>添加</button></li>";
							  })
							  html=html+"</ul></div>";
							  layer.open({
								  content:html,
								  type:1,
								  title:"可选资源列表",
								  area:["311px","274px"],
								  success:function(layero,index){
									  $(layero).find("button").click(function(){
										  var $that=$(this);
										  var responsePosition=$("#map").data("responsePoint").split("#"),selectPoint=null;
										  var currentId=$that.attr("gid"),currentF=null;
										  for(var i=0,z=features.length;i<z;i++){
											  if(currentId===features[i].getId().split(".")[1]){
												  currentF=features[i];
												  break;
											  }
										  }
										  var distance=buffer.distance([responsePosition[0],responsePosition[1]],currentF.getGeometry().getCoordinates());
										  var arr=JSON.stringify([currentF.getGeometry().getCoordinates()[0].toFixed(5),currentF.getGeometry().getCoordinates()[1].toFixed(5)]);
										  $.post("/main/onemap/isInsert",{tb:"HBAJ:"+currentLayer,sgid:layerConfig.emergencyId,jhdid:currentId}).done(function(data){
											  console.log(data);
											  if(data==="1"){
												  layer.msg("已经添加过不能再次添加！");
												  return;
											  }
											  $.post("/main/onemap/DecisionBuffer",{tb:"HBAJ:"+currentLayer,sgid:layerConfig.emergencyId,jhdid:currentId,distance:distance,position:arr}).done(function(data){
				           		    			   if(data==="1"){
				           		    				   layer.msg("添加成功",{
				           		    					   time:1000,
				           		    					   icon:1
				           		    				   },function(){
				           		    					 $that.parent().animate({
				           		    						 height:0,
				           		    						 opacity:0,
				           		    						 display:"none"
				           		    					 },1000);
				           		    					 var tdLength=$(".resourcebottom tr td[position]").length;
				           		    				     if(tdLength<10){
				           		    				    	 var name=domOperation.resourceJudge(currentF,currentLayer);
				           		    				    	 
				           		    				    	$(".resourcebottom tr").eq(tdLength+1).find("td").eq(0)
				           		    				    	                       .attr("position",JSON.stringify(currentF.getGeometry().getCoordinates())).html("<p class='resourse-p' title='"+name+"'>"+name+"<p>");
				           		    				    	$(".resourcebottom tr").eq(tdLength+1).find("td").eq(1)
				           		    				    	                       .html('<img src="/main/resources/image/images/icon-013.png" title="查看详情" style="cursor:pointer;"><img src="/main/resources/image/images/delete.png" title="删除" style="cursor:pointer;">').attr("gid",currentId);
				           		    				     }
				           		    				   });
				           		    			   }else{
				           		    				   layer.msg("添加失败",{time:1000, icon:0});
				           		    			   }
				           		    		   })
										  })
										
									  })
								  }
							  })
						  }
					
					});
				}
				
			}
			
			if(rescueLayer.getVisible()){//如果应急救援显示则可以选择响应点
				map.forEachFeatureAtPixel(evt.pixel, function (f, l) {
					if(l==rescueLayer){
						if(layerConfig.emergencyId!==f.getId().split(".")[1]){
							rescueLayerClearLayer.getSource().clear();
							var feature1=f.clone();
							var feature2=f.clone();
							rescueLayerClearLayer.getSource().addFeatures([feature1,feature2]);
							var radius1=1,radius2=10;
							clearInterval(rescueLayerClear);
							rescueLayerClear=setInterval(function(){
								if(radius1>25){
									radius1=1;
								}
								if(radius2>25){
									radius2=1;
								}
								feature1.setStyle(new ol.style.Style({
									image:new ol.style.Circle({
										radius:++radius1,
										/*fill:new ol.style.Fill({
											color:"#ff0000"
										}),*/
										stroke:new ol.style.Stroke({
											color:"rgba(255,0,0,"+(1-radius1/25)+")",
											width:2
										})
									})
								}));
								feature2.setStyle(new ol.style.Style({
									image:new ol.style.Circle({
										radius:++radius2,
										/*fill:new ol.style.Fill({
											color:"#ff0000"
										}),*/
										stroke:new ol.style.Stroke({
											color:"rgba(255,0,0,"+(1-radius2/25)+")",
											width:2
										})
									})
								}));
							},80);
							layerConfig.emergencyId=f.getId().split(".")[1];
							//把当前应急响应点的位置存储起来
							$.get("/main/onemap/getCurrentRescue",{rescueId:layerConfig.emergencyId}).done(function(data){
								  $("#map").data("responsePoint",data);
							})
							var state=f.get("STATUS")?true:false;
							map.getOverlays().clear();
							mapTools.emergencyRescue(layerConfig.emergencyId,f.getGeometry().getCoordinates(),state);
						}
					}
					})
			}


			if (xyLayer.getSource().getFeatures().length === 1) {
				map.forEachFeatureAtPixel(evt.pixel, function (f, l) {

					if (f.get("id")){
						$.post("/main/emer/iSearchYjjy", { ids: f.get("id") }, function (data) {
							var obj = JSON.parse(data)[0];
							mapTools.openDetail(obj.url, obj.type, obj.width, obj.height, obj.title, false);
						});
					}
					
				});

			}
		})





	
		//监管图层的显示  待删除
		/*$("#supervise").menu({
			onClick: function (item) {
				var text = item.text;
				switch (text) {
					case "涉氨企业":
						mapTools.superviseLayer("shean");
						break;
					case "涉爆企业":
						mapTools.superviseLayer("shebao");
						break;
					case "粉尘企业":
						mapTools.superviseLayer("fenchen");
						break;
					case "有限空间企业":
						mapTools.superviseLayer("youxiankongjian");
						break;
				}
			}
		});*/

		//根据gps查询gps车辆
		$("#gpsSelect").on("click", function () {
			if ($("#list").css("display") === "block") {
				$("#list").css("display", "none");
			}
			$("#tucengImg").attr("src", "/main/resources/image/map/info.png");
			$("#gpsImg").attr("src", "/main/resources/image/map/gps_active.png");
			$("#carinfo").addClass("active");
			searchGPS();
		});

		//车辆轨迹确定按钮
		$("#guiji_submit").on("click", function () {
			var starttime = $("#starttime").val();
			var endtime = $("#endtime").val();
			if (starttime != "" && endtime != "") {
				var times = Date.parse(endtime.replace(/-/g, '/')) - Date.parse(starttime.replace(/-/g, '/'));
				if (times <= 1 * 24 * 60 * 60 * 1000) {
					clearInterval(stopAnim);
					mapTools.historyTrack($("#select_plateno").val(), starttime, endtime);
				} else
					layer.msg('请确日期范围不超过一天!');
			} else
				layer.msg('请确定日期范围!');
		});

        //搜索图层原来的全选和全不选(删除)
		/*$("#selectAll input").click(function () {
			var index = $("#selectAll input").index(this);
			switch (index) {
				case 0:
					var id = $("#searchLayer ul li.active").attr("getId");
					$("#" + id + " input[type='checkbox']").prop("checked", true);
					break;
				case 1:
					var id = $("#searchLayer ul li.active").attr("getId");
					$("#" + id + " input[type='checkbox']").prop("checked", false);
					break;
			}
		});*/

		//根据所选图层筛选查询热点
		$("#layerSelect").on("click", function () {
			$("#tucengImg").attr("src", "/main/resources/image/map/info_active.png");
			$("#searchLayer").css("display", "block");
			layer.open({
				type: 1,
				title: domOperation.searchName,
				content: $("#searchLayer"),
				area: ["461px", "282px"],
				btn: ["确定"],
				btnAlign: "c",
				yes: function (index, layero) {
					currentLayer="";
					layer.close(index);
					/*var layers = {}, idd = $("#searchLayer ul li.active").attr("getid"); 删除
					layers[idd] = [];
					$("#" + idd).find("input:checked").each(function () {
						layers[idd].push($(this).attr("code"));
					});
					var layerName = domOperation.getLayerName(idd);
					for (var m = 0, n = statLayers.length; m < n; m++) {
						if (statLayers[m].get("layerName") === layerName) {
							var sql = "";
							if (idd === "qy_jglx") {
								sql = domOperation.filterSql("qy_jglx", statLayers[m].getSource().getParams().cql_filter, layers[idd]);
							} else if (idd === "wxylb") {
								sql = domOperation.filterSql("wxylb", statLayers[m].getSource().getParams().cql_filter, layers[idd]);
							} else {
								sql = domOperation.filterSql(layerName, statLayers[m].getSource().getParams().cql_filter, layers[idd]);
							}
							statLayers[m].getSource().updateParams({ cql_filter: sql });
						}
					}*/
				},
				end: function () {
					$("#searchLayer").css("display", "none");
				}
			});

		});

		//如果是热点图层则隐藏全选和全不选
		$("#searchLayer ul li").click(function () {
			if ($(this).attr("getId") === "poi") {
				$("#selectAll").css("display", "none");
			} else {
				$("#selectAll").css("display", "block");
			}
		});




		var cameraKey;
		var alarmLayer=new ol.layer.Vector({
			source:new ol.source.Vector(),
			style:new ol.style.Style({
				image:new ol.style.Icon({
					src:"/main/resources/image/map/alarm.png"
				})
			})
		});
		map.addLayer(alarmLayer);
		
		
		
		
		
		var consultationLayer=new ol.layer.Image({
			visible: false,
			source: new ol.source.ImageWMS({
				crossOrigin: "anonymous",
				ratio: 1,
				url: mapConfig.hebeiBordr,
				params: {
					'FORMAT': "image/png",
					'VERSION': '1.1.1',
					LAYERS: 'HBAJ:TBCAMERA',
					cql_filter:"TYPE=1 and ISENABLE=1"
				}
			}),
			id: "consultationLayer"
		})
		map.addLayer(consultationLayer);
		
		
		
		initMap.cameraLayer.getSource().updateParams({
            cql_filter:""
        });
		//远程会商
		$("#consultation").click(function(){
			if($(this).hasClass("yi_active")){
				consultationLayer.setVisible(true);
				/*if(initMap.cameraLayer.getSource().getParams().cql_filter.indexOf("0")>-1){
					initMap.cameraLayer.getSource().updateParams({
	                      cql_filter:"TYPE in(0,1) and ISENABLE=1"
	                  });
				}else{
					initMap.cameraLayer.getSource().updateParams({
	                      cql_filter:"TYPE=1 and ISENABLE=1"
	                  });
				}*/
			}else{
				consultationLayer.setVisible(false);
				/*if(initMap.cameraLayer.getSource().getParams().cql_filter.indexOf("0,1")>-1){
					initMap.cameraLayer.getSource().updateParams({
	                      cql_filter:"TYPE=0 and ISENABLE=1"
	                  });
				}else{
					initMap.cameraLayer.setVisible(false);
					initMap.cameraLayer.getSource().updateParams({
	                      cql_filter:""
	                  });
				}*/
			}
		})
		
		
		
		// 摄像头按钮控制显示摄像头图层
		$("#camera").click(function () {
			var $ele=$(this);
			if ($ele.hasClass("littleTip")) {
				$ele.find("img").attr("src",$ele.find("img").attr("src").replace("-act.png",".png"));
				map.unByKey(cameraKey);
				$ele.removeClass("littleTip");

				/*if(initMap.cameraLayer.getSource().getParams().cql_filter.indexOf("0,1")>-1){
					initMap.cameraLayer.getSource().updateParams({
	                      cql_filter:"TYPE=1 and ISENABLE=1"
	                  });
				}else{
					initMap.cameraLayer.setVisible(false);
					initMap.cameraLayer.getSource().updateParams({
	                      cql_filter:""
	                  });
				}*/
				initMap.cameraLayer.setVisible(false);
				alarmLayer.getSource().clear();
			} else {
				$ele.addClass("littleTip");
				$ele.find("img").attr("src",$ele.find("img").attr("src").replace(".png","-act.png"));
				initMap.cameraLayer.setVisible(true);
				initMap.cameraLayer.getSource().updateParams({
                    cql_filter:"TYPE=0 and ISENABLE=1 and"+mapConfig.userFilters.split("and")[1]
                });
				
				 
				/*if(initMap.cameraLayer.getSource().getParams().cql_filter.indexOf("1")>-1){
					initMap.cameraLayer.getSource().updateParams({
	                      cql_filter:"TYPE in(0,1) and ISENABLE=1 and"+mapConfig.userFilters.split("and")[1]
	                  });
				}else{
					initMap.cameraLayer.getSource().updateParams({
	                      cql_filter:"TYPE=0 and ISENABLE=1 and"+mapConfig.userFilters.split("and")[1]
	                  });
				}*/
				  
				$.get("/main/mdit/getAllQyid").done(function(data){
					 var obj=JSON.parse(data);
					 var features=obj.map(function(val,index){
						 return new ol.Feature({
							 geometry:new ol.geom.Point([parseFloat(val.jd),parseFloat(val.wd)]),
							 id:val.qyid
						 });
					 });
					 alarmLayer.getSource().clear();
					 alarmLayer.getSource().addFeatures(features);
				});
				cameraKey = map.on("click", function (evt) {
					map.forEachFeatureAtPixel(evt.pixel,function(f,l){
						if(l==alarmLayer){
							layer.open({
								type:2,
								content:"/main/eait/toEaitPage?qyid="+f.get("id"),
								area:["80%","100%"],
								title:"报警信息"
							});
						}
					});
					var url = initMap.cameraLayer.getSource().getGetFeatureInfoUrl(evt.coordinate, view.getResolution(), view.getProjection(),
						{
							'INFO_FORMAT': 'application/json',
							'FEATURE_COUNT': 1
						});
					$.get(url, function (data) {
						if (data.features.length === 0) {
							return;
						}
						var id = data.features[0].id.split(".")[1];
						initMap.panToPoint2(data.features[0].geometry.coordinates);
						
						if(data.features[0].properties.TYPE==="0"){
							if(!domOperation.IsPC()){
								//Android.watch("ezopen://open.ys7.com/" + data.features[0].properties.SERIALNUMBER + "/1.hd.live");
								 Android.getCompanyCameras(data.features[0].properties.QYOPGUID);
							}else{
								layer.open({
									type:2,
									skin:"dome-layer",
									title:"监控列表",
									content:"/main/tbcamera/toCamerasPage?qyid="+ data.features[0].properties.QYOPGUID,
									closeBtn:1,
									area:["748px","400px"]
								})
							}
							
						}
						/*else{
                              if(!domOperation.IsPC()){
                            	  Android.getCompanyCameras(data.features[0].properties.QYOPGUID);
							}else{
								layer.open({
									type:2,
									skin:"dome-layer",
									title:"监控列表",
									content:"/main/tbcamera/toCamerasPage?qyid="+ data.features[0].properties.QYOPGUID,
									closeBtn:1,
									area:["748px","400px"]
								})
							}
							
						}*/

						

					});

				});
			}
		});
         var layerSwitch=0;
		//矢量底图和遥感地图切换
		$("#layerSwitch").hover(function () {
			if(layerSwitch>150){
				return;
			}
			layerSwitch=new Date();
				initMap.routeLayer.getSource().clear();
				$("#satelliteImage").stop(true).animate({
					right: "+91px"
				}, 500).parent().stop(true).animate({
					width: "187px"
				}, 500);
		}, function () {
			if(layerSwitch<150){
			return;
		}
			layerSwitch=new Date()-layerSwitch;
			$("#satelliteImage").stop(true).delay(500).animate({
				right: "0px"
			}, 500).parent().stop(true).delay(500).animate({
				width: "96px"
			}, 500,function(){
				layerSwitch=0;
			});
			
				
		});

		//当点击影像图的时候
		$("#satelliteImage").on("click", function () {
			if ($("#satelliteImage span").attr("class").indexOf("primary") === -1) {
				$("#satelliteImage span").addClass("am-badge-primary");
				$("#vectorMap span").removeClass("am-badge-primary");
				initMap.tiandituVector.setVisible(false);
				initMap.tiandituSatellite.setVisible(true);
			}

		});

		//当点击矢量图层的时候
		$("#vectorMap").on("click", function () {
			if ($("#vectorMap span").attr("class").indexOf("primary") === -1) {
				$("#vectorMap span").addClass("am-badge-primary");
				$("#satelliteImage span").removeClass("am-badge-primary");
				initMap.tiandituVector.setVisible(true);
				initMap.tiandituSatellite.setVisible(false);
			}

		});
		







		//标绘适量图层
		var plotLayer = new ol.layer.Vector({
			source: new ol.source.Vector()
		});
		map.addLayer(plotLayer);

	


		//标绘事件
		/*var plotDraw = null;
		$("#plotting button").click(function () {
			var colors = ["#ff0000", "#00ff00"];
			layer.open({
				title: "颜色选择",
				type: 1,
				content: $("#plotColor"),
				area: ["295px", "239px"],
				btn: ["确定"],
				yes: function () {
					layer.close(layer.index);
					colors.length = 0;
					$("#plotColor input").each(function () {
						colors.push($(this).prop("value"));
					});
				}
			});
			var text = $(this).text();
			switch (text) {
				case "简单箭头":
					map.removeInteraction(plotDraw);
					plotDraw = mapTools.simpleArrow(map, plotLayer.getSource());
					plotDraw.on("drawend", function (evt) {
						evt.feature.setStyle(initMap.createStyle(colors[0], colors[1], 1, 1, colors[2]));
						map.removeInteraction(plotDraw);
					});
					break;
				case "直箭头":
					map.removeInteraction(plotDraw);
					plotDraw = mapTools.fineArrow(map, plotLayer.getSource());
					plotDraw.on("drawend", function (evt) {
						evt.feature.setStyle(initMap.createStyle(colors[0], colors[1], 1, 1, colors[2]));
						map.removeInteraction(plotDraw);
					});
					break;
				case "长箭头":
					map.removeInteraction(plotDraw);
					plotDraw = mapTools.longArrow(map, plotLayer.getSource());
					plotDraw.on("drawend", function (evt) {
						evt.feature.setStyle(initMap.createStyle(colors[0], colors[1], 1, 1, colors[2]));
						map.removeInteraction(plotDraw);
					});
					break;
				case "聚集地":
					map.removeInteraction(plotDraw);
					plotDraw = mapTools.drawHabitation(map, plotLayer.getSource());
					plotDraw.on("drawend", function (evt) {
						evt.feature.setStyle(initMap.createStyle(colors[0], colors[1], 1, 1, colors[2]));
						map.removeInteraction(plotDraw);
					});
					break;
			}
		});
*/
		//只有事故和隐患排查按照时间统计
		$("#selTheLay").on("change", function () {
			var val = $("#selTheLay").val();
			if (val === 'GEOM_SGBS' || val === 'GEOM_Danger_Report') {//只有事故和隐患排查按照时间统计
				$("#yearSelect").parent().parent().slideDown("fast");
			} else {
				$("#yearSelect").parent().parent().slideUp("fast");
			}
		});



		var positionLayer = new ol.layer.Vector({
			source: new ol.source.Vector()
		});
		map.addLayer(positionLayer);
		var style3 = new ol.style.Style({
			image: new ol.style.Icon({
				src: mapConfig.imagePoint,
				anchor: [0.5, 1]
			}),
			zIndex:900
		});

		//当在地图上点击统计点的时候
		$("#list3").on("click", "a.listLocation", function () {
			initMap.panToPoint([parseFloat($(this).attr("x")), parseFloat($(this).attr("y"))]);

			var feature = new ol.Feature({
				geometry: new ol.geom.Point([parseFloat($(this).attr("x")), parseFloat($(this).attr("y"))])
			});
			$("#searchval").val($(this).text());
			feature.setStyle(style3);
			positionLayer.getSource().clear();
			positionLayer.getSource().addFeature(feature);
			var ovarlay=mapTools.overlayFunction();
			mapTools.showSummary(currentLayer,$(this).attr("id"),overlay,[parseFloat($(this).attr("x")), parseFloat($(this).attr("y"))],$(this).attr("title"));
		}).on("mouseover", "a.listLocation", function () {
			var feature = new ol.Feature({
				geometry: new ol.geom.Point([parseFloat($(this).attr("x")), parseFloat($(this).attr("y"))])
			});
			feature.setStyle(style3);
			positionLayer.getSource().clear();
			positionLayer.getSource().addFeature(feature);
		});

		
		var flayer="",partList,clasifica;//专题图层快捷入口的图层名称
		//图层分类按钮
		/*$("a.funcon").click(function () {
			var text = this.lastChild.innerHTML;
			var $list = $(".celist");
			var ly=this.getAttribute("fly");
			flayer=ly;
			$list.slideUp("fast");
			$list.html("");
			
			var operation={
					dom:this,
					statLayers:statLayers,
					layerName:ly,
					searchLayer:lengendLayer
			}
			clasifica=null;
			
			$("#xzqhname").attr("code","");
			switch (text) {
				case "重大危险源":
					function getList1() {
						$.get("/main/onemap/dif?name=zdwxy").then(function (data) {
							var obj = JSON.parse(data);
							$list.append("<li class='firstFL'><a>" + text + "</a></li>");
							partList=obj[0].wxylb;
							for (var i = 0; i < partList.length; i++) {
								$list.append("<li licode='" + partList[i].code + "'><a>" + partList[i].codename + "</a></li>");
							}
						})
						$list.slideDown("fast");
					}
					
					domOperation.layerClassification(operation,getList1);
					break;
				case "应急物资":
					function getList2() {
						$.get("/main/onemap/dif?name=yjwz").then(function (data) {
							var obj = JSON.parse(data);
							$list.append("<li class='firstFL'><a>" + text + "</a></li>");
							partList=obj[0].wz;
							for (var i = 0; i < partList.length; i++) {
								$list.append("<li licode='" + partList[i].code + "'><a>" + partList[i].codename + "</a></li>");
							}
						})
						$list.slideDown("fast");
					}
					domOperation.layerClassification(operation, getList2);
					break;
				case "救援装备":
					function getList3() {
						$.get("/main/onemap/dif?name=zjyb").then(function (data) {
							var obj = JSON.parse(data);
							$list.append("<li class='firstFL'><a>" + text + "</a></li>");
							partList=obj[0].zb;
							for (var i = 0; i < partList.length; i++) {
								$list.append("<li licode='" + partList[i].code + "'><a>" + partList[i].codename + "</a></li>");
							}
							$list.slideDown("fast");
						})
					}
					domOperation.layerClassification(operation, getList3);
					break;
				case "尾矿库":
					function getList4() {
						$.get("/main/onemap/dif?name=wkk").then(function (data) {
							var obj = JSON.parse(data);
							$list.append("<li class='firstFL'><a>" + text + "</a></li>");
							partList=obj[0].wkk;
							for (var i = 0; i < partList.length; i++) {
								$list.append("<li licode='" + partList[i].code + "'><a>" + partList[i].codename + "</a></li>");
							}
							$list.slideDown("fast");
						})
					}
					domOperation.layerClassification(operation, getList4);
					break;
				case "救援队伍":
					function getList5() {
						$.get("/main/onemap/dif?name=jhd").then(function (data) {
							var obj = JSON.parse(data);
							$list.append("<li class='firstFL'><a>" + text + "</a></li>");
							partList=obj[0].jhd;
							for (var i = 0; i < partList.length; i++) {
								$list.append("<li licode='" + partList[i].code + "'><a>" + partList[i].codename + "</a></li>");
							}
							$list.slideDown("fast");
						})
					}
					domOperation.layerClassification(operation, getList5);
					break;

			}
			
		});*/

		//图层分类后的分类列表点击事件
		$(document).find("ul.celist").click(function (evt) {
				if(evt.target.parentNode.className!="firstFL"){
					var code=evt.target.parentNode.getAttribute("licode");
					initMap.statisticalLayer.getSource().clear();
					clasifica={
							classification:true,
							code:code
					}
					$("#xzqhname").attr("code",code);
					mapTools.zoomStatistics(flayer,clasifica);
					
					sql = domOperation.filterSql(flayer,domOperation.flayer.getSource().getParams().cql_filter, [code]);
					domOperation.flayer.getSource().updateParams({ cql_filter: sql });
					if(!partList[0].son||evt.target.style.color){
						return;
					}
					for (var i = 0; i < partList.length; i++) {
						if(partList[i].codename===evt.target.innerHTML){
							var $target=$(evt.target.parentNode);
							if($target.children().length===2){
								$target.find("ul").remove();
								return;
							}
							//清除其兄弟节点的子列表
							$target.siblings().each(function(){
								$(this).find("ul").remove();
							})
							$target.append("<ul style='display:block;margin:0px;'></ul>");
							for(var m=0,n=partList[i].son.length;m<n;m++){
								$target.find("ul").append("<li ispart licode='" + partList[i].son[m].code + "'><a style='color:#757575'>" + partList[i].son[m].codename + "</a></li>");
							}
							break;
						}
		
					}
				}
		});
				
		//如果天地图在更新维护就进行提示
		$.ajax({
			url:"/tdt/dmdz/geocoding?output=json&request=GetCapabilities&service=GeoCoding&version=1.0.0",
			timeout:1500,
			error:function(){
				$(".hint").css("display","block");
				$(".hint").addClass("am-animation-slide-left");
			}
		})
		
		
		
		
		//其他图层的热力图展示
		var allHeatLayer=new ol.layer.Image({
			visible:false,
			source:new ol.source.ImageWMS({
				crossOrigin: "anonymous",
				ratio: 1,
				url: mapConfig.hebeiBordr,
				serverType:"geoserver",
				imageLoadFunction:function(image,src){
						 !imageLoad?null:clearTimeout(imageLoad);
						 imageLoad=setTimeout(function(){
							 image.getImage().src = src;
						 },500);
				},
				params: {
					'FORMAT': "image/png",
					'VERSION': '1.1.1',
					STYLES: 'HeatMap',
					LAYERS: 'HBAJ:GEOM_QYJCXX',
					cql_filter:mapConfig.userFilters.split("=")[1]
				}
			})
		});
		map.addLayer(allHeatLayer);
		//热力图开关按钮
		$("#kqrlt").click(function(){
			allHeatLayer.setVisible(true);
		})
		$("#gbrlt").click(function(){
			allHeatLayer.setVisible(false);
		})
		//专题地图
		$("#themeticMap").click(function(evt){
			  if(evt.target.tagName==="A"){
				  domOperation.hideList();//隐藏列表
				  var $target=$(evt.target);
				  var ly=$target.parent().attr("ly");
				  if($target.hasClass("layerList")){
					  if(ly===currentLayer){
						  $(".cemain").slideUp("fast");
						    initMap.statisticalLayer.getSource().clear();
						    selLys=domOperation.layerQueue(selLys,ly);
						    if(selLys.length>0){
						    	$("#themeticMap li[ly="+selLys[selLys.length-1]+"] a").removeClass("layerList");
						    	for (var i = 0, z = statLayers.length; i < z; i++) {
									if (statLayers[i].get("layerName") === selLys[selLys.length-1]) {
										map.removeLayer(statLayers[i]);
										statLayers.splice(i, 1);
										break;
									}
								}
						    	currentLayer=selLys[selLys.length-1];
						    	selLys=domOperation.layerQueue(selLys,currentLayer);
						    	$("#themeticMap li[ly="+currentLayer+"] a").trigger("click");
						    }else{
						    	$("#currentLy span").text("无");
						    	currentLayer="";
						    	//隐藏热力图
						    	allHeatLayer.setVisible(false);
						    }
						  }else{
							  selLys=domOperation.layerQueue(selLys,ly);
						  }
					  
					  
					 $target.removeClass("layerList");
					  for (var i = 0, z = statLayers.length; i < z; i++) {
						if (statLayers[i].get("layerName") === ly) {
							map.removeLayer(statLayers[i]);
							statLayers.splice(i, 1);
							break;
						}
					}
				  }else{
					if($("#lengends").css("display")==="block"){
						$("#lengends").css("display","none");
						mapTools.createLengend("当前图层", ly);
					}
					  domOperation.hasJg(ly);
					  selLys.push(ly);
					  currentLayer=ly;
					  $target.addClass("layerList");
					  //清除选择的行业类别和监管类型
					  domOperation.clearSel();
					  $("#currentLy span").text(evt.target.innerHTML);
					  $("#currentLy span").attr("currentLy",currentLayer);
					  //不同图层提示不同的文字进行搜索
					  $("#searchval").attr("placeholder",layerConfig.placeholderLy[currentLayer]);
					  statLayers.push(mapTools.createLayer(currentLayer, map));
					  //更新热力图层
					  allHeatLayer.getSource().updateParams({
						  LAYERS:'HBAJ:'+currentLayer
					  });
					  //根基点击图层创建分级分类列表
					  domOperation.createList(currentLayer);
					  mapTools.difLevelData(currentLayer);
					  
				  }

			  }
		});
		
		//点击图例按钮显示图例
		$(".phsach").click(function(){
			mapTools.createLengend("当前图层", currentLayer);
		});
		
		
		
		
		
		

		 var styleCache = {};
		var populationData = new ol.layer.Vector({
		source:new ol.source.Vector(),
		/*style: function(feature) {
	          var size = feature.get('features').length;
	          var style = styleCache[size];
	          if (!style) {
	            style = new ol.style.Style({
	              image: new ol.style.Circle({
	                radius: 10,
	                stroke: new ol.style.Stroke({
	                  color: '#fff'
	                }),
	                fill: new ol.style.Fill({
	                  color: '#3399CC'
	                })
	              }),
	              text: new ol.style.Text({
	                text: size.toString(),
	                fill: new ol.style.Fill({
	                  color: '#fff'
	                })
	              })
	            });
	            styleCache[size] = style;
	          }
	          return style;
	        },*/
		id: "populationData",
		minResolution:0.010986328125,
	     });
		map.addLayer(populationData);
		var heatLayer = new ol.layer.Heatmap({
			source: new ol.source.Vector(),
			maxResolution:0.010986328125,
			weight: function (f) {
				return parseFloat(f.get("rksl")) / 115387.0;
			},
			radius: 22,
			blur: 35
		});
		map.addLayer(heatLayer);
	
		
		//快捷图层的入口
		$(".bottom-fun li").click(function(evt){
			 domOperation.hideList();//隐藏列表
			var $this=$(this);
			 var fly=$(this).find("a").attr("fly");
			if($this.find("img").attr("src").indexOf("-act")>-1){
				$this.find("img").attr("src",$this.find("img").attr("src").replace("-act",""));
				$this.find("a span").css("color",$this.find("a").css("background").split("none")[0]);
				$this.find("a").css("background","");
				if($this.find("a span").text()==="人口热力图"){
					  populationData.getSource().clear();
						heatLayer.getSource().clear();
				  }else if($this.find("a span").text()==="风险地图"){
					  mapTools.destroyRisk();
				  }else{
					  $("#themeticMap li[ly="+fly+"] a").trigger("click"); 
				  }
				   return;
			}else{
				$this.find("img").attr("src",$this.find("img").attr("src").replace(".png","-act.png"));
				$this.find("a").css("background",$this.find("a span").css("color"));
				$this.find("a span").css("color","#ffffff");
				
				
				 if($this.find("a span").text()==="人口热力图"){
					  var index = layer.load(1);
						$.get('/tdt/CZ_RK_XIANG/wfs?VERSION=1.1.0&SERVICE=WFS&REQUEST=GetFeature&TYPENAME=CZ_RK_XIANG&RESULTTYPE=result&FILTER=<ogc:Filter xmlns:ogc="http://www.opengis.net/ogc"><ogc:PropertyIsEqualTo><ogc:PropertyName>CLASID</ogc:PropertyName><ogc:Literal>310904</ogc:Literal></ogc:PropertyIsEqualTo></ogc:Filter>').done(function (data) {
							var $xml = $(data);
							var children = $xml.find("CZ_RK_XIANG");
							var features = [];
								var lon = parseFloat(children.children("lon").text());
								var lat = parseFloat(children.children("lat").text());
								var feature = new ol.Feature({
									geometry: new ol.geom.Point([lon, lat]),
									rksl: children.find("total").text(),
									name: children.find("name").text()
								});
								var total=Math.floor(parseFloat(children.children("total").text())/4000);
								var style=mapTools.setStyle(total.toString(),"RKSJ");
								feature.setStyle(style);
								features.push(feature);
							populationData.getSource().addFeatures(features);
							$.get('/tdt/CZ_RK_XIANG/wfs?VERSION=1.1.0&SERVICE=WFS&REQUEST=GetFeature&TYPENAME=CZ_RK_XIANG&RESULTTYPE=result&FILTER=<ogc:Filter xmlns:ogc="http://www.opengis.net/ogc"><ogc:PropertyIsEqualTo><ogc:PropertyName>CLASID</ogc:PropertyName><ogc:Literal>310906</ogc:Literal></ogc:PropertyIsEqualTo></ogc:Filter>').done(function(data){
								var $xml=$(data).find("CZ_RK_XIANG"),features=[];
								for(var i=0,z=$xml.length;i<z;i++){
									var lon = parseFloat($xml.eq(i).children("lon").text());
									var lat = parseFloat($xml.eq(i).children("lat").text());
									var feature = new ol.Feature({
										geometry: new ol.geom.Point([lon, lat]),
										rksl: $xml.eq(i).find("RKSHJ").text(),
										name: $xml.eq(i).find("name").text()
									});
									features.push(feature);
								}
								heatLayer.getSource().addFeatures(features);
							});
							layer.close(index);
						});
				  }else if($this.find("a span").text()==="风险地图"){
					  initMap.riskLayer.set("isRisk",1);
					  initMap.riskLayer.set("riskStatus",0);
					  mapTools.CityOrCountyRisk();
				  }
				 else{
					  currentLayer=fly;
					  var isHave=false;
					  for (var i = 0, z = statLayers.length; i < z; i++) {
							if (statLayers[i].get("layerName") === currentLayer) {
								isHave=true;
								break;
							}
						}
					  if(!isHave){
						  $("#themeticMap li[ly="+fly+"] a").trigger("click"); 
					  }
					  mapTools.difLevelData(currentLayer);
				  }
				  
				
			}
			
		})
		
		
		
		//对于图层统计进行行业过滤
    $("#industry ul").click(function(evt){
    	if($("#currentLy span").text()==="无"){
    		return;
    	}
    	var $target=$(evt.target);
    	if($target.prop("tagName")==="A"){
    		if(layerConfig.lyHylb[currentLayer]){
    			if(currentLayer==="GEOM_QYJCXX"&&!$target.hasClass("layerList")){
    				if($target.attr("codenum")==="193"){//当点击危险化学品
    					$(".cemain ul:eq(0) li.cefenji").remove();
        				$(".cemain ul:eq(0)").append("<li class='cefenji'><a href='#2' codenum='1418'>危化品生产</a></li>");
        				$(".cemain ul:eq(0)").append("<li class='cefenji'><a href='#2' codenum='1419'>危化品经营</a></li>");
        				$(".cemain ul:eq(0)").append("<li class='cefenji'><a href='#2' codenum='1420'>危化品使用</a></li>");
        				$(".cemain ul:eq(0)").css("display","block");
        				$(".cemain").slideDown();
    				}else if($target.attr("codenum")==="194"){//烟花爆竹分类
    					$(".cemain ul:eq(0) li.cefenji").remove();
    					
        				$(".cemain ul:eq(0)").append("<li class='cefenji'><a href='#2' codenum='1425'>生产企业</a></li>");
        				$(".cemain ul:eq(0)").append("<li class='cefenji'><a href='#2' codenum='1426'>批发企业</a></li>");
        				$(".cemain ul:eq(0)").append("<li class='cefenji'><a href='#2' codenum='1427'>零售企业</a></li>");
        				$(".cemain ul:eq(0)").css("display","block");
        				$(".cemain").slideDown();
    				}else{
    					$(".cemain").slideUp();
    				}
    			}
    			/*else{
    					$(".cemain").slideUp();
    			}*/

        		var params=domOperation.getCodeFl($target);
        		var layerSource=null;
        		for (var i = 0, z = statLayers.length; i < z; i++) {
					if (statLayers[i].get("layerName") === currentLayer) {
						layerSource=statLayers[i].getSource();
						break;
					}
				}
        		judge.updateLayers(currentLayer,layerSource,params);
        		/*var zoom=view.getZoom();
      		   if(zoom<=8){
      			 mapTools.showData(currentLayer,params);
				  }else{
					  mapTools.getCountyData(currentLayer,params);
				  }*/
        		mapTools.difLevelData(currentLayer,params);
    		}else{
    			layer.msg("当前图层不能按照行业类型过滤!");
    		}
    	}
    })
    
    
    //对于图层统计进行监管行业过滤
    $("#supervise2 ul").click(function(evt){
    	if($("#currentLy span").text()==="无"){
    		return;
    	}
    	var $target=$(evt.target);
    	if($target.prop("tagName")==="A"){
    		if(layerConfig.lyJg[currentLayer]){
    			var params=domOperation.getCodeFl($target);
    			var layerSource=null;
        		for (var i = 0, z = statLayers.length; i < z; i++) {
					if (statLayers[i].get("layerName") === currentLayer) {
						layerSource=statLayers[i].getSource();
						break;
					}
				}
        		judge.updateLayers(currentLayer,layerSource,params);
    			/*var zoom=view.getZoom();
    			 if(zoom<=8){
    				 mapTools.showData(currentLayer,params);
    				  }else{
    					  mapTools.getCountyData(currentLayer,params);
    				  }*/
        		mapTools.difLevelData(currentLayer,params);
    		}else{
    			layer.msg("当前图层不能按照监管行业过滤!");
    		}
    	}
    })
    
 
    
    var GpsLy=new ol.layer.Image({
    	source:new ol.source.ImageWMS({
    		crossOrigin: "anonymous",
    		params:{
    			'FORMAT': "image/png",
				'VERSION': '1.1.1',
				STYLES: '',
				LAYERS: "HBAJ:GPS"
    		},
    		url:mapConfig.hebeiBordr
    	}),
    	visible:false
    });
		map.addLayer(GpsLy);
    //GPS车辆历史轨迹信息
    $("#GPS").click(function(){
    	var $ele=$(this);
    	
    	if($ele.hasClass("littleTip")){
    		$ele.removeClass("littleTip");
    		$ele.css("background",$ele.css("background").replace("-act.png",".png"));
			map.unByKey(cameraKey);
			GpsLy.setVisible(false);
		} else {
			$ele.addClass("littleTip");
    		$ele.css("background","");
			GpsLy.setVisible(true);
			cameraKey = map.on("click", function (evt) {
				//var coord=evt.coordinate;
				var url = GpsLy.getSource().getGetFeatureInfoUrl(evt.coordinate, view.getResolution(), view.getProjection(),
					{
						'INFO_FORMAT': 'application/json',
						'FEATURE_COUNT': 1
					});
				$.get(url, function (data) {
					if (data.features.length === 0) {
						return;
					}

					var feature=data.features[0];
					var bh=feature.properties.GPSBH;
					map.getOverlays().clear();
					map.addOverlay(overlay);
					overlay.setPosition(feature.geometry.coordinates);
					initMap.panToPoint(feature.geometry.coordinates);
					var html="<a>"+data.features[0].properties.ZBMC+"</a>"+'<a class="am-btn am-btn-link" style="padding:2px 3px;" href="javascript:void(0);" gpsbh="' + bh + '" title="轨迹"><img src="/main/resources/image/map/lishiguiji.png"/></a>';
					html+='<a class="am-btn am-btn-link" style="padding:2px 3px;" href="javascript:void(0);" gpsbh="' + bh + '" title="位置"><img src="/main/resources/styles/map/css/themes/icons/toolbox3.png"/></a>';
					overlay.getElement().lastChild.innerHTML=html;
					$(".am-btn.am-btn-link").click(function (){
						if (bh !== undefined && $(this).attr("title") === "位置") {
							clearInterval(stopAnim);
							initMap.stopAnim = mapTools.stopAnim = stopAnim = setInterval(mapTools.currentLocation2, 3000, bh, mapTools);
							return;
						} else if (bh !== undefined && $(this).attr("title") === "轨迹") {
							clearInterval(stopAnim);
							openGuiji(bh);
							return;
						}
					})
				});

			});
		}
    });
    
    
    //地图工具
    $("#mapTool").click(function(evt){
    	if(evt.target.tagName==="A"){
    		var attr=evt.target.getAttribute("tools");
    		switch(attr){
    		case "kjdw":   //空间定位
    			$("#mapLonLat").css("display", "block");
    			layer.open({
    				title: "请输入经纬度",
    				type: 1,
    				area: ["auto", "auto"],
    				content: $("#mapLonLat"),
    				closeBtn: 1,
    				cancel: function () {
    					$("#mapLonLat").css("display", "none");
    				},
    				end: function () {
    					$("#mapLonLat").css("display", "none");
    				}
    			});
    			break;
    		case "qcdwbj":   //清除定位标记
    			initMap.locationLayer.getSource().clear();
    			break;
    		case "mjls":    //面积量算
    			mapTools.measureArea(map);
    			break;
    		case "cdls":  //长度量算
    			mapTools.measureLength(map);
    			break;
    		case "kqjl":  //开启卷帘
    			mapTools.openSwipe(map);
    			break;
    		case "gbjl":  //关闭卷帘
    			mapTools.closeSwipe(map);
    			break;
    		case "qcgj":    //清除轨迹
    			mapTools.closeTrack();
    			break;
    		}
    	}
    });
    
    
    //空间分析
    $("#mapAnalyze").click(function(evt){
    	if(evt.target.tagName==="A"){
    		var attr=evt.target.getAttribute("analyze");
    		switch (attr) {
			case "dhcqfx":  //点缓冲区分析
				bufferType = "point";
				$("#mapBufferSet").css("display", "block");
				layer.open({
					title: "配置缓冲区参数",
					type: 1,
					area: ["650px", "505px"],
					content: $("#mapBufferSet"),
					end: function () {
						$("#mapBufferSet").css("display", "none");
					}
				});
				break;
			case "xhcqfx":   //线缓冲区分析
				bufferType = "line";
				layer.open({
					title: "配置缓冲区参数",
					type: 1,
					area: ["650px", "500px"],
					content: $("#mapBufferSet"),
					end: function () {
						$("#mapBufferSet").css("display", "none");
					}
				});
				break;
			case "mhcqfx":  //面缓冲区分析
				bufferType = "polygon";
				layer.open({
					title: "配置缓冲区参数",
					type: 1,
					area: ["650px", "500px"],
					content: $("#mapBufferSet"),
					end: function () {
						$("#mapBufferSet").css("display", "none");
					}
				});
				break;
			case "qcjg":  //清除分析结果
				initMap.searchLayer.getSource().clear();
				//clearInterval(rescueLayerClear);
				break;
		}
    		}
    });
    
    
    //空间统计
    $("#mapStatistics").click(function(evt){
    	if(evt.target.tagName==="A"){
    		  var attr=evt.target.getAttribute("statistics");
    		  if(attr==="tctj"){  //图层统计
    			  $("#themeticSelect").css("display", "block");
    				layer.open({
    					title: "专题图",
    					type: 1,
    					content: $("#themeticSelect"),
    					success: function () {
    						var val = $("#selTheLay").val();
    						if (val === 'GEOM_SGBS' || val === 'GEOM_Danger_Report') {//只有事故和隐患排查按照时间统计
    							$("#yearSelect").parent().parent().slideDown("fast");
    						} else {
    							$("#yearSelect").parent().parent().slideUp("fast");
    						}
    					},
    					end: function () {
    						$("#themeticSelect").css("display", "none");
    					}
    				});
    		  }else{   //清除统计结果
    	    		$("#statisticsLegend").html("");
    				// 清除专题图select交互控件
    				map.removeInteraction(initMap.themeSelect);
    				initMap.themeMap.getSource().clear();
    	    	}
    	}
    });
    
    
    var listCurSty=null,currentCode=null;
    //图层左侧分类分级数据过滤
    $(".cemain").click(function(evt) {
        var $target = $(evt.target);
        if (evt.target.tagName === "A" && evt.target.parentNode.className === "cefenji") {
            listCurSty = evt.target.className;

            if (evt.target.getAttribute("son")) {
                if (!listCurSty) {
                    $(evt.target).parent().parent().find("li")
                        .each(function(index, ele) {
                            $(ele).find("ul").slideUp(500);
                        })
                    var son = JSON.parse(evt.target.getAttribute("son"));
                    var $list = $(evt.target).parent().find("ul").remove().end().append("<ul class='yisonson' style='right:-152px;'></ul>").find("ul");
                    for (var i = 0; i < son.length; i++) {
                        $list.append("<li><a style='line-height:23px;' class='third_item' href='#2' codenum='" + son[i].code + "'>" + son[i].codename + "</a></li>")
                    }
                    $list.delay(500).slideDown(500);
                } else {
                    if ($(evt.target).parent().find("ul").css("display") === "block") {
                        $(evt.target).parent().find("ul").slideUp(500);
                    }
                }
            }
            currentCode = evt.target.getAttribute("codenum");
            evt.target.classList.toggle("listActive");
            if(evt.target.tagName === "A" && !evt.target.className&&$(evt.target).parent().find("ul li a").length>0){
            	//当取消左侧一级分类的时候，删除二级分类的listActive样式名
            	 $(evt.target).parent().find("ul li a").removeClass("listActive");
            	 console.log($(evt.target).parent().find("ul li a"));
            }
            var params = domOperation.getCodeFl(null);
            var layerSource = null;
            for (var i = 0, z = statLayers.length; i < z; i++) {
                if (statLayers[i].get("layerName") === currentLayer) {
                    layerSource = statLayers[i].getSource();
                    break;
                }
            }
            judge.updateLayers(currentLayer, layerSource, params);
            mapTools.difLevelData(currentLayer, params);
            /*var zoom = view.getZoom();
            if (zoom <= 8) {
                mapTools.showData(currentLayer, params);
            }
            else {
                mapTools.getCountyData(currentLayer, params);
            }*/
        }
         

        if ($target.hasClass("third_item")) {
            $target.toggleClass("listActive");

            var params = domOperation.getCode();
            var layerSource = null;
            for (var i = 0, z = statLayers.length; i < z; i++) {
                if (statLayers[i].get("layerName") === currentLayer) {
                    layerSource = statLayers[i].getSource();
                    break;
                }
            }
            judge.updateLayers(currentLayer, layerSource, params);
            var zoom = view.getZoom();
            if (zoom <= 8) {
                mapTools.showData(currentLayer, params);
            } else {
                mapTools.getCountyData(currentLayer, params);
            }
        }



    });
    
    


	
		
		
    var hrefLayer = document.location.href.split("layer=")[1];
	var hrefCoordx = "";
	if (document.location.href.split("&").length >= 3 && document.location.href.indexOf("xCoord") > -1) {
		hrefCoordx = document.location.href.split("xCoord=")[1].split("&")[0];
	}
	if (document.location.search.indexOf("location") > -1) {
		var location = document.location.search.split("location=")[1].split("*");
		setTimeout(domOperation.flyToLocation, 2000, [parseFloat(location[0]), parseFloat(location[1])]);
	}


	var xyLayer = new ol.layer.Vector({
		source: new ol.source.Vector()
	});
	if (hrefCoordx) {

		var hrefCoordy = document.location.href.split("yCoord=")[1];
		var style1 = new ol.style.Style({
			image: new ol.style.Icon({
				src: mapConfig.imagePoint,
				anchor: [0.5, 1]
			})
		});

		var feature = new ol.Feature({
			geometry: new ol.geom.Point([parseFloat(hrefCoordx), parseFloat(hrefCoordy)]),
			id: hrefCoordx.split("*")[1]
		});
		feature.setStyle(style1);
		xyLayer.getSource().addFeature(feature);

		map.addLayer(xyLayer);
		initMap.panToPoint([parseFloat(hrefCoordx), parseFloat(hrefCoordy)]);

	}
	
	
	//风险地图
	$("#geom_fxdt").click(function(){
		$(".bottom-fun li #fxdt").trigger("click");
		var $ele=$(this);
		if ($ele.hasClass("littleTip")) {
			$ele.removeClass("littleTip");
			$ele.find("img").attr("src",$ele.find("img").attr("src").replace("-act.png",".png"));}
		else{
			$ele.addClass("littleTip");
			$ele.find("img").attr("src",$ele.find("img").attr("src").replace(".png","-act.png"));
		}
	});
	
	
	
	
	
	
	//复位功能
	$(".fuwei").click(function(){
		initMap.panToPoint([116.112212109375, 38.566251171875],7);
	})
	
	var isearchKey="";
	//i查询
	$("#isearch").click(function () {
		var $this=$(this);
		if(!$this.hasClass("littleTip")){
			$("#map").css("cursor", "url(../resources/image/map/i.cur) 0 -32,auto");
			$this.addClass("littleTip");
			$this.find("img").attr("src",$this.find("img").attr("src").replace(".png","-act.png"));
			isearchKey=map.on("singleclick",function(evt){
				
				var coord=evt.coordinate;
				var layerSource=null;
        		for (var i = 0, z = statLayers.length; i < z; i++) {
					if (statLayers[i].get("layerName") === currentLayer) {
						layerSource=statLayers[i].getSource();
						layerSource.updateParams({ LAYERS: currentLayer })
						break;
					}
				}
				
				var url = layerSource.getGetFeatureInfoUrl(coord, view.getResolution(), view.getProjection(),
						{
							'INFO_FORMAT': 'application/json',
							'FEATURE_COUNT': 30
						});
				$.get(url).done(function(data){
					if(!data.features[0]){
						console.warn("此处没有信息");
						return;
					}
					
					map.getOverlays().clear();
					var overlay = mapTools.overlayFunction();
					var features=data.features;
					var position=data.features[0].geometry.coordinates;
					if(currentLayer==="GEOM_QYJCXX"){
						var table = '<a class="am-btn am-btn-link" title="' + features[0].properties.QYMC + '" href="javascript:void(0);" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:300px;" ids="' + features[0].id.split(".")[1] + '">' + features[0].properties.QYMC + '</a>';
						overlay.getElement().lastChild.innerHTML = table;
						map.addOverlay(overlay);
						overlay.setPosition(position);
						initMap.panToPoint(position);
						$.post("/main/qyjcxxManager/getQyBusinessInformationForMap", { ids: features[0].id.split(".")[1] }, function (data) {
							var obj = JSON.parse(data);
							$(".am-btn.am-btn-link").click(function () {
										mapTools.openDetail(obj[0].url, obj[0].type, obj[0].width, obj[0].height, obj[0].title, true);
							});
						})
						
					}else if(currentLayer==="GEOM_WXYQY"){//危险源企业
						var table = '<a class="am-btn am-btn-link" title="' + features[0].properties.QYMC + '" href="javascript:void(0);" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:300px;" ids="' + id + '">' + features[0].properties.QYMC + '</a>';
						overlay.getElement().lastChild.innerHTML = table;
						initMap.map.addOverlay(overlay);
						overlay.setPosition(position);
						initMap.panToPoint(position);
						$("#popup-content a").click(function(){
							layer.open({
								type:2,
								title:features[0].properties.QYMC,
								content:"/main/zdwxySqManage/zdwxyHzblistForMap?qyguid="+features[0].id.split(".")[1],
								area:["500px","500px"]
							})
						});
						
						
					}else{
						
						if (currentLayer==="GEOM_LAWINFO_PLAN") {//执法监察
								var ids = [data.features[0].id.split(".")[1]];
								for (var i = 1, z = data.features.length; i < z; i++) {
									if (data.features[0].properties.QYID === data.features[i].properties.QYID) {
										ids.push(data.features[i].id.split(".")[1]);
									}
								}
								$.post("/main/zfjc/iSearchMoreByLiAnIds", { ids: ids }).done(function (data) {
									var obj = JSON.parse(data), table = '<ul class="am-list" style="margin-bottom:0px;">';
									for (var m = 0, n = obj.length; m < n; m++) {
										table += '<li><a style="padding:5px 0;" pid="' + obj[m].id + '" href="#">' + obj[m].name + '</a></li>';
									}
									table += '</ul>';
									map.addOverlay(overlay);
									overlay.getElement().lastChild.innerHTML = table;
									overlay.setPosition(coord);
									initMap.panToPoint(coord);
									$(overlay.getElement().lastChild).click(function (evt) {
										if (evt.target.tagName === "A") {
											if (evt.target.getElementsByTagName("p").length > 0) {
												if ($(evt.target).find("p").css("display") === "none") {
													$(evt.target).find("p").slideDown();
												} else {
													$(evt.target).find("p").slideUp();
												}

											} else {
												$.post("/main/zfjc/iSearchLiAn", { id: evt.target.getAttribute("pid") }).done(function (d) {
													var lianD = JSON.parse(d);
													var p = document.createElement("p");
													p.innerHTML = "<p style='color:#333;' title='" + lianD.code + "'><span>编号:</span>" + lianD.code + "</p><p style='display:inline-flex;color:#333;'><span>时间:</span><i>" + lianD.date + "</i><span style='position:absolute;right: 11px;text-decoration: underline;color:#0066cc;font-weight:normal;cursor:pointer;'>查看详情</span></p>";
													evt.target.appendChild(p);
												});
											}
										} else if (evt.target.tagName === "SPAN" && evt.target.innerHTML === "查看详情") {
											judge.openDetail(currentLayer, evt.target.parentNode.getAttribute("pid"));
										}
									});
								})
								return;}
						else if(currentLayer==="GEOM_WXYHZB"){//重大危险源
							var table = '<ul class="am-list" style="margin-bottom:0px;">';
							table += '<li><a style="padding:5px 0;" pid="' + data.features[0].id.split(".")[1] + '" href="#">' + data.features[0].properties.WXYMC + '</a></li>';
							for (var i = 1, z = data.features.length; i < z; i++) {
								if (data.features[0].properties.QYID === data.features[i].properties.QYID) {
									table += '<li><a style="padding:5px 0;" pid="' + data.features[i].id.split(".")[1] + '" href="#">' + data.features[i].properties.WXYMC + '</a></li>';
								}
							}
							table += '</ul>';
							map.addOverlay(overlay);
							overlay.getElement().lastChild.innerHTML = table;
							overlay.setPosition(coord);
							initMap.panToPoint(coord);
							$(overlay.getElement().lastChild).click(function (evt) {
								if (evt.target.tagName === "A") {
									if (evt.target.getElementsByTagName("p").length > 0) {
										if ($(evt.target).find("p").css("display") === "none") {
											$(evt.target).find("p").slideDown();
										} else {
											$(evt.target).find("p").slideUp();
										}

									} else {
										$.post("/main/zdwxySqManage/searchWxyAbstractForMap", { id: evt.target.getAttribute("pid") }).done(function (d) {
											var lianD = JSON.parse(d);
											var p = document.createElement("p");
											p.innerHTML = "<p style='color:#333;' title='" + lianD[0].name + "'><span>重大危险源名称:</span>" + lianD[0].name + "</p><p style='color:#333;' title='"+lianD[0].type+ "'><span>重大危险源级别:</span>" + lianD[0].grade + "</p><p style='display:inline-flex;color:#333;'><span>企业名称:</span><i>" + lianD[0].qymc + "</i><span style='position:absolute;right: 11px;text-decoration: underline;color:#0066cc;font-weight:normal;cursor:pointer;'>查看详情</span></p>";
											evt.target.appendChild(p);
										});
									}
								} else if (evt.target.tagName === "SPAN" && evt.target.innerHTML === "查看详情") {
									judge.openDetail(currentLayer, evt.target.parentNode.parentNode.parentNode.getAttribute("pid"));
								}
							});
								return;
						}else if(currentLayer==="GEOM_YJZY_YJJYZB"){//救援装备
							var table = '<ul class="am-list" style="margin-bottom:0px;">';
							table += '<li><a style="padding:5px 0;" pid="' + data.features[0].id.split(".")[1] + '" href="#">' + data.features[0].properties.ZBMC + '</a></li>';
							for (var i = 1, z = data.features.length; i < z; i++) {
								if (data.features[0].properties.QYID === data.features[i].properties.QYID) {
									table += '<li><a style="padding:5px 0;" pid="' + data.features[i].id.split(".")[1] + '" href="#">' + data.features[i].properties.ZBMC + '</a></li>';
								}
							}
							table += '</ul>';
							map.addOverlay(overlay);
							overlay.getElement().lastChild.innerHTML = table;
							overlay.setPosition(coord);
							initMap.panToPoint(coord);
							$(overlay.getElement().lastChild).click(function (evt) {
								if (evt.target.tagName === "A") {
									if (evt.target.getElementsByTagName("p").length > 0) {
										if ($(evt.target).find("p").css("display") === "none") {
											$(evt.target).find("p").slideDown();
										} else {
											$(evt.target).find("p").slideUp();
										}

									} else {
										$.post("/main/yjzyManager/gyxxjyzbDataMapOpen", { id: evt.target.getAttribute("pid") }).done(function (d) {
											var lianD = JSON.parse(d);
											var p = document.createElement("p");
											p.innerHTML = "<p style='color:#333;' title='" + lianD.name + "'><span>装备名称:</span>" + lianD.name + "</p><p style='color:#333;' title='"+lianD.ssdw+ "'><span>所属单位名称:</span>" + lianD.ssdw + "</p><p style='color:#333;' title='"+lianD.amout+ "'><span>数量:</span>" + lianD.amout + "</p><p style='display:inline-flex;color:#333;'><span>联系人电话:</span><i>" + lianD.phone + "</i><span style='position:absolute;right: 11px;text-decoration: underline;color:#0066cc;font-weight:normal;cursor:pointer;'>查看详情</span></p>";
											evt.target.appendChild(p);
										});
									}
								} else if (evt.target.tagName === "SPAN" && evt.target.innerHTML === "查看详情") {
									judge.openDetail(currentLayer, evt.target.parentNode.parentNode.parentNode.getAttribute("pid"));
								}
							});
								return;
						}else if(currentLayer==="GEOM_YJYA_YJWZ"){//救援物资
							var table = '<ul class="am-list" style="margin-bottom:0px;">';
							table += '<li><a style="padding:5px 0;" pid="' + data.features[0].id.split(".")[1] + '" href="#">' + data.features[0].properties.WZMC + '</a></li>';
							for (var i = 1, z = data.features.length; i < z; i++) {
								if (data.features[0].properties.QYID === data.features[i].properties.QYID) {
									table += '<li><a style="padding:5px 0;" pid="' + data.features[i].id.split(".")[1] + '" href="#">' + data.features[i].properties.WZMC + '</a></li>';
								}
							}
							table += '</ul>';
							map.addOverlay(overlay);
							overlay.getElement().lastChild.innerHTML = table;
							overlay.setPosition(coord);
							initMap.panToPoint(coord);
							$(overlay.getElement().lastChild).click(function (evt) {
								if (evt.target.tagName === "A") {
									if (evt.target.getElementsByTagName("p").length > 0) {
										if ($(evt.target).find("p").css("display") === "none") {
											$(evt.target).find("p").slideDown();
										} else {
											$(evt.target).find("p").slideUp();
										}

									} else {
										$.post("/main/yjzyManager/gyxxjywzDataMapOpen", { id: evt.target.getAttribute("pid") }).done(function (d) {
											var lianD = JSON.parse(d);
											var p = document.createElement("p");
											p.innerHTML = "<p style='color:#333;' title='" + lianD.name + "'><span>物资名称:</span>" + lianD.name + "</p><p style='color:#333;' title='"+lianD.ssdw+ "'><span>所属单位名称:</span>" 
											+ lianD.ssdw + "</p><p style='color:#333;' title='"+lianD.amout+ "'><span>数量:</span>" + lianD.amout + "</p><p style='color:#333;' title='"+lianD.zbtype+ "'><span>物资所属单位分类:</span>" + lianD.wztype + "</p><p style='display:inline-flex;color:#333;'><span>联系人电话:</span><i>" 
											+ lianD.phone 
											+ "</i><span style='position:absolute;right: 11px;text-decoration: underline;color:#0066cc;font-weight:normal;cursor:pointer;'>查看详情</span></p>";
											evt.target.appendChild(p);
										});
									}
								} else if (evt.target.tagName === "SPAN" && evt.target.innerHTML === "查看详情") {
									judge.openDetail(currentLayer, evt.target.parentNode.parentNode.parentNode.getAttribute("pid"));
								}
							});
								return;
						}

						
						
						var id = "";
						switch(currentLayer){
						case "GEOM_HON_CHMAIN"://诚信企业传递的参数为企业id
							id = data.features[0].properties.QYID;	
							break;
							default:
								id = data.features[0].id.split(".")[1];	
						}
						mapTools.showSummary(currentLayer,id,overlay,position);
					}
				}).fail(function(){
					layer.msg("数据获取失败，请重新选择点！");
				});
			});
		}else{
			$("#map").css("cursor", "auto");
			$this.removeClass("littleTip");
			$this.find("img").attr("src",$this.find("img").attr("src").replace("-act.png",".png"));
			map.unByKey(isearchKey);
		}
	})
	
	
	
	
	var layerOpen=0;
	$("#decisionSupport li").click(function(){
		  var text=$(this).text();
		  switch (text) {
			case "点分析":  //点缓冲区分析
				bufferType = "point";
				break;
			case "线分析":   //线缓冲区分析
				bufferType = "line";
				break;
			case "面分析":  //面缓冲区分析
				bufferType = "polygon";
				break;
			case "qcjg":  //清除分析结果
				initMap.searchLayer.getSource().clear();
				break;
		}
		  layer.open({
				title: "配置缓冲区参数",
				type: 1,
				area: ["600px", "535px"],
				content: $("#decisionBufferSet"),
				success:function(){
					if(layerOpen===0){
						layerOpen++;
						$("#decisionBufferSet li[rescue=GEOM_YJZY_YJJYDW] a").trigger("click");
					}
					
				},
				end: function () {
					$("#decisionBufferSet").css("display", "none");
				}
			});
	});
	
	var $api={};
	//决策支持的分析结果
	$("#decisionBufferSet").click(function(evt){
		   var $target=$(evt.target);
		if($target.prop("tagName")==="A"){
			    if(!$target.parent().hasClass("tactive")){
			    	$target.parent().siblings().removeClass("tactive");
			    	 $target.parent().addClass("tactive");
			    	 var tb=$target.parent().attr("rescue");
			    	 $(".list-right.fl").html("");
			    	 switch($target.text()){
			    	 case "救援队伍":
			    		 if(!$api[tb]){
			    			 $api[tb]=$.post("/main/zjjgManager/flfjMapOpen",{name:tb});
			    		 }
			    		 $api[tb].done(function(data){
			    			 $(".list-right.fl").append("<div>");
			    			 $(".list-right.fl div:eq(0)").append("<hr/>");
				    		   var obj=JSON.parse(data);
				    		  
				    		   for(var i=0,z=obj.fl.length;i<z;i++){
				    			   $(".list-right.fl div:eq(0)").append("<label><input code='"+obj.fl[i].codenum+"' type='checkbox'/>"+obj.fl[i].codename+"</label>");
				    		   }
				    		   $(".list-right.fl").append("<div>");
				    		   $(".list-right.fl div:eq(1)").append("<hr/>");
				    		  
				    		   for(var i=0,z=obj.grade.length;i<z;i++){
				    			   $(".list-right.fl div:eq(1)").append("<label><input code='"+obj.grade[i].codenum+"' type='checkbox'/>"+obj.grade[i].codename+"</label>");
				    		   }
				    		   
				    	})
			    		 break;
			    	 case "应急物资":
			    		 if(!$api[tb]){
			    			 $api[tb]=$.post("/main/onemap/dif?name=yjwz")
			    		 }
			    		 $api[tb].done(function(data){
				    		   var obj=JSON.parse(data);
				    		   for(var i=0,z=obj[0].wz.length;i<z;i++){
				    			   $(".list-right.fl").append("<label><input code='"+obj[0].wz[i].code+"' type='checkbox'/>"+obj[0].wz[i].codename+"</label>");
				    		   }
				    		   
				    	});
			    		 break;
			    	 case "救援装备":
			    		 if(!$api[tb]){
			    			 $api[tb]=$.post("/main/onemap/dif?name=zjyb")
			    		 }
			    		 $api[tb].done(function(data){
				    		   var obj=JSON.parse(data);
				    		   for(var i=0,z=obj[0].zb.length;i<z;i++){
				    			   $(".list-right.fl").append("<label><input code='"+obj[0].zb[i].code+"' type='checkbox'/>"+obj[0].zb[i].codename+"</label>");
				    		   }
				    		   
				    	});
				    	 
			    		 break;
			    	 case "重大危险源":
			    		 $(".list-right.fl").append("<label><input code='"+tb+"' type='checkbox'/>重大危险源</label>");
			    		 break;
			    	 case "脆弱性目标":
			    		 $(".list-right.fl").append("<label><input code='"+tb+"' type='checkbox'/>脆弱性目标</label>");
			    		 break;
			    	 case "人口数据":
			    		 $(".list-right.fl").append("<label><input code='"+tb+"' type='checkbox'/>人口数据</label>");
			    		 break;
			    	 }
			    	
			    }
		   }
	});
	
	//决策支持进行缓冲区分析
	$("#decisionSetPoint").click(function(){
		//清除统计图层
		initMap.statisticalLayer.getSource().clear();
		layer.close(layer.index);
		$("#decisionBufferSet").css("display", "none");
		var layerNames = $("#decisionBufferSet .list-left li.tactive").attr("rescue");
		getSearchLay = layerNames;
		var bufferDistance = parseFloat($("#decisionSetPoint").siblings("input").val());
		if (bufferType === "polygon") bufferDistance = 0.1;
			if (bufferType === "point") {
				buffer.buffer(map, initMap.searchLayer
					.getSource(), drawPoint, layerNames,
					bufferDistance,true);
			} else if (bufferType === "line") {
				buffer.buffer(map, initMap.searchLayer
						.getSource(), drawLine, layerNames,
						bufferDistance,true);
			} else {
				buffer.buffer(map, initMap.searchLayer
					.getSource(), drawPolygon, layerNames,
					0.1,true);
			}

	});
	
	
	//生成救援方案
	$("#rescuePlan").click(function(){
		if(!!layerConfig.emergencyId){
			window.parent.parent.commonAddTabs("救援方案","/main/yjxy/yjczfaDetail?respguid="+layerConfig.emergencyId+"&readonly=false");
		}else{
			layer.msg("请先选择应急响应点!");
		}
	});
	
	
	
	/*var addResources=initMap.addResources;//控制是否能够进行增加资源，只能增加队伍、救护队、物资
	//增加资源
	$("#addResources").click(function(evt){
		if($(evt.target).hasClass("ysonact")){
			addResources=true;
		}else{
			addResources=false;
		}
	});*/
	
	//资源清单的首页、上一页、下一页、末页功能
	$(".resourcetable .qypage").click(function(evt){
		var $target=$(evt.target);
		var pageName=$target.text();
		var text=$(".resourcetop.clearfix a.act").html();
		var total=parseInt($(".resourcetable").attr("total"));
		var currentPage=isNaN(parseInt($(".resourcetable").attr("currentPage")))?1:parseInt($(".resourcetable").attr("currentPage"));
		switch(pageName){
		case "首页":
			if(currentPage!==1){
				domOperation.rescueList(text,1);
			}
			break;
		case "上一页":
			if(currentPage>1){
				$(".resourcetable").attr("currentPage",currentPage-1);
				domOperation.rescueList(text,currentPage-1);
			}
			break;
		case "下一页":
			if(total/10>currentPage){
				$(".resourcetable").attr("currentPage",currentPage+1);
				domOperation.rescueList(text,currentPage+1);
			}
			break;
		case "末页":
			if(currentPage!==1){
				domOperation.rescueList(text,Math.ceil(total/10));
			}
			break;
		case "添加":
			var text=$(".resourcetop.clearfix a.act").html();
			var ly=domOperation.rescueLy(text);
			if(currentLayer===ly){
				layer.msg("您当前正在添加的是"+text+"图层的数据！");
				initMap.addResources=true;
			}else{
				layer.msg("请您先选择专题地图中的"+text+"再点击添加按钮");
			}
			break;
		}
	})
	
	
	//资源清单被点击时定位到该点显示概要信息
	$(".resourcetable .resourcebottom tr:not(:last)").click(function(evt){
		  var $target=$(evt.target);
		  var position=$target.parent().attr("position");
		  var title=$target.attr("title");
		  var id=$target.parent().attr("gid");
		  if(title==="删除"){
			  $.post("/main/onemap/DecisionBufferDel",{sgid:layerConfig.emergencyId,jhdid:id,tb:currentLayer}).done(function(data){
   			   if(data==="1"){
   				$target.parent().parent().find("td").html("")
   				                .removeAttr("gid").removeAttr("position").end()
   				                .insertAfter($(".resourcetable table tr:eq(10)"));
   				   layer.msg("删除成功");
   			   }else{
   				   layer.msg("删除失败");
   			   }
   		   })
		  }else if(title==="查看详情"){
			  var text=$(".resourcetop.clearfix a.act").html();
				var ly=domOperation.rescueLy(text);
			  judge.openDetail(ly,id);
		  }else{
			  if(!!position){
				  var point=JSON.parse(position);
				  var coordinates=[parseFloat(point[0]),parseFloat(point[1])];
				  initMap.panToPoint3(coordinates,12);
				  var ovarlay=mapTools.overlayFunction();
				  mapTools.showSummary(currentLayer,$target.parent().next().attr("gid"),overlay,coordinates);
			  }
		  }
	})
	
	/*//点击图标显示资源清单的详细信息
	$(".resourcetable").click(function(evt){
		var $target=$(evt.target);
		if($target.prop("tagName")==="IMG"){
			
			
		}
	});*/
	
	
	//点击资源清单头部的图层名称切换列表
	$(".resourcetable ul").click(function(evt){
		//关闭添加资源功能
		initMap.addResources=false;
		var target=$(evt.target);
		target.parent().parent().find("li a").removeClass("act");
		target.addClass("act");
		var text=target.text();
		var ly=domOperation.rescueLy(text);
		if($("#themeticMap li[ly="+ly+"] a").hasClass("layerList")){
			$("#themeticMap li[ly="+ly+"] a").trigger("click");
			$("#themeticMap li[ly="+ly+"] a").trigger("click");
		}else{
			$("#themeticMap li[ly="+ly+"] a").trigger("click");
		}
		
		$(".resourcebottom tr td[gid]").html("").removeAttr("gid");
		$(".resourcebottom tr td[position]").html("").removeAttr("position");
		$(".resourcetable").removeAttr("currentPage")
		domOperation.rescueList(text,1);//加载列表
	})
	
	//资源清单
	$("#resourceInventory").click(function(){
		
        var isActive=$(this).hasClass("ysonact");
		if(!!layerConfig.emergencyId&&isActive){
			$(".resourcetable").slideDown();
			domOperation.rescueList("救护队",1);
			$("#themeticMap li[ly=GEOM_YJZY_YJJYDW] a").trigger("click");
		}else if(!layerConfig.emergencyId){
			layer.msg("请先选择应急响应点!");
		}else if(!isActive){
			initMap.addResources=false;
		}
		
	});
	
	//最新动态
	$("#recentNews").click(function(){
			var id=layerConfig.emergencyId?layerConfig.emergencyId:"";
			if($(this).hasClass("yi_active")){
				layer.open({
					type:2,
					title:"最新动态",
					content:"/main/yjxy/toYjxyLatestNewsForMap?respguid="+id,
					area:["900px","580px"]
				});
			}
			
	});
	
	
	
	
	
	var rescueLayer=new ol.layer.Vector({
		source:new ol.source.Vector(),
		visible:false,
		style:new ol.style.Style({
			image:new ol.style.Circle({
				fill:new ol.style.Fill({color:"#ff0000"}),
				radius:5,
				stroke:new ol.style.Stroke({
					color:"#ff0000",
					width:1
				})
			})
		})
	});
	map.addLayer(rescueLayer);
	//加载应急响应图层
	$("#emergencyRescue").click(function(){
		if($("#emergencyRescue").hasClass("yi_active")){
			if(rescueLayer.getSource().getFeatures().length>0){
				rescueLayer.setVisible(true);
			}else{
				$.post(mapConfig.bufferUrl+"service=WFS&version=1.1.0&cql_filter="+encodeURI(mapConfig.userFilters.split("and")[1])+"&REQUEST=GetFeature&outputFormat=application/json&typename=GEOM_EMERG_RESPONSE&SRS=EPSG:4326").done(function(data){
					var format=new ol.format.GeoJSON();
					var features=format.readFeatures(data);
					for(var m=0,n=features.length;m<n;m++){
						if(!features[m].get("STATUS")){
							console.log(features[m].get("STATUS"));
							features[m].setStyle(new ol.style.Style({
								image:new ol.style.Circle({
									radius:6,
									fill:new ol.style.Fill({
										color:"#666"
									})
								})
							}))
						}else{
							if(features[m].get("STATUS")=="1"){
								features[m].setStyle(new ol.style.Style({
									image:new ol.style.Icon({
										src:"/main/resources/image/map/yjxy.png",//当前应急响应
										anchor:[0.5,0.5]
									})
								}))
							}else{
								features[m].setStyle(new ol.style.Style({
									image:new ol.style.Icon({
										src:"/main/resources/image/map/yjxystory.png",//历史应急响应
										anchor:[0.5,0.5]
									})
								}))
							}
						}
					}
					rescueLayer.getSource().addFeatures(features);
					rescueLayer.setVisible(true);
				})
			}
		}else{
			rescueLayer.setVisible(false);
		}
		
		
	});
	
	
	
	
		
	//当页面加载进来以后初始化显示的统计图层
	if (hrefLayer) {
		if(hrefLayer==="GEOM_FXZS"){
			//domOperation.riskLayerHide();
			$("#fxdt").parent().trigger("click");
		}else{
			if(hrefLayer.length>20){
				$.get("/main/onemap/getCurrentRescue",{rescueId:layerConfig.emergencyId}).done(function(data){
					  $("#map").data("responsePoint",data);
				});
				layerConfig.emergencyId=hrefLayer;
				mapTools.showInfo(hrefLayer);
			}else if(hrefLayer==="YCHS"){
				$("#consultation").trigger("click");
			}else{
				$("#themeticMap li[ly="+hrefLayer+"] a").trigger("click");
			}
			
		}
	} else {
		$("#themeticMap li[ly=GEOM_QYJCXX] a").trigger("click");
	}
		
		
		
	});


   





